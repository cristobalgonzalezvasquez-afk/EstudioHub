import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { describe, expect, it } from "vitest";
import { validateStudyKitSnapshotIntegrity, validateStudyStatePayload } from "./studyhub";

const sourceText = "[Biología · Fotosíntesis · apuntes de clase]\nLa fotosíntesis transforma la energía luminosa en energía química y ocurre principalmente en los cloroplastos de las células vegetales.";
const moduleSource = readFileSync(new URL("../client/public/studyhub-study-kit-compat-v1.js", import.meta.url), "utf8");

function loadCompatibility() {
  const windowState: { StudyKitCompatibility?: { normalize: (kit: any) => any; normalizeInPlace: (kit: any) => boolean } } = {};
  runInNewContext(moduleSource, { window: windowState });
  return windowState.StudyKitCompatibility!;
}

function legacySnapshot() {
  const quote = "La fotosíntesis transforma la energía luminosa";
  const kit = {
    id: "legacy-kit-1", title: "Kit heredado", difficulty: "Intermedio", createdAt: "2026-10-15T00:00:00.000Z", sourceLength: sourceText.length,
    sourceText, sourceLabels: [], sourceClassIds: [], sourceFiles: [],
    studyGuide: { summary: "Resumen suficiente sobre la transformación de energía luminosa en las células vegetales.", keyPoints: ["La luz entrega energía", "Los cloroplastos transforman energía", "El resultado es energía química"], glossary: [{ term: "Luz", definition: "Energía que inicia el proceso.", sourceQuote: quote }, { term: "Cloroplasto", definition: "Estructura de células vegetales.", sourceQuote: quote }, { term: "Energía química", definition: "Energía producida por el proceso.", sourceQuote: quote }], questions: ["¿Qué energía transforma?", "¿Dónde ocurre?", "¿Qué produce?"], sourceQuote: quote, podcastScript: "" },
    multipleChoice: [], questions: [{ id: "q1", question: "¿Qué transforma la fotosíntesis?", topic: "Fotosíntesis", options: ["Energía luminosa", "Sonido", "Gravedad", "Viento"], correctIndex: 0, explanations: ["La fuente lo indica.", "No corresponde.", "No corresponde.", "No corresponde."], sourceQuote: quote }],
    trueFalse: [], trueFalseQuestions: [{ id: "tf1", question: "La fotosíntesis ocurre en cloroplastos.", topic: "Fotosíntesis", answer: true, explanation: "La fuente menciona los cloroplastos.", sourceQuote: quote }],
    matchingPairs: [], pairs: [{ id: "pair1", left: "Fotosíntesis", right: "Transformación de energía luminosa", explanation: "La fuente describe esa transformación.", sourceQuote: quote }],
    flashcards: [], cards: [{ id: "card1", front: "¿Qué transforma la fotosíntesis?", back: "Energía luminosa en energía química.", sourceQuote: quote }],
    shortAnswer: [], ordering: [], diagramLabels: [], followUps: [], history: [], failedQuestionIds: [], failedPairIds: [], spacedRepetition: {}, sessions: [],
  };
  return { v: 4, subjects: [{ id: "subject-1", name: "Biología", classes: [{ id: "class-1", name: "Fotosíntesis", notes: sourceText, studyKits: [kit] }] }] };
}

describe("compatibilidad de formatos legacy de Study Kit", () => {
  it("prefiere un alias con datos sobre un array canónico vacío y conserva un array canónico no vacío", () => {
    const compatibility = loadCompatibility();
    const normalized = compatibility.normalize({ multipleChoice: [], questions: [{ id: "legacy" }], trueFalse: [{ id: "canonical" }], trueFalseQuestions: [{ id: "legacy" }] });
    expect(normalized.multipleChoice).toEqual([{ id: "legacy" }]);
    expect(normalized.trueFalse).toEqual([{ id: "canonical" }]);
  });

  it("normaliza kits heredados de alternativa, V/F, pareados y tarjetas para render y sync", () => {
    const compatibility = loadCompatibility();
    const snapshot = legacySnapshot();
    const kit = snapshot.subjects[0].classes[0].studyKits[0];
    expect(validateStudyStatePayload(snapshot)).toBe(true);
    expect(compatibility.normalizeInPlace(kit)).toBe(true);
    expect(kit.multipleChoice).toHaveLength(1);
    expect(kit.trueFalse).toHaveLength(1);
    expect(kit.matchingPairs).toHaveLength(1);
    expect(kit.flashcards).toHaveLength(1);
    expect(validateStudyStatePayload(snapshot)).toBe(true);
    expect(validateStudyKitSnapshotIntegrity(null, snapshot, new Map())).toBe(true);
  });
});
