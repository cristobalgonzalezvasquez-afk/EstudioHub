import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { describe, expect, it } from "vitest";

const source = readFileSync(new URL("../client/public/studyhub-session-clock-v1.js", import.meta.url), "utf8");
type Clock = {
  syncServerNow: (serverNow: number, startedAt: number, receivedAt: number) => boolean;
  now: () => number | null;
  deadlineAfter: (durationMs: number) => number | null;
  remainingUntil: (deadline: number) => number | null;
  remainingMs: (session: Record<string, unknown>) => number | null;
  isReady: () => boolean;
};
type TestWindow = { performance: { now: () => number }; civilClock: number; StudyKitSessionClock?: Clock };
function client(civilClock: number) {
  let monotonic = 1_000;
  const windowState: TestWindow = { performance: { now: () => monotonic }, civilClock };
  runInNewContext(source, { window: windowState, Date: { now: () => windowState.civilClock } });
  const clock = windowState.StudyKitSessionClock as Clock;
  return {
    clock,
    advanceMonotonic(ms: number) { monotonic += ms; },
    setCivilClock(value: number) { windowState.civilClock = value; },
  };
}

const serverTime = 1_792_100_000_000;

describe("Study Kit server session clock", () => {
  it("da el mismo tiempo restante en dispositivos con relojes civiles distintos", () => {
    const saved = { status: "active", timestampBasis: "server", updatedAt: serverTime, remainingMs: 60_000 };
    const deviceA = client(serverTime - 86_400_000);
    const deviceB = client(serverTime + 172_800_000);
    expect(deviceA.clock.syncServerNow(serverTime, 900, 1_100)).toBe(true);
    expect(deviceB.clock.syncServerNow(serverTime, 900, 1_100)).toBe(true);
    deviceA.advanceMonotonic(10_000);
    deviceB.advanceMonotonic(10_000);
    deviceA.setCivilClock(serverTime + 900_000_000);
    deviceB.setCivilClock(serverTime - 900_000_000);
    expect(deviceA.clock.remainingMs(saved)).toBe(50_000);
    expect(deviceB.clock.remainingMs(saved)).toBe(50_000);
  });

  it("crea, muestra y expira un deadline usando solo el avance monotónico anclado al servidor", () => {
    const device = client(99_999_999_999_999);
    expect(device.clock.deadlineAfter(60_000)).toBeNull();
    expect(device.clock.syncServerNow(serverTime, 900, 1_100)).toBe(true);
    const deadline = device.clock.deadlineAfter(60_000)!;
    expect(deadline).toBe(serverTime + 60_000);
    device.advanceMonotonic(25_000);
    device.setCivilClock(1);
    expect(device.clock.remainingUntil(deadline)).toBe(35_000);
    device.advanceMonotonic(40_000);
    expect(device.clock.remainingUntil(deadline)).toBe(0);
  });

  it("falla cerrado si falta el ancla y pausa sesiones legacy sin descontar tiempo local", () => {
    const device = client(10_000_000_000);
    const activeServer = { status: "active", timestampBasis: "server", updatedAt: serverTime, remainingMs: 30_000 };
    const activeLegacy = { status: "active", updatedAt: 1_000, remainingMs: 30_000 };
    expect(device.clock.now()).toBeNull();
    expect(device.clock.remainingUntil(serverTime + 30_000)).toBeNull();
    expect(device.clock.deadlineAfter(30_000)).toBeNull();
    expect(device.clock.remainingMs(activeServer)).toBeNull();
    expect(device.clock.remainingMs(activeLegacy)).toBeNull();
    expect(device.clock.remainingMs({ status: "paused", remainingMs: 30_000 })).toBe(30_000);
  });

  it("rechaza timestamps inválidos o solicitudes con orden temporal imposible", () => {
    const device = client(0);
    expect(device.clock.syncServerNow(Number.NaN, 900, 1_100)).toBe(false);
    expect(device.clock.syncServerNow(serverTime, 1_100, 900)).toBe(false);
    expect(device.clock.isReady()).toBe(false);
    expect(device.clock.now()).toBeNull();
  });
});
