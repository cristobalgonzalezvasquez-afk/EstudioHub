import { createHash, webcrypto } from "node:crypto";
import { readFile } from "node:fs/promises";
import { runInNewContext } from "node:vm";
import { beforeAll, describe, expect, it } from "vitest";

let clientSource = "";
beforeAll(async () => {
  clientSource = await readFile(new URL("../client/public/studyhub-cloud-v20.js", import.meta.url), "utf8");
});

function sha256(bytes: Buffer): string {
  return createHash("sha256").update(bytes).digest("hex");
}

type TestFileStore = {
  get: (key: string) => Promise<Blob | undefined>;
  put: (key: string, blob: Blob) => Promise<void>;
};

function createTestClient(fetcher: typeof fetch, fileStore: TestFileStore = { get: async () => undefined, put: async () => undefined }) {
  const window: Record<string, any> = { __ESTUDIOHUB_CLOUD_TEST_MODE__: true };
  const context = {
    window,
    document: { getElementById: () => null },
    navigator: { onLine: true },
    appData: {},
    FS: fileStore,
    fetch: fetcher,
    Headers,
    AbortSignal,
    Blob,
    Response,
    crypto: webcrypto,
    TextEncoder,
    setTimeout,
    clearTimeout,
  };
  runInNewContext(clientSource, context, { filename: "studyhub-cloud-v20.js" });
  const hooks = window.__ESTUDIOHUB_CLOUD_TEST_HOOKS__;
  if (!hooks) throw new Error("No se registró el adaptador de pruebas v20.");
  hooks.authorizeTestUser();
  return { hooks: hooks as any, window };
}

const remoteKey = "f_synthetic_1";

describe("studyhub-cloud-v20 download integrity", () => {
  it("acepta el blob íntegro aunque el ETag débil difiera; usa el SHA del contenido como decisión final", async () => {
    const bytes = Buffer.from("contenido privado sintético íntegro", "utf8");
    const checksum = sha256(bytes);
    const differentEtag = "a".repeat(64);
    const fetcher: typeof fetch = async (_input, init) => {
      if (init?.method === "HEAD") {
        return new Response(null, { status: 200, headers: { ETag: `W/"${differentEtag.toUpperCase()}"`, "X-Content-Checksum": checksum } });
      }
      return new Response(bytes, { status: 200, headers: { ETag: `W/"${differentEtag}"`, "X-Content-Checksum": checksum } });
    };
    const { hooks } = createTestClient(fetcher);
    expect(hooks.normalizeCloudChecksum(`W/"${checksum.toUpperCase()}"`)).toBe(checksum);
    const blob = await hooks.downloadCloudFile(remoteKey, { checksum, fileName: "apunte.pdf" });
    expect(sha256(Buffer.from(await blob.arrayBuffer()))).toBe(checksum);
  });

  it("rechaza un SHA distinto, no escribe ni descarta copias y permite un nuevo intento manual", async () => {
    const registeredBytes = Buffer.from("contenido cloud registrado", "utf8");
    const badBytes = Buffer.from("respuesta transformada que no corresponde", "utf8");
    const checksum = sha256(registeredBytes);
    const saved = new Map<string, Blob>();
    const store: TestFileStore = {
      get: async key => saved.get(key),
      put: async (key, blob) => { saved.set(key, blob); },
    };
    let currentBody = badBytes;
    const remote = { localKey: remoteKey, fileName: "respaldo.pdf", mimeType: "application/pdf", size: registeredBytes.length, checksum };
    const fetcher: typeof fetch = async (input, init) => {
      if (String(input) === "/api/files") return new Response(JSON.stringify({ files: [remote] }), { status: 200, headers: { "Content-Type": "application/json" } });
      if (init?.method === "HEAD") return new Response(null, { status: 200, headers: { ETag: `W/"${checksum}"`, "X-Content-Checksum": checksum } });
      return new Response(currentBody, { status: 200, headers: { "X-Content-Checksum": checksum } });
    };
    const { hooks, window } = createTestClient(fetcher, store);
    const target = {};
    const other = { files: [{ key: remoteKey, name: "respaldo.pdf" }] };
    window.collectFileRefs = (value: unknown) => value === other ? [remoteKey] : [];

    await expect(hooks.preserveSnapshotFileCopies(target, other, "prueba")).rejects.toMatchObject({
      code: "CLOUD_FILE_CHECKSUM_MISMATCH",
      retryable: false,
    });
    expect(saved.size).toBe(0);

    currentBody = registeredBytes;
    await hooks.preserveSnapshotFileCopies(target, other, "reintento manual");
    expect(saved.size).toBe(1);
    expect(sha256(Buffer.from(await saved.get(remoteKey)!.arrayBuffer()))).toBe(checksum);
  });

  it("reintenta una descarga tras una respuesta transitoria y acepta el SHA correcto", async () => {
    const bytes = Buffer.from("descarga recuperada en el segundo intento", "utf8");
    const checksum = sha256(bytes);
    let getCalls = 0;
    const fetcher: typeof fetch = async (_input, init) => {
      if (init?.method === "HEAD") return new Response(null, { status: 200, headers: { ETag: `"${checksum}"`, "X-Content-Checksum": checksum } });
      getCalls += 1;
      if (getCalls === 1) return new Response(null, { status: 503, headers: { "Retry-After": "0" } });
      return new Response(bytes, { status: 200, headers: { "X-Content-Checksum": checksum } });
    };
    const { hooks } = createTestClient(fetcher);
    const blob = await hooks.downloadCloudFile(remoteKey, { checksum, fileName: "material.pdf" });
    expect(getCalls).toBe(2);
    expect(sha256(Buffer.from(await blob.arrayBuffer()))).toBe(checksum);
  });
});
