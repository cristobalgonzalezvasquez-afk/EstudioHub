import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";
import { mapWithConcurrency, prepareStudyMaterials, StudyMaterialError, type StudyPrivateFile } from "./study-material";

function privateFile(fileName: string, mimeType: string, content: Buffer, localKey = "f_synthetic_1"): StudyPrivateFile {
  return { localKey, fileName, mimeType, size: content.length, checksum: createHash("sha256").update(content).digest("hex"), content };
}

const validateFile = (_name: string, declaredType: string) => declaredType.split(";")[0].toLowerCase();

function syntheticPdf(pageTexts: string[]): Buffer {
  const objects: string[] = [];
  const add = (value: string) => { objects.push(value); return objects.length; };
  const catalogId = add("<< /Type /Catalog /Pages 2 0 R >>");
  const pagesId = add("<< /Type /Pages /Kids [] /Count 0 >>");
  const fontId = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  const kids: string[] = [];
  for (const text of pageTexts) {
    const pageId = objects.length + 1;
    const contentId = pageId + 1;
    const lineOps = (text.match(/.{1,70}/g) ?? []).map(line => `(${line.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)")}) Tj T*`).join("\n");
    const stream = text ? `BT /F1 8 Tf 10 TL 20 760 Td\n${lineOps}\nET\n` : "20 20 100 100 re S\n";
    add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 ${fontId} 0 R >> >> /Contents ${contentId} 0 R >>`);
    add(`<< /Length ${Buffer.byteLength(stream, "latin1")} >>\nstream\n${stream}endstream`);
    kids.push(`${pageId} 0 R`);
  }
  objects[pagesId - 1] = `<< /Type /Pages /Kids [${kids.join(" ")}] /Count ${kids.length} >>`;
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(Buffer.byteLength(pdf, "latin1"));
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = Buffer.byteLength(pdf, "latin1");
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let index = 1; index < offsets.length; index += 1) pdf += `${String(offsets[index]).padStart(10, "0")} 00000 n \n`;
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  return Buffer.from(pdf, "latin1");
}

describe("mapWithConcurrency", () => {
  it("preserves result order and never exceeds the requested concurrency", async () => {
    let active = 0;
    let peak = 0;
    const results = await mapWithConcurrency([1, 2, 3, 4, 5], 2, async value => {
      active += 1;
      peak = Math.max(peak, active);
      await new Promise(resolve => setTimeout(resolve, 2));
      active -= 1;
      return value * 2;
    });
    expect(results).toEqual([2, 4, 6, 8, 10]);
    expect(peak).toBe(2);
  });
});

describe("prepareStudyMaterials", () => {
  it("sends the selected PDF bytes directly to Gemini and keeps extracted text only for server-side evidence checks", async () => {
    const pdf = Buffer.from("%PDF-1.7\nSynthetic visual study material\n%%EOF\n", "ascii");
    const prepared = await prepareStudyMaterials({ sourceText: "", files: [privateFile("clase.pdf", "application/pdf", pdf)], fileLabels: [{ fileKey: "f_synthetic_1", sourceId: "S1", label: "Biología · Clase 1" }], validateFile });
    const inline = prepared.parts.find(part => "inline_data" in part);
    expect(inline && "inline_data" in inline ? inline.inline_data.mime_type : "").toBe("application/pdf");
    expect(inline && "inline_data" in inline ? Buffer.from(inline.inline_data.data, "base64") : Buffer.alloc(0)).toEqual(pdf);
    expect(prepared.sourceFiles[0]).toMatchObject({ sourceId: "S1", convertedToPdf: false, fileKey: "f_synthetic_1" });
  });

  it("retains literal PDF evidence after the former 100,000-character cutoff and indexes pages", async () => {
    const marker = "DOMINIO_LITERAL_DESPUES_DE_CIEN_MIL_CARACTERES";
    const longText = `Inicio del documento. ${"contenido de referencia ".repeat(5_000)}${marker}`;
    const pages = Array.from({ length: Math.ceil(longText.length / 3_000) }, (_, index) => longText.slice(index * 3_000, (index + 1) * 3_000));
    const pdf = syntheticPdf(pages);
    const prepared = await prepareStudyMaterials({ sourceText: "", files: [privateFile("dominio-largo.pdf", "application/pdf", pdf)], validateFile });
    expect(prepared.sourceFiles[0].evidenceText).toContain(marker);
    expect(prepared.sourceFiles[0].evidencePages?.some(page => page.includes(marker))).toBe(true);
    const inline = prepared.parts.find(part => "inline_data" in part);
    expect(inline && "inline_data" in inline ? Buffer.from(inline.inline_data.data, "base64") : Buffer.alloc(0)).toEqual(pdf);
  });

  it("keeps page boundaries so a mixed PDF can identify a page without extractable text", async () => {
    const pdf = syntheticPdf(["Pagina uno contiene una definicion que puede citarse literalmente.", ""]);
    const prepared = await prepareStudyMaterials({ sourceText: "", files: [privateFile("mixto.pdf", "application/pdf", pdf)], validateFile });
    expect(prepared.sourceFiles[0].textEvidenceAvailable).toBe(true);
    expect(prepared.sourceFiles[0].evidencePages?.[0]).toContain("definicion");
    expect(prepared.sourceFiles[0].evidencePages).toHaveLength(2);
    expect(prepared.sourceFiles[0].evidencePages?.[1].trim()).toBe("");
  });

  it("sends selected images as their original bytes without running browser OCR", async () => {
    const image = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/Z3sAAAAASUVORK5CYII=", "base64");
    const prepared = await prepareStudyMaterials({ sourceText: "", files: [privateFile("foto.png", "image/png", image)], validateFile });
    const inline = prepared.parts.find(part => "inline_data" in part);
    expect(inline && "inline_data" in inline ? inline.inline_data.mime_type : "").toBe("image/png");
    expect(inline && "inline_data" in inline ? Buffer.from(inline.inline_data.data, "base64") : Buffer.alloc(0)).toEqual(image);
  });

  it("converts DOCX and XLSX to visual PDFs in an isolated server process", async () => {
    for (const [name, mimeType, expectedText] of [
      ["minimal.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "Word a PDF"],
      ["minimal.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Excel a PDF"],
    ] as const) {
      const bytes = await readFile(new URL(`./fixtures/${name}`, import.meta.url));
      const file = privateFile(name, mimeType, bytes, `f_${name.replace(/\W/g, "_")}`);
      const prepared = await prepareStudyMaterials({ sourceText: "", files: [file], fileLabels: [{ fileKey: file.localKey, sourceId: "S1", label: "Finanzas · Clase 2" }], validateFile });
      const inline = prepared.parts.find(part => "inline_data" in part);
      expect(inline && "inline_data" in inline ? inline.inline_data.mime_type : "").toBe("application/pdf");
      expect(inline && "inline_data" in inline ? Buffer.from(inline.inline_data.data, "base64").subarray(0, 5).toString("ascii") : "").toBe("%PDF-");
      expect(prepared.sourceFiles[0]).toMatchObject({ originalMimeType: mimeType, mimeType: "application/pdf", convertedToPdf: true, textEvidenceAvailable: true });
      expect(prepared.evidenceText).toContain(expectedText);
    }
  }, 60_000);

  it("keeps selected text-file provenance and passes the contents as text", async () => {
    const text = Buffer.from("La tasa de interés compuesto acumula la capitalización por períodos sucesivos.", "utf8");
    const prepared = await prepareStudyMaterials({ sourceText: "", files: [privateFile("apunte.txt", "text/plain; charset=utf-8", text)], validateFile });
    expect(prepared.parts.some(part => "text" in part && part.text.includes("La tasa de interés compuesto"))).toBe(true);
    expect(prepared.parts.some(part => "inline_data" in part)).toBe(false);
    expect(prepared.sourceFiles[0]).toMatchObject({ fileKey: "f_synthetic_1", textEvidenceAvailable: true, convertedToPdf: false });
    expect(prepared.sourceNames).toContain("Material de clase · apunte.txt");
  });

  it("explains file-count and unsupported-format errors before calling Gemini", async () => {
    const files = Array.from({ length: 9 }, (_, i) => privateFile(`f${i}.png`, "image/png", Buffer.from([1]), `f_${i}`));
    await expect(prepareStudyMaterials({ sourceText: "", files, validateFile })).rejects.toMatchObject({ status: 413 });
    await expect(prepareStudyMaterials({ sourceText: "", files: [privateFile("macro.pptm", "application/octet-stream", Buffer.from("x"))], validateFile })).rejects.toBeInstanceOf(StudyMaterialError);
  });
});
