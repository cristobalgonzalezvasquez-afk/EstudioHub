import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { describe, expect, it } from "vitest";

const source = readFileSync(new URL("../client/public/studyhub-sync-merge.js", import.meta.url), "utf8");
const context: { window: Record<string, unknown> } = { window: {} };
runInNewContext(source, context);
const merge3 = (context.window.StudyHubSyncMerge as { merge3: (...args: unknown[]) => { value: unknown; conflicts: string[] } }).merge3;
const normalized = (value: unknown) => JSON.parse(JSON.stringify(value));

describe("StudyHubSyncMerge.merge3", () => {
  it("combina automáticamente cambios de campos distintos", () => {
    const result = merge3(
      { title: "base", notes: "base", settings: { theme: "light" } },
      { title: "local", notes: "base", settings: { theme: "light" } },
      { title: "base", notes: "cloud", settings: { theme: "dark" } },
    );
    expect(normalized(result.value)).toEqual({ title: "local", notes: "cloud", settings: { theme: "dark" } });
    expect(result.conflicts).toEqual([]);
  });

  it("elige el valor cloud ya confirmado en un campo modificado en ambos dispositivos", () => {
    const result = merge3({ notes: "base" }, { notes: "edición offline" }, { notes: "versión cloud confirmada" });
    expect(normalized(result.value)).toEqual({ notes: "versión cloud confirmada" });
    expect(result.conflicts).toEqual(["/notes"]);
  });

  it("fusiona listas por ID sin duplicar registros y conserva el valor cloud del mismo campo", () => {
    const result = merge3(
      { subjects: [{ id: "s1", name: "Economía", color: "azul" }] },
      { subjects: [{ id: "s1", name: "Economía local", color: "azul" }, { id: "s2", name: "Contabilidad" }] },
      { subjects: [{ id: "s1", name: "Economía cloud", color: "verde" }] },
    );
    expect(normalized(result.value)).toEqual({ subjects: [{ id: "s1", name: "Economía cloud", color: "verde" }, { id: "s2", name: "Contabilidad" }] });
    expect(result.conflicts).toEqual(["/subjects/s1/name"]);
  });

  it("usa la lista cloud si una lista sin IDs tiene cambios incompatibles", () => {
    const result = merge3({ tags: ["base"] }, { tags: ["local"] }, { tags: ["cloud"] });
    expect(normalized(result.value)).toEqual({ tags: ["cloud"] });
    expect(result.conflicts).toEqual(["/tags"]);
  });

  it("simula la reanudación de una misma sesión con respuestas locales y tiempo cloud", () => {
    const base = { subjects: [{ id: "s1", classes: [{ id: "c1", studyKits: [{ id: "k1", sessions: [{ id: "session-1", index: 1, remainingMs: 60_000, updatedAt: 1_792_100_000_000, answers: { q1: { userAnswer: "A" } } }] }] }] }] };
    const deviceA = structuredClone(base);
    const deviceB = structuredClone(base);
    deviceA.subjects[0].classes[0].studyKits[0].sessions[0].answers.q1.userAnswer = "B";
    deviceB.subjects[0].classes[0].studyKits[0].sessions[0].index = 2;
    deviceB.subjects[0].classes[0].studyKits[0].sessions[0].remainingMs = 45_000;
    deviceB.subjects[0].classes[0].studyKits[0].sessions[0].updatedAt += 15_000;
    const result = merge3(base, deviceA, deviceB);
    expect(result.conflicts).toEqual([]);
    expect(normalized(result.value)).toEqual({ subjects: [{ id: "s1", classes: [{ id: "c1", studyKits: [{ id: "k1", sessions: [{ id: "session-1", index: 2, remainingMs: 45_000, updatedAt: 1_792_100_015_000, answers: { q1: { userAnswer: "B" } } }] }] }] }] });
  });

  it("devuelve un conflicto explícito en vez de colapsar IDs duplicados", () => {
    const local = { kits: [{ id: "kit-1", title: "local" }, { id: "kit-1", title: "duplicado" }] };
    const remote = { kits: [{ id: "kit-1", title: "cloud" }] };
    const result = merge3({ kits: [{ id: "kit-1", title: "base" }] }, local, remote);
    expect(result.conflicts).toContain("/kits/(duplicate-id)");
    expect(normalized(result.value)).toEqual(remote);
    expect(local.kits).toHaveLength(2);
  });

  it("fusiona referencias de archivos por key cuando no tienen id", () => {
    const result = merge3(
      { files: [{ key: "f1", label: "base" }] },
      { files: [{ key: "f1", label: "local" }] },
      { files: [{ key: "f1", label: "cloud" }] },
    );
    expect(normalized(result.value)).toEqual({ files: [{ key: "f1", label: "cloud" }] });
    expect(result.conflicts).toEqual(["/files/key:f1/label"]);
  });
});
