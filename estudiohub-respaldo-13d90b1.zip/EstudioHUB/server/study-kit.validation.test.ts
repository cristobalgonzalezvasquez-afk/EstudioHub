import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { prepareStudyMaterials } from "./study-material";
import { computeStudyKitCounts, diagnoseStudyKitSnapshotIntegrity, hasConfirmedCloudSnapshot, normalizeStudyKitResponse, normalizeStudyKitFollowUpForStorage, studyKitFrozenFileSelectionMatches, studyKitLegacyFileSelectionMismatchFields, snapQuoteToEvidence, resolveStudyMaterialSelection, studyKitGenerationFailure, studyKitProofFieldHashes, studyKitProofFieldOperationId, studyKitProofOperationRows, studyKitProofHash, studyKitProofRevisionMatches, validatePrivateFilePayload, studyKitProofIdsNeedingValidation, STUDY_KIT_FORMATS, validAdaptiveAnswer, validateStudyKitGeneration, validateStudyKitSnapshotIntegrity, validateStudyStatePayload } from "./studyhub";

const source = "La fotosíntesis transforma la energía luminosa en energía química y ocurre principalmente en los cloroplastos de las células vegetales.";
const serverTime = 1_792_100_000_000;

function validKit() {
  const plan = computeStudyKitCounts(["multipleChoice"], 5, false, false);
  if (!plan.ok) throw new Error("test plan");
  return {
    plan,
    kit: {
      title: "Guía de fotosíntesis",
      difficulty: "Intermedio",
      studyGuide: {
        summary: "La fotosíntesis transforma la energía luminosa en energía química dentro de las células vegetales.",
        keyPoints: ["Usa energía luminosa", "Produce energía química", "Ocurre en cloroplastos"],
        glossary: [
          { term: "Fotosíntesis", definition: "Proceso que transforma energía luminosa.", sourceQuote: "La fotosíntesis transforma la energía luminosa" },
          { term: "Cloroplasto", definition: "Estructura principal de las células vegetales.", sourceQuote: "ocurre principalmente en los cloroplastos" },
          { term: "Energía química", definition: "Forma de energía producida por el proceso.", sourceQuote: "en energía química y ocurre principalmente" },
        ],
        questions: ["¿Qué transforma la fotosíntesis?", "¿Dónde ocurre principalmente?", "¿Qué tipo de energía produce?"],
        sourceQuote: "La fotosíntesis transforma la energía luminosa en energía química",
        podcastScript: "",
      },
      multipleChoice: Array.from({ length: 5 }, (_, index) => ({
        id: `q${index + 1}`,
        question: "¿Qué transforma la fotosíntesis?",
        topic: "Fotosíntesis",
        options: ["La energía luminosa", "El agua", "El sonido", "La gravedad"],
        correctIndex: 0,
        explanations: ["La fuente lo indica claramente.", "No corresponde al proceso.", "No es una fuente de energía.", "No participa en la transformación."],
        sourceQuote: "La fotosíntesis transforma la energía luminosa",
      })),
      trueFalse: [],
      shortAnswer: [],
      matchingPairs: [],
      ordering: [],
      diagramLabels: [],
      flashcards: [],
    },
  };
}

function validStoredState() {
  const { kit } = validKit();
  return {
    v: 4,
    subjects: [{ id: "subject-1", name: "Biología", classes: [{ id: "class-1", name: "Fotosíntesis", notes: source, trainingText: source, studyKits: [{
      ...structuredClone(kit), id: "kit-1", createdAt: "2026-10-15T00:00:00.000Z", sourceLength: source.length,
      sourceText: `[Biología · Fotosíntesis · apuntes de clase]\n${source}`, sourceLabels: ["Biología · Fotosíntesis"], sourceClassIds: ["class-1"], sourceFiles: [] as any[], followUps: [], history: [], failedQuestionIds: [], failedPairIds: [], spacedRepetition: {},
      sessions: [{ id: "session-1", kitId: "kit-1", kind: "quiz", mode: "practice", status: "active", startedAt: serverTime - 10_000, updatedAt: serverTime, timestampBasis: "server", index: 0, remainingMs: 60_000, deadline: 0, questions: [{ id: "q1" }], answers: {}, drafts: {}, finished: false }],
    }] }] }],
  };
}

function fileReference(sourceId: string, fileKey: string, evidenceText: string) {
  return { sourceId, fileKey, name: `${sourceId}.txt`, label: `${sourceId} · apuntes`, mimeType: "text/plain; charset=utf-8", originalMimeType: "text/plain", size: evidenceText.length, checksum: "a".repeat(64), convertedToPdf: false, textEvidenceAvailable: true, evidenceText };
}

function pdfReference(sourceId: string, evidencePages: string[]) {
  const evidenceText = evidencePages.join("\f");
  return { ...fileReference(sourceId, `f_${sourceId}`, evidenceText), name: `${sourceId}.pdf`, mimeType: "application/pdf", originalMimeType: "application/pdf", textEvidenceAvailable: evidenceText.trim().length >= 12, evidenceText, evidencePages };
}

describe("computeStudyKitCounts", () => {
  it("distribuye exactamente el total entre modalidades y controla complementos", () => {
    const result = computeStudyKitCounts([...STUDY_KIT_FORMATS], 20, true, true);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(Object.values(result.counts).reduce((sum, value) => sum + value, 0)).toBe(20);
    expect(result.formats).toEqual([...STUDY_KIT_FORMATS]);
    expect(result.flashcardCount).toBe(5);
    expect(result.includePodcast).toBe(true);
  });

  it("rechaza cero modalidades y más modalidades que actividades", () => {
    expect(computeStudyKitCounts([], 5).ok).toBe(false);
    expect(computeStudyKitCounts(["multipleChoice", "trueFalse", "shortAnswer", "ordering", "matchingPairs", "diagramLabels"], 5).ok).toBe(false);
  });
});

describe("validateStudyKitGeneration", () => {
  it("acepta un kit con cantidades exactas y citas literales", () => {
    const { kit, plan } = validKit();
    expect(validateStudyKitGeneration(kit, source, plan)).toBe(true);
  });

  it("rechaza cantidades incorrectas y citas que no aparecen en el material", () => {
    const { kit, plan } = validKit();
    kit.multipleChoice.pop();
    expect(validateStudyKitGeneration(kit, source, plan)).toBe(false);

    const valid = validKit();
    valid.kit.multipleChoice[0].sourceQuote = "Esta frase no está en la fuente";
    expect(validateStudyKitGeneration(valid.kit, source, valid.plan)).toBe(false);
  });

  it("valida cada cita de archivo contra la evidencia de su propio sourceFileId", () => {
    const { kit, plan } = validKit();
    const files = [
      fileReference("S1", "f_clase_uno", "La clorofila absorbe energía luminosa.") ,
      fileReference("S2", "f_clase_dos", "La mitocondria produce energía para la célula."),
    ];
    kit.multipleChoice[0].sourceQuote = "La mitocondria produce energía";
    (kit.multipleChoice[0] as any).sourceFileId = "S1";
    expect(validateStudyKitGeneration(kit, source, plan, files)).toBe(false);
    (kit.multipleChoice[0] as any).sourceFileId = "S2";
    expect(validateStudyKitGeneration(kit, source, plan, files)).toBe(true);
  });
});

describe("normalizeStudyKitResponse", () => {
  it("normaliza arrays no seleccionados y metadatos opcionales cuando la cita coincide con un solo archivo", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    const files = [fileReference("S1", "f_unico", source)];
    for (const format of STUDY_KIT_FORMATS) if ((plan.counts[format] ?? 0) === 0) delete candidate[format];
    candidate.diagramLabels = [{ question: "No solicitado", sourceQuote: "No usar" }];
    candidate.flashcards = [{ front: "No solicitada", back: "Descartable" }];
    candidate.studyGuide.podcastScript = "Gemini incluyó un guion que el usuario no pidió.";
    const citationItems = [candidate.studyGuide, ...candidate.studyGuide.glossary, ...candidate.multipleChoice];
    for (const item of citationItems) { item.sourceFileId = null; item.sourcePage = null; }

    const normalized = normalizeStudyKitResponse(candidate, plan, files);
    expect(normalized).not.toBeNull();
    expect(normalized?.trueFalse).toEqual([]);
    expect(normalized?.matchingPairs).toEqual([]);
    expect(normalized?.diagramLabels).toEqual([]);
    expect(normalized?.flashcards).toEqual([]);
    expect(normalized?.studyGuide.podcastScript).toBe("");
    expect(normalized?.multipleChoice[0].sourceFileId).toBe("S1");
    expect(normalized?.multipleChoice[0].sourcePage).toBeUndefined();
    expect(studyKitGenerationFailure(normalized, "", plan, files)).toBeNull();
  });

  it("no rellena modalidades solicitadas incompletas y explica el conteo esperado", () => {
    const { kit, plan } = validKit();
    kit.multipleChoice.pop();
    const normalized = normalizeStudyKitResponse(kit, plan, []);
    expect(normalized?.multipleChoice).toHaveLength(4);
    expect(studyKitGenerationFailure(normalized, source, plan)).toMatch(/4 actividades.*se esperaban 5/);
  });

  it("recorta solo actividades excedentes para ajustarse al total solicitado", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    candidate.multipleChoice.push(...structuredClone(candidate.multipleChoice.slice(0, 3)).map((item: any, index: number) => ({ ...item, id: `extra-${index}` })));
    const normalized = normalizeStudyKitResponse(candidate, plan, []);
    expect(normalized?.multipleChoice).toHaveLength(5);
    expect(studyKitGenerationFailure(normalized, source, plan)).toBeNull();
  });

  it("repara IDs de actividad duplicados sin alterar su contenido ni sus citas", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    candidate.multipleChoice[2].id = candidate.multipleChoice[0].id;
    const normalized = normalizeStudyKitResponse(candidate, plan, [], source);
    const ids = normalized?.multipleChoice.map((item: any) => item.id) ?? [];
    expect(new Set(ids).size).toBe(5);
    expect(studyKitGenerationFailure(normalized, source, plan)).toBeNull();
  });

  it("no asigna una cita si aparece en varios archivos seleccionados", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    const files = [fileReference("S1", "f_uno", source), fileReference("S2", "f_dos", source)];
    for (const item of [candidate.studyGuide, ...candidate.studyGuide.glossary, ...candidate.multipleChoice]) delete item.sourceFileId;
    const normalized = normalizeStudyKitResponse(candidate, plan, files);
    expect(normalized?.multipleChoice[0].sourceFileId).toBeUndefined();
    expect(studyKitGenerationFailure(normalized, "", plan, files)).toMatch(/cita/);
  });

  it("quita sourcePage=1 de citas literales de apuntes, aunque el modelo lo devuelva por defecto", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    const citationItems = [candidate.studyGuide, ...candidate.studyGuide.glossary, ...candidate.multipleChoice];
    for (const item of citationItems) item.sourcePage = 1;
    const normalized = normalizeStudyKitResponse(candidate, plan, [], source);
    expect(citationItems.every(item => item.sourcePage === 1)).toBe(true);
    expect(normalized?.studyGuide.sourcePage).toBeUndefined();
    expect(normalized?.multipleChoice.every((item: any) => item.sourcePage === undefined)).toBe(true);
    expect(studyKitGenerationFailure(normalized, source, plan)).toBeNull();
  });

  it("reasigna un ID incorrecto solo cuando la cita literal identifica un archivo único", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    const files = [fileReference("S1", "f_unico", source), fileReference("S2", "f_otro", "La mitocondria produce energía para la célula.")];
    for (const item of [candidate.studyGuide, ...candidate.studyGuide.glossary, ...candidate.multipleChoice]) item.sourceFileId = "S2";
    const normalized = normalizeStudyKitResponse(candidate, plan, files);
    expect(normalized?.studyGuide.sourceFileId).toBe("S1");
    expect(normalized?.multipleChoice.every((item: any) => item.sourceFileId === "S1")).toBe(true);
    expect(studyKitGenerationFailure(normalized, "", plan, files)).toBeNull();
  });

  it("señala la primera modalidad y actividad cuya cita no coincide", () => {
    const { kit, plan } = validKit();
    kit.multipleChoice[0].sourceQuote = "Una cita que no aparece en la fuente";
    expect(studyKitGenerationFailure(kit, source, plan)).toMatch(/actividad 1 de alternativas/);
  });

  it("señala la actividad exacta y el campo estructural incompleto", () => {
    const { kit, plan } = validKit();
    const missingExplanation = structuredClone(kit) as any;
    missingExplanation.multipleChoice[2].explanations = ["Solo hay una explicación"];
    expect(studyKitGenerationFailure(missingExplanation, source, plan)).toMatch(/actividad 3 de alternativas.*explicar cada opción/);

    const duplicateId = structuredClone(kit) as any;
    duplicateId.multipleChoice[2].id = "q1";
    expect(studyKitGenerationFailure(duplicateId, source, plan)).toMatch(/actividad 3 de alternativas.*identificador interno/);
  });

  it("permite evidencia visual solo en una página sin texto de un PDF mixto y rechaza paráfrasis en páginas textuales", () => {
    const { kit, plan } = validKit();
    const pageOne = "El dominio de una funcion es el conjunto de valores de entrada permitidos.";
    const file = pdfReference("S1", [pageOne, ""]);
    const citations = [kit.studyGuide, ...kit.studyGuide.glossary, ...kit.multipleChoice];
    for (const item of citations) { item.sourceQuote = pageOne; (item as any).sourceFileId = "S1"; (item as any).sourcePage = 1; }
    kit.studyGuide.sourceQuote = "El diagrama muestra la relacion entre dos conjuntos";
    (kit.studyGuide as any).sourcePage = 2;
    const normalized = normalizeStudyKitResponse(kit, plan, [file]);
    expect(studyKitGenerationFailure(normalized, "", plan, [file])).toBeNull();

    const paraphrase = structuredClone(normalized) as any;
    paraphrase.studyGuide.sourceQuote = "El dominio comprende las entradas permitidas de la funcion";
    paraphrase.studyGuide.sourcePage = 1;
    expect(studyKitGenerationFailure(paraphrase, "", plan, [file])).toMatch(/no coincide literalmente con la página 1 del PDF/);
  });

  it("corrige sourcePage solo cuando una cita literal identifica una única página del PDF", () => {
    const { kit, plan } = validKit();
    const file = pdfReference("S1", ["Contenido de la primera pagina sin la cita.", source]);
    const citations = [kit.studyGuide, ...kit.studyGuide.glossary, ...kit.multipleChoice];
    for (const item of citations) { item.sourceQuote = source; (item as any).sourceFileId = "S1"; (item as any).sourcePage = 1; }
    const normalized = normalizeStudyKitResponse(kit, plan, [file]);
    expect(normalized?.studyGuide.sourcePage).toBe(2);
    expect(normalized?.multipleChoice.every((item: any) => item.sourcePage === 2)).toBe(true);
    expect(studyKitGenerationFailure(normalized, "", plan, [file])).toBeNull();
  });

  it("acepta una cita visual de PDF sin sourcePage cuando el texto extraído no permite cotejarla", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    const textFile = fileReference("S1", "f_escaneado", "");
    const visualFile = { ...textFile, name: "escaneado.pdf", mimeType: "application/pdf", originalMimeType: "application/pdf", textEvidenceAvailable: true, evidencePages: ["Texto distinto a la cita generada."] };
    const citationItems = [candidate.studyGuide, ...candidate.studyGuide.glossary, ...candidate.multipleChoice];
    for (const item of citationItems) { item.sourceFileId = "S1"; item.sourcePage = null; }
    const normalized = normalizeStudyKitResponse(candidate, plan, [visualFile]);
    expect(studyKitGenerationFailure(normalized, "", plan, [visualFile])).toBeNull();
  });

  it("mantiene el rechazo textual estricto si falta evidencePages y hay texto extraíble", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    const textFile = { ...fileReference("S1", "f_texto", "Texto extraído que no coincide con el contenido citado."), name: "texto.pdf", mimeType: "application/pdf", originalMimeType: "application/pdf", textEvidenceAvailable: true };
    const citationItems = [candidate.studyGuide, ...candidate.studyGuide.glossary, ...candidate.multipleChoice];
    for (const item of citationItems) { item.sourceFileId = "S1"; delete item.sourcePage; }
    const normalized = normalizeStudyKitResponse(candidate, plan, [textFile]);
    expect(studyKitGenerationFailure(normalized, "", plan, [textFile])).toMatch(/no coincide literalmente con el PDF indicado/);
  });
});

describe("Study Kit request and sync contracts", () => {
  it("acepta diagram-label answers solo cuando cada índice seleccionado es válido para su etiqueta", () => {
    const labels = [
      { prompt: "Etiqueta A", options: ["opción 1", "opción 2"], correctIndex: 1 },
      { prompt: "Etiqueta B", options: ["opción 1", "opción 2", "opción 3"], correctIndex: 0 },
    ];
    expect(validAdaptiveAnswer("diagramLabels", [1, 0], { labels })).toBe(true);
    expect(validAdaptiveAnswer("diagramLabels", [2, 0], { labels })).toBe(false);
    expect(validAdaptiveAnswer("diagramLabels", [1], { labels })).toBe(false);
    expect(validAdaptiveAnswer("multipleChoice", 3, {})).toBe(true);
  });

  it("resuelve texto y etiquetas desde las clases declaradas y rechaza archivos de otra clase", () => {
    const classOneFile = "f_clase_uno";
    const classTwoFile = "f_clase_dos";
    const snapshot = { v: 4, subjects: [{ id: "subject-1", name: "Biología", notes: "Apuntes del ramo: biología celular.", classes: [
      { id: "class-1", name: "Unidad uno", notes: "La célula contiene organelos.", key: "Núcleo y citoplasma", studyKitText: "Revisar la membrana celular.", studyKitSources: [{ id: "yt-1", type: "youtube", text: "Transcripción pública sobre la célula.", label: "Video de células" }, { id: "img-1", type: "image", text: "OCR heredado no debe usarse." }], files: [{ key: classOneFile, name: "celula.pdf" }] },
      { id: "class-2", name: "Unidad dos", notes: "Apuntes secretos de otra unidad.", files: [{ key: classTwoFile, name: "mitosis.pdf" }] },
    ] }] };
    const resolved = resolveStudyMaterialSelection(snapshot, ["class-1"], [classOneFile]);
    expect(resolved.sourceText).toContain("La célula contiene organelos.");
    expect(resolved.sourceText).toContain("Transcripción pública sobre la célula.");
    expect(resolved.sourceText).not.toContain("Apuntes secretos de otra unidad");
    expect(resolved.sourceText).not.toContain("OCR heredado");
    expect(resolved.sourceLabels).toEqual(["Biología · Unidad uno"]);
    expect(resolved.fileLabels).toEqual([{ fileKey: classOneFile, sourceId: "S1", label: "Biología · Unidad uno", name: "celula.pdf", legacyName: "celula.pdf" }]);
    expect(() => resolveStudyMaterialSelection(snapshot, ["class-1"], [classTwoFile])).toThrow(/no pertenece/);
    expect(() => resolveStudyMaterialSelection(snapshot, ["unknown-class"], [])).toThrow(/no pertenece/);
    expect(() => resolveStudyMaterialSelection(snapshot, ["class-1", "class-1"], [])).toThrow(/sin repetir/);
  });

  it("acepta Study Kit YouTube solo en campo cloud seguro e ignora OCR legado como fuente de IA", () => {
    const payload = {
      v: 4,
      subjects: [{ id: "subject-1", name: "Contabilidad", classes: [{ id: "class-1", name: "Unidad 1", studyKitSources: [
        { id: "image-1", label: "Foto de apuntes", type: "image", text: "Texto OCR de la foto." },
        { id: "youtube-1", label: "Video de apoyo", type: "youtube", text: "Transcripción del video." },
      ] }] }],
    };
    expect(validateStudyStatePayload(payload)).toBe(true);
    const invalid = structuredClone(payload);
    delete (invalid.subjects[0].classes[0].studyKitSources[0] as any).label;
    expect(validateStudyStatePayload(invalid)).toBe(false);
  });

  it("valida kits, sesiones y unicidad de IDs antes de aceptar snapshots cloud", () => {
    const payload = validStoredState();
    expect(validateStudyStatePayload(payload)).toBe(true);

    const invalidIndex = structuredClone(payload);
    (invalidIndex.subjects[0].classes[0].studyKits[0].multipleChoice[0] as any).correctIndex = 9;
    expect(validateStudyStatePayload(invalidIndex)).toBe(false);

    const missingCitation = structuredClone(payload);
    (missingCitation.subjects[0].classes[0].studyKits[0].multipleChoice[0] as any).sourceQuote = "";
    expect(validateStudyStatePayload(missingCitation)).toBe(false);

    const duplicateClasses = structuredClone(payload);
    duplicateClasses.subjects[0].classes[0].studyKits[0].sourceClassIds = ["class-1", "class-1"];
    expect(validateStudyStatePayload(duplicateClasses)).toBe(false);

    const duplicateSessions = structuredClone(payload);
    duplicateSessions.subjects[0].classes[0].studyKits[0].sessions.push(structuredClone(duplicateSessions.subjects[0].classes[0].studyKits[0].sessions[0]));
    expect(validateStudyStatePayload(duplicateSessions)).toBe(false);

    const badTimestamp = structuredClone(payload);
    badTimestamp.subjects[0].classes[0].studyKits[0].sessions[0].timestampBasis = "local";
    expect(validateStudyStatePayload(badTimestamp)).toBe(false);

    const duplicateSources = structuredClone(payload);
    const sourceFile = { sourceId: "S1", fileKey: "f_clase_uno", name: "Uno.txt", label: "Biología · Uno", mimeType: "text/plain", originalMimeType: "text/plain", size: 20, checksum: "b".repeat(64), convertedToPdf: false, textEvidenceAvailable: true };
    duplicateSources.subjects[0].classes[0].studyKits[0].sourceFiles = [sourceFile, { ...sourceFile }];
    expect(validateStudyStatePayload(duplicateSources)).toBe(false);

    const duplicateSubjects = structuredClone(payload);
    duplicateSubjects.subjects.push(structuredClone(duplicateSubjects.subjects[0]));
    expect(validateStudyStatePayload(duplicateSubjects)).toBe(false);

    const duplicateKits = structuredClone(payload);
    (duplicateKits.subjects[0].classes as any[]).push({ id: "class-2", name: "Otra unidad", notes: "", trainingText: "", studyKits: [structuredClone(duplicateKits.subjects[0].classes[0].studyKits[0])] });
    expect(validateStudyStatePayload(duplicateKits)).toBe(false);

    const duplicateFileKeys = structuredClone(payload);
    (duplicateFileKeys.subjects[0].classes[0] as any).files = [{ key: "f_clase_uno" }, { key: "f_clase_uno" }];
    expect(validateStudyStatePayload(duplicateFileKeys)).toBe(false);
  });
});

describe("Study Kit snapshot citation proofs", () => {
  it("preserves unchanged legacy kits and progress while rejecting changed text citations not present in selected notes", () => {
    const previous = validStoredState();
    const unchanged = structuredClone(previous);
    (unchanged.subjects[0].classes[0].studyKits[0].sessions[0].answers as Record<string, unknown>).q1 = { userAnswer: "A" };
    expect(validateStudyKitSnapshotIntegrity(previous, unchanged, new Map())).toBe(true);

    const forged = structuredClone(previous);
    forged.subjects[0].classes[0].studyKits[0].multipleChoice[0].sourceQuote = "Esta afirmación inventada no aparece aquí";
    expect(validateStudyStatePayload(forged)).toBe(true);
    expect(validateStudyKitSnapshotIntegrity(previous, forged, new Map())).toBe(false);
  });

  it("requires an owner-bound proof for changed file-backed kits and rejects citation tampering", () => {
    const snapshot = { v: 4, subjects: [{ id: "subject-1", name: "Biología", classes: [{ id: "class-1", name: "Unidad 1", notes: source, files: [{ key: "f_clase_uno", name: "uno.txt" }, { key: "f_clase_dos", name: "dos.txt" }] }] }] };
    const selection = resolveStudyMaterialSelection(snapshot, ["class-1"], ["f_clase_uno", "f_clase_dos"]);
    const { kit } = validKit();
    const proofId = "kitproof_abcdefghijklmnop123456";
    const fileKit = {
      ...structuredClone(kit), id: "kit-file-backed", createdAt: "2026-10-15T00:00:00.000Z", sourceText: selection.sourceText,
      sourceLabels: selection.sourceLabels, sourceClassIds: ["class-1"], sourceLength: source.length,
      sourceFiles: [
        { sourceId: "S1", fileKey: "f_clase_uno", name: "uno.txt", label: `${selection.fileLabels[0].label} · ${selection.fileLabels[0].name}`, mimeType: "text/plain", originalMimeType: "text/plain", size: source.length, checksum: "a".repeat(64), convertedToPdf: false, textEvidenceAvailable: true },
        { sourceId: "S2", fileKey: "f_clase_dos", name: "dos.txt", label: `${selection.fileLabels[1].label} · ${selection.fileLabels[1].name}`, mimeType: "text/plain", originalMimeType: "text/plain", size: 44, checksum: "b".repeat(64), convertedToPdf: false, textEvidenceAvailable: true },
      ],
      citationProofId: proofId, followUps: [], history: [], failedQuestionIds: [], failedPairIds: [], spacedRepetition: {}, sessions: [],
    };
    (fileKit.multipleChoice[0] as any).sourceFileId = "S1";
    const payload = { ...snapshot, subjects: [{ ...snapshot.subjects[0], classes: [{ ...snapshot.subjects[0].classes[0], studyKits: [fileKit] }] }] };
    const proof = new Map([[proofId, { payloadHash: studyKitProofHash(fileKit), fieldHashes: studyKitProofFieldHashes(fileKit) }]]);
    expect(validateStudyStatePayload(payload)).toBe(true);
    expect(studyKitProofIdsNeedingValidation(null, payload)).toEqual([proofId]);
    expect(validateStudyKitSnapshotIntegrity(null, payload, proof)).toBe(true);
    expect(diagnoseStudyKitSnapshotIntegrity(null, payload, proof)).toBeNull();
    expect(diagnoseStudyKitSnapshotIntegrity(null, payload, new Map())).toMatchObject({ branch: "b", reason: "proof_record_missing", fields: ["citationProofId"] });

    const tampered = structuredClone(payload);
    (tampered.subjects[0].classes[0].studyKits[0].multipleChoice[0] as any).sourceFileId = "S2";
    expect(validateStudyKitSnapshotIntegrity(null, tampered, proof)).toBe(false);
    expect(diagnoseStudyKitSnapshotIntegrity(null, tampered, proof)).toMatchObject({ branch: "c", reason: "proof_payload_hash_mismatch", fields: ["multipleChoice[].sourceFileId"] });

    const unresolvedClass = structuredClone(payload);
    (unresolvedClass.subjects[0].classes[0].studyKits[0] as any).sourceClassIds = ["class-missing"];
    delete (unresolvedClass.subjects[0].classes[0].studyKits[0] as any).citationProofId;
    expect(diagnoseStudyKitSnapshotIntegrity(null, unresolvedClass, proof)).toMatchObject({ branch: "a", reason: "material_selection_unresolved", fields: ["sourceClassIds", "sourceFiles[].fileKey"] });

    const unproven = structuredClone(payload);
    delete (unproven.subjects[0].classes[0].studyKits[0] as any).citationProofId;
    expect(validateStudyKitSnapshotIntegrity(null, unproven, new Map())).toBe(false);
    expect(diagnoseStudyKitSnapshotIntegrity(null, unproven, new Map())).toMatchObject({ branch: "d", reason: "legacy_file_citations_without_proof", fields: ["citationProofId", "sourceFiles"] });

    const legacyDuplicateLabels = structuredClone(unproven);
    const legacyFiles = (legacyDuplicateLabels.subjects[0].classes[0].studyKits[0] as any).sourceFiles;
    for (let index = 0; index < legacyFiles.length; index += 1) {
      const selected = selection.fileLabels[index];
      legacyFiles[index].label = `${selected.label} · ${selected.legacyName} · ${selected.name}`;
    }
    expect(studyKitLegacyFileSelectionMismatchFields(legacyFiles, selection.fileLabels)).toEqual([]);
    expect(diagnoseStudyKitSnapshotIntegrity(null, legacyDuplicateLabels, new Map())).toMatchObject({ branch: "d", reason: "legacy_file_citations_without_proof" });
    const invalidLegacyLabel = structuredClone(legacyDuplicateLabels);
    (invalidLegacyLabel.subjects[0].classes[0].studyKits[0] as any).sourceFiles[0].label = "Etiqueta manipulada";
    expect(diagnoseStudyKitSnapshotIntegrity(null, invalidLegacyLabel, new Map())).toMatchObject({ branch: "a", fields: ["sourceFiles[0].label"] });

    const editedSourceAfterGeneration = structuredClone(payload);
    editedSourceAfterGeneration.subjects[0].classes[0].notes = "Apuntes actualizados después de generar el kit.";
    expect(diagnoseStudyKitSnapshotIntegrity(null, editedSourceAfterGeneration, proof)).toBeNull();
  });

  it("does not bind the server proof to IDs that the client assigns while preserving all study content", () => {
    const { kit } = validKit();
    const before = studyKitProofHash(kit);
    const after = structuredClone(kit);
    (after as any).id = "client-generated-kit-id";
    after.multipleChoice[0].id = "client-generated-question-id";
    expect(studyKitProofHash(after)).toBe(before);
  });
});

describe("confirmed cloud snapshot", () => {
  it("requires a persisted revision and payload", () => {
    expect(hasConfirmedCloudSnapshot({ revision: 1, payload: { v: 4, subjects: [] } })).toBe(true);
    expect(hasConfirmedCloudSnapshot({ revision: 0, payload: null })).toBe(false);
    expect(hasConfirmedCloudSnapshot({ revision: 1, payload: null })).toBe(false);
  });
});


describe("snapQuoteToEvidence", () => {
  it("reemplaza una paráfrasis por el fragmento literal de la fuente", () => {
    const evidence = "El dominio de una función es el conjunto de valores de entrada permitidos.";
    const paraphrase = "El conjunto de valores de entrada permitidos define el dominio de una función.";
    const snapped = snapQuoteToEvidence(evidence, paraphrase);
    expect(snapped).not.toBeNull();
    expect(evidence).toContain(snapped!);
    expect(snapped!.length).toBeGreaterThanOrEqual(12);
    expect(snapped!.length).toBeLessThanOrEqual(400);
  });

  it("no ajusta una cita sin parecido con la evidencia", () => {
    expect(snapQuoteToEvidence(
      "El dominio de una función es el conjunto de valores de entrada permitidos.",
      "La fotosíntesis transforma energía luminosa en energía química.",
    )).toBeNull();
  });

  it("actualiza la cita antes de resolver el archivo y la página del PDF", () => {
    const { kit, plan } = validKit();
    const candidate = structuredClone(kit) as any;
    const evidence = "El dominio de una función es el conjunto de valores de entrada permitidos.";
    const paraphrase = "El conjunto de valores de entrada permitidos define el dominio de una función.";
    const file = pdfReference("S1", [evidence]);
    const citationItems = [candidate.studyGuide, ...candidate.studyGuide.glossary, ...candidate.multipleChoice];
    for (const item of citationItems) { item.sourceQuote = paraphrase; item.sourceFileId = "S1"; delete item.sourcePage; }
    const normalized = normalizeStudyKitResponse(candidate, plan, [file]);
    expect(normalized?.studyGuide.sourceQuote).not.toBe(paraphrase);
    expect(evidence).toContain(normalized?.studyGuide.sourceQuote);
    expect(normalized?.studyGuide.sourceFileId).toBe("S1");
    expect(normalized?.studyGuide.sourcePage).toBe(1);
    expect(studyKitGenerationFailure(normalized, "", plan, [file])).toBeNull();
  });
});


describe("Study Kit Gemini PDF-to-cloud integration", () => {
  it("simula generación, proof del servidor, guardado v18 y sincronización sin mutar campos firmados", () => {
    const { kit: baseKit, plan } = validKit();
    const pdfText = "El dominio de una función es el conjunto de valores de entrada permitidos.";
    const paraphrase = "El conjunto de valores de entrada permitidos define el dominio de una función.";
    const file = { ...pdfReference("S1", [pdfText, ""]), fileKey: "f_pdf_1", name: "diapositivas.pdf", label: "Biología · Fotosíntesis · diapositivas.pdf" };
    const initialSnapshot: any = { v: 4, subjects: [{ id: "subject-1", name: "Biología", classes: [{ id: "class-1", name: "Fotosíntesis", notes: source, files: [{ key: file.fileKey, name: file.name }], studyKits: [] }] }] };
    const selection = resolveStudyMaterialSelection(initialSnapshot, ["class-1"], [file.fileKey]);
    const rawGemini = structuredClone(baseKit) as any;
    const generatedCitationItems = [rawGemini.studyGuide, ...rawGemini.studyGuide.glossary, ...rawGemini.multipleChoice];
    for (const item of generatedCitationItems) { item.sourceQuote = paraphrase; item.sourceFileId = "S1"; delete item.sourcePage; }
    rawGemini.studyGuide.sourceQuote = "El diagrama representa una relación visual entre conjuntos.";
    delete rawGemini.studyGuide.sourcePage;
    rawGemini.followUps = [{ id: "followup-1", type: "multipleChoice", question: "¿Qué define el dominio?", options: ["Las entradas permitidas", "La salida", "El nombre", "El gráfico"], sourceQuote: pdfText, sourceFileId: "S1" }];

    const normalized = normalizeStudyKitResponse(rawGemini, plan, [file], selection.sourceText);
    expect(normalized).not.toBeNull();
    if (!normalized) throw new Error("No se pudo normalizar el fixture de Gemini.");
    expect(pdfText).toContain(normalized.multipleChoice[0].sourceQuote);
    expect(normalized.multipleChoice[0].sourcePage).toBe(1);
    expect(normalized.studyGuide.sourcePage).toBeUndefined();
    expect(studyKitGenerationFailure(normalized, selection.sourceText, plan, [file])).toBeNull();

    const { evidenceText: _evidenceText, evidencePages: _evidencePages, ...sourceFile } = file;
    const proofId = "kitproof_integration_test_123456";
    const serverKit: Record<string, any> = { ...normalized, id: "kit_server_integration", createdAt: "2026-10-17T00:00:00.000Z", citationProofId: proofId, sourceText: selection.sourceText, sourceLabels: selection.sourceLabels, sourceClassIds: selection.sourceClassIds, sourceLength: selection.sourceText.length + file.evidenceText.length, sourceFiles: [sourceFile] };
    const makeProofFromOperations = (proofKit: Record<string, any>, id: string) => {
      const operations = studyKitProofOperationRows(7, id, proofKit, 1);
      expect(operations.every(operation => !JSON.stringify(operation).includes(pdfText))).toBe(true);
      const receipt = operations.find(operation => operation.operationId === id);
      if (!receipt) throw new Error("El registro sintético no creó el receipt base.");
      const prefix = `${id}:f:`;
      const fieldHashes = Object.fromEntries(operations.filter(operation => operation.operationId.startsWith(prefix)).map(operation => [operation.operationId.slice(prefix.length), operation.payloadHash]));
      return new Map([[id, { payloadHash: receipt.payloadHash, fieldHashes }]]);
    };
    const proof = makeProofFromOperations(serverKit, proofId);

    // v18 añade solo estado local/IDs no firmados; antes del arreglo sobrescribía followUps.
    const brokenV18Kit: Record<string, any> = { ...structuredClone(serverKit), id: "kit_client_integration", followUps: [] };
    const protectedFields = ["title", "difficulty", "sourceText", "sourceLabels", "sourceClassIds", "sourceLength", "sourceFiles", "studyGuide", "multipleChoice", "trueFalse", "shortAnswer", "matchingPairs", "ordering", "diagramLabels", "flashcards", "followUps"];
    const changedFields = protectedFields.filter(field => JSON.stringify((serverKit as any)[field] ?? null) !== JSON.stringify((brokenV18Kit as any)[field] ?? null));
    expect(changedFields).toEqual(["followUps"]);
    const rejectedPayload = structuredClone(initialSnapshot);
    rejectedPayload.subjects[0].classes[0].studyKits = [brokenV18Kit];
    expect(diagnoseStudyKitSnapshotIntegrity(null, rejectedPayload, proof)).toMatchObject({ branch: "c", reason: "proof_payload_hash_mismatch", kitId: "kit_client_integration", fields: expect.arrayContaining(["followUps[].question", "followUps[].sourceQuote"]) });

    const v18SavedKit: Record<string, any> = { ...structuredClone(serverKit), id: "kit_client_integration", sessions: [], failedQuestionIds: [], failedPairIds: [], history: [], spacedRepetition: {} };
    const synchronizedPayload = structuredClone(initialSnapshot);
    synchronizedPayload.subjects[0].classes[0].studyKits = [v18SavedKit];
    expect(v18SavedKit.followUps).toEqual(serverKit.followUps);
    expect(diagnoseStudyKitSnapshotIntegrity(null, synchronizedPayload, proof)).toBeNull();

    const followUp = normalizeStudyKitFollowUpForStorage({ type: "multipleChoice", question: "¿Qué conjunto determina la entrada?", options: ["El dominio", "La imagen", "El rango", "El gráfico"], sourceQuote: pdfText, sourceFileId: "S1", sourcePage: 1 }, "q1", "follow_integration");
    expect(followUp).not.toBeNull();
    if (!followUp) throw new Error("No se pudo normalizar el follow-up adaptativo.");
    const extendedProofId = "kitproof_integration_followup_123456";
    const extendedKit = { ...structuredClone(v18SavedKit), citationProofId: extendedProofId, followUps: [...structuredClone(v18SavedKit.followUps), followUp] };
    const extendedProof = makeProofFromOperations(extendedKit, extendedProofId);
    const extendedPayload = structuredClone(initialSnapshot);
    extendedPayload.subjects[0].classes[0].studyKits = [extendedKit];
    expect(validateStudyStatePayload(extendedPayload)).toBe(true);
    expect(diagnoseStudyKitSnapshotIntegrity(null, extendedPayload, extendedProof)).toBeNull();
    (extendedKit.followUps[0] as any).question = "Pregunta manipulada que no tiene proof.";
    expect(diagnoseStudyKitSnapshotIntegrity(null, extendedPayload, extendedProof)).toMatchObject({ branch: "c", fields: ["followUps[].question"] });

    synchronizedPayload.subjects[0].classes[0].notes = "El material de la clase se editó luego de generar el Study Kit.";
    expect(diagnoseStudyKitSnapshotIntegrity(null, synchronizedPayload, proof)).toBeNull();
  });

  it("ejecuta el normalizador y el aplicador reales de v18 para guardar el follow-up con su nuevo proof", () => {
    const clientSource = readFileSync(new URL("../client/public/studyhub-study-kit-v18.js", import.meta.url), "utf8");
    const extractFunction = (startMarker: string, endMarker: string) => {
      const start = clientSource.indexOf(startMarker), end = clientSource.indexOf(endMarker, start);
      if (start < 0 || end < 0) throw new Error(`No se encontró la función cliente ${startMarker}`);
      return clientSource.slice(start, end).trim();
    };
    const normalizeQuestion = runInNewContext(`(${extractFunction("function normalizeQuestion(raw) {", "function findKit(")})`, { str: (value: unknown) => String(value ?? ""), newId: () => "client-generated" }) as (value: Record<string, any>) => Record<string, any>;
    const applyProof = runInNewContext(`(${extractFunction("function applyStudyKitFollowUpProof(kit, follow, nextCitationProofId) {", "function normalizedStudyText(")})`, { str: (value: unknown) => String(value ?? "") }) as (kit: Record<string, any>, follow: Record<string, any>, proofId: string) => boolean;
    const followUp = normalizeStudyKitFollowUpForStorage({ type: "multipleChoice", question: "¿Qué se permite como entrada?", options: ["Valores del dominio", "El gráfico", "La respuesta", "El nombre"], sourceQuote: "El dominio de una función es el conjunto de valores de entrada permitidos.", sourceFileId: "S1", sourcePage: 1 }, "q1", "follow_v18_test");
    expect(followUp).not.toBeNull();
    if (!followUp) throw new Error("No se pudo normalizar el follow-up.");
    expect(JSON.parse(JSON.stringify(normalizeQuestion(followUp)))).toEqual(followUp);
    const kit: Record<string, any> = { citationProofId: "kitproof_initial_abcdefghijklmnop", followUps: [] };
    expect(applyProof(kit, followUp, "kitproof_next_abcdefghijklmnop")).toBe(true);
    expect(kit.followUps).toEqual([followUp]);
    expect(kit.citationProofId).toBe("kitproof_next_abcdefghijklmnop");
    const before = structuredClone(kit);
    expect(applyProof(kit, followUp, "invalid-proof")).toBe(false);
    expect(kit).toEqual(before);
    const constructor = clientSource.match(/const kit = \{\s*\.\.\.raw,[\s\S]*?\n\s*\};/);
    expect(constructor?.[0]).toContain("...raw");
    expect(constructor?.[0]).not.toMatch(/\bfollowUps\s*:/);
  });
});

describe("Study Kit frozen material selection and proof receipt IDs", () => {
  it("exige el conjunto completo de archivos congelados, admite solo un subconjunto citado y respeta varchar(80)", async () => {
    const frozenFiles = [
      { sourceId: "S1", fileKey: "f_pdf_1", name: "uno.pdf", label: "Clase · uno.pdf", mimeType: "application/pdf", originalMimeType: "application/pdf", size: 10, checksum: "a".repeat(64), convertedToPdf: false, textEvidenceAvailable: true },
      { sourceId: "S2", fileKey: "f_pdf_2", name: "dos.pdf", label: "Clase · dos.pdf", mimeType: "application/pdf", originalMimeType: "application/pdf", size: 20, checksum: "b".repeat(64), convertedToPdf: false, textEvidenceAvailable: true },
    ];
    const currentLabels = frozenFiles.map(({ sourceId, fileKey, name }) => ({ sourceId, fileKey, label: "Clase", name }));
    const preparedOnlySecond = [{ ...frozenFiles[1], sourceId: "S2" }];
    expect(studyKitFrozenFileSelectionMatches(frozenFiles, currentLabels, ["f_pdf_2"], preparedOnlySecond)).toBe(true);
    expect(studyKitFrozenFileSelectionMatches(frozenFiles, currentLabels, ["f_pdf_2"], [{ ...frozenFiles[1], sourceId: "S1" }])).toBe(false);
    expect(studyKitFrozenFileSelectionMatches(frozenFiles, currentLabels.slice(0, 1), ["f_pdf_1"], [frozenFiles[0]])).toBe(false);
    expect(studyKitFrozenFileSelectionMatches(frozenFiles, currentLabels, ["f_pdf_extra"], [{ ...frozenFiles[0], fileKey: "f_pdf_extra" }])).toBe(false);
    expect(studyKitFrozenFileSelectionMatches(frozenFiles, currentLabels, [], [])).toBe(true);

    const cloudSnapshot = { v: 4, subjects: [{ id: "subject-1", name: "Biología", classes: [{ id: "class-1", name: "Unidad", notes: source, files: [{ key: "f_pdf_1", name: "uno.pdf" }, { key: "f_pdf_2", name: "nombre distinto en snapshot.txt" }] }] }] };
    const secondFileSelection = resolveStudyMaterialSelection(cloudSnapshot, ["class-1"], ["f_pdf_2"], [{ fileKey: "f_pdf_2", sourceId: "S2", label: "ignored-client-label" }]);
    expect(secondFileSelection.fileLabels[0].sourceId).toBe("S2");
    expect(secondFileSelection.fileLabels[0].label).toBe("Biología · Unidad");
    expect(secondFileSelection.fileLabels[0].name).toBe("nombre distinto en snapshot.txt");
    const materialText = "El dominio limita los valores que una función puede recibir como entrada.";
    const bytes = Buffer.from(materialText, "utf8");
    const preparedSubset = await prepareStudyMaterials({
      sourceText: secondFileSelection.sourceText,
      sourceLabels: secondFileSelection.sourceLabels,
      files: [{ localKey: "f_pdf_2", fileName: "dos  final.txt", mimeType: "text/plain", size: bytes.length, checksum: "c".repeat(64), content: bytes }],
      fileLabels: secondFileSelection.fileLabels,
      validateFile: validatePrivateFilePayload,
    });
    expect(preparedSubset.sourceFiles[0].sourceId).toBe("S2");
    expect(preparedSubset.sourceFiles[0].name).toBe("dos  final.txt");
    expect(preparedSubset.sourceFiles[0].label).toBe("Biología · Unidad · dos  final.txt");
    expect(studyKitFrozenFileSelectionMatches(preparedSubset.sourceFiles, secondFileSelection.fileLabels, ["f_pdf_2"], preparedSubset.sourceFiles)).toBe(true);
    const legacyDuplicateLabel = { ...preparedSubset.sourceFiles[0], label: `${preparedSubset.sourceFiles[0].label} · dos  final.txt` };
    expect(studyKitFrozenFileSelectionMatches([legacyDuplicateLabel], secondFileSelection.fileLabels, ["f_pdf_2"], preparedSubset.sourceFiles)).toBe(true);
    const frozenSnapshotName = { ...preparedSubset.sourceFiles[0], name: secondFileSelection.fileLabels[0].name };
    expect(studyKitFrozenFileSelectionMatches([frozenSnapshotName], secondFileSelection.fileLabels, ["f_pdf_2"], preparedSubset.sourceFiles)).toBe(false);
    const { kit, plan } = validKit();
    const kitWithSecondSource = structuredClone(kit) as any;
    kitWithSecondSource.multipleChoice[0].sourceQuote = materialText;
    kitWithSecondSource.multipleChoice[0].sourceFileId = "S2";
    expect(validateStudyKitGeneration(kitWithSecondSource, secondFileSelection.sourceText, plan, preparedSubset.sourceFiles)).toBe(true);

    const maximumProofId = `kitproof_${"a".repeat(71)}`;
    expect(studyKitProofRevisionMatches(12, 12)).toBe(true);
    expect(studyKitProofRevisionMatches(12, 13)).toBe(false);
    expect(studyKitProofRevisionMatches(12, "12")).toBe(false);
    expect(maximumProofId.length).toBe(80);
    expect(studyKitProofFieldOperationId(maximumProofId, "followUps[].sourcePage")).toBeNull();
    const generatedProofId = `kitproof_${"a".repeat(32)}`;
    const fieldOperationId = studyKitProofFieldOperationId(generatedProofId, "followUps[].sourcePage");
    expect(fieldOperationId).not.toBeNull();
    expect(fieldOperationId!.length).toBeLessThanOrEqual(80);
    const generatedRows = studyKitProofOperationRows(7, generatedProofId, validKit().kit, 1);
    expect(generatedRows.length).toBeGreaterThan(1);
    expect(generatedRows.every(operation => operation.operationId.length <= 80)).toBe(true);
    const maximumRows = studyKitProofOperationRows(7, maximumProofId, validKit().kit, 1);
    expect(maximumRows).toHaveLength(1);
    expect(maximumRows[0].operationId).toBe(maximumProofId);
  });
});
