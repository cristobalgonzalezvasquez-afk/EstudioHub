import { describe, expect, it } from "vitest";
import { collectStudyFileRefs, computeStudyQuizCounts, sourceContainsStudyEvidence, validatePrivateFilePayload, validateStudyStatePayload } from "./studyhub";
import { safeDatabaseErrorCode } from "./db";

describe("collectStudyFileRefs", () => {
  it("deduplicates only valid private keys in supported reference fields", () => {
    const state = {
      subjects: [
        { files: [{ key: "f_alpha-1", name: "A.pdf" }, { key: "external-link", name: "B.pdf" }],
          classes: [{ assets: [{ fileKey: "f_beta_2" }, { tk: "f_alpha-1" }] }] },
      ],
      unrelated: { text: "f_not-a-reference" },
    };
    expect(collectStudyFileRefs(state).sort()).toEqual(["f_alpha-1", "f_beta_2"]);
  });

  it("returns an empty collection when there are no valid references", () => {
    expect(collectStudyFileRefs({ files: [{ key: "https://example.test/file.pdf" }] })).toEqual([]);
  });
  it("rejects malformed private keys instead of silently dropping file references", () => {
    expect(() => collectStudyFileRefs({ files: [{ key: `f_${"a".repeat(151)}` }] })).toThrow();
  });
});

describe("validatePrivateFilePayload", () => {
  it("accepts a PDF only when its signature and declared MIME agree", () => {
    expect(validatePrivateFilePayload("clase.pdf", "application/pdf", Buffer.from("%PDF-1.7\n"))).toBe("application/pdf");
    expect(validatePrivateFilePayload("clase.pdf", "application/pdf", Buffer.from("not a PDF"))).toBeNull();
    expect(validatePrivateFilePayload("clase.pdf", "text/html", Buffer.from("%PDF-1.7\n"))).toBeNull();
  });
  it("checks binary image signatures and forces unrecognized active files to octet-stream", () => {
    const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]);
    expect(validatePrivateFilePayload("apunte.png", "image/png", png)).toBe("image/png");
    expect(validatePrivateFilePayload("apunte.png", "image/png", Buffer.from("not a PNG"))).toBeNull();
    expect(validatePrivateFilePayload("material.html", "text/html", Buffer.from("<script>alert(1)</script>"))).toBe("application/octet-stream");
  });
});

describe("sourceContainsStudyEvidence", () => {
  it("matches exact source wording despite whitespace, case and Unicode normalization", () => {
    expect(sourceContainsStudyEvidence("La tasa de interés\ncompuesto acumula capitalización.", "TASA de   interés compuesto")).toBe(true);
  });

  it("ignores only spacing inserted inside PDF words while retaining exact characters", () => {
    expect(sourceContainsStudyEvidence("La teoría se aplica al domi nio continental y sus límites.", "La teoría se aplica al dominio continental y sus límites")).toBe(true);
    expect(sourceContainsStudyEvidence("La teoría se aplica al dominio continental y sus límites.", "La teoría se aplica al dominio geográfico y sus límites")).toBe(false);
  });

  it("keeps literal word order while tolerating PDF line-break hyphenation, accents and punctuation", () => {
    expect(sourceContainsStudyEvidence("La energía foto-\nvoltaica: esencial.", "la energia fotovoltaica esencial")).toBe(true);
    expect(sourceContainsStudyEvidence("La energía foto-voltaica es esencial.", "La energía solar es esencial")).toBe(false);
  });

  it("rejects unsupported or too-short quotes", () => {
    const source = "El valor presente se calcula con una tasa por período.";
    expect(sourceContainsStudyEvidence(source, "La inflación determina el resultado final")).toBe(false);
    expect(sourceContainsStudyEvidence(source, "tasa")).toBe(false);
  });
});

describe("safeDatabaseErrorCode", () => {
  it("returns a bounded driver code without exposing the error message or SQL", () => {
    const error = Object.assign(new Error("mysql://student:secret@db/private?query=INSERT"), { code: "ER_ACCESS_DENIED_ERROR", sql: "INSERT INTO users VALUES (...)" });
    expect(safeDatabaseErrorCode(error)).toBe("ER_ACCESS_DENIED_ERROR");
    expect(safeDatabaseErrorCode(error)).not.toContain("secret");
  });

  it("falls back to a generic code when the driver error has no safe code", () => {
    expect(safeDatabaseErrorCode(new Error("password=secret"))).toBe("DATABASE_OPERATION_FAILED");
  });
});

describe("validateStudyStatePayload", () => {
  it("accepts normalized current data and the prior supported data version", () => {
    const current = { v: 4, subjects: [{ id: "eco", name: "Economía", classes: [{ id: "c1", quizzes: [{ multipleChoice: [], matchingPairs: [], flashcards: [] }] }] }], studyhubFileArchives: [] };
    expect(validateStudyStatePayload(current)).toBe(true);
    expect(validateStudyStatePayload({ v: 3, subjects: [{ id: "eco" }] })).toBe(true);
  });

  it("rejects future versions and malformed nested collections before a snapshot write", () => {
    expect(validateStudyStatePayload({ v: 5, subjects: [] })).toBe(false);
    expect(validateStudyStatePayload({ v: 4, subjects: [{ id: "eco", classes: {} }] })).toBe(false);
    expect(validateStudyStatePayload({ v: 4, subjects: [{ classes: [{ quizzes: [{ multipleChoice: {} }] }] }] })).toBe(false);
  });
});

describe("computeStudyQuizCounts", () => {
  it("keeps the selected number as evaluated items and reports combined flashcards separately", () => {
    for (const count of [5, 10, 15, 20]) {
      const result = computeStudyQuizCounts("combinada", count);
      expect(result.mcCount + result.pairCount).toBe(count);
      expect(result.flashcardCount).toBe(5);
    }
    expect(computeStudyQuizCounts("seleccion", 10)).toEqual({ mode: "seleccion", count: 10, mcCount: 10, pairCount: 0, flashcardCount: 0 });
    expect(computeStudyQuizCounts("pareados", 5)).toEqual({ mode: "pareados", count: 5, mcCount: 0, pairCount: 5, flashcardCount: 0 });
  });
});
