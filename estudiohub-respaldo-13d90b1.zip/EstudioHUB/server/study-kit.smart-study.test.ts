import { describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import type { Express } from "express";
import * as databaseHelpers from "./db";
import { registerStudyHubRoutes, resolveStudyMaterialSelection, studyKitProofFieldHashes, studyKitProofHash, studyKitProofOperationRows, validateStudyStatePayload } from "./studyhub";
import { studyCloudState, studyOperations } from "../drizzle/schema";

const serverTime = 1_792_100_000_000;
const clientSource = readFileSync(new URL("../client/public/studyhub-study-kit-v18.js", import.meta.url), "utf8");
const studySource = "La fotosíntesis transforma la energía luminosa en energía química y ocurre principalmente en los cloroplastos de las células vegetales.";

type SyncState = "signed-out" | "offline" | "conflict" | "pending" | "syncing" | "error" | "confirmed";

function makeCloudSnapshot() {
  const snapshot: any = { v: 4, subjects: [{ id: "subject-1", name: "Biología", classes: [{ id: "class-1", name: "Fotosíntesis", notes: studySource, trainingText: studySource, studyKits: [] }] }] };
  const selection = resolveStudyMaterialSelection(snapshot, ["class-1"], []);
  const proofId = "kitproof_smartstudy_session_123456";
  const kit: any = {
    id: "kit-smartstudy", citationProofId: proofId, title: "Guía de fotosíntesis", difficulty: "Intermedio", createdAt: "2026-10-17T00:00:00.000Z",
    sourceText: selection.sourceText, sourceLabels: selection.sourceLabels, sourceClassIds: selection.sourceClassIds, sourceLength: selection.sourceText.length, sourceFiles: [],
    studyGuide: {
      summary: "La fotosíntesis transforma la energía luminosa en energía química dentro de las células vegetales.",
      keyPoints: ["Usa energía luminosa", "Produce energía química", "Ocurre en cloroplastos"],
      questions: ["¿Qué transforma la fotosíntesis?", "¿Dónde ocurre el proceso?", "¿Qué energía produce?"],
      glossary: [
        { term: "Fotosíntesis", definition: "Proceso que transforma energía luminosa.", sourceQuote: studySource.slice(0, 48) },
        { term: "Cloroplasto", definition: "Estructura de las células vegetales.", sourceQuote: "en los cloroplastos de las células vegetales" },
        { term: "Energía química", definition: "Energía producida por el proceso.", sourceQuote: "energía química y ocurre principalmente" },
      ],
      sourceQuote: studySource.slice(0, 55), podcastScript: "",
    },
    multipleChoice: [{ id: "q1", question: "¿Qué transforma la fotosíntesis?", topic: "Fotosíntesis", options: ["La energía luminosa", "El sonido", "La gravedad", "La temperatura"], correctIndex: 0, explanations: ["La fuente indica que transforma energía luminosa.", "El sonido no es la respuesta.", "La gravedad no corresponde.", "La temperatura no corresponde."], sourceQuote: studySource.slice(0, 55) }],
    trueFalse: [], shortAnswer: [], matchingPairs: [], ordering: [], diagramLabels: [], flashcards: [], followUps: [],
    sessions: [], history: [], failedQuestionIds: [], failedPairIds: [], spacedRepetition: {},
  };
  snapshot.subjects[0].classes[0].studyKits = [kit];
  return { snapshot, kit, proofId };
}

function createClientHarness(snapshot: any) {
  const subject = snapshot.subjects[0];
  const clazz = subject.classes[0];
  const listeners = new Map<string, (event?: any) => void>();
  const elements = new Map<string, any>();
  const timers: Array<{ id: number; fn: () => void; delay: number }> = [];
  let nextTimer = 1;
  let idCounter = 0;
  let syncState: SyncState = "confirmed";
  let profileGeneration = 1;
  let saveAppDataCalls = 0;
  let localSaveCalls = 0;
  const makeNode = () => {
    let html = "", text = "";
    return {
      get innerHTML() { return html; },
      set innerHTML(value: string) { html = String(value); text = html.replace(/<[^>]*>/g, " "); },
      get textContent() { return text; },
      set textContent(value: string) { text = String(value); html = text; },
      value: "", disabled: false, hidden: false, title: "",
      classList: { toggle() {}, add() {}, remove() {}, contains() { return false; } },
      replaceChildren() { html = ""; text = ""; },
      append() {}, setAttribute() {}, removeAttribute() {}, addEventListener() {}, removeEventListener() {},
      querySelector() { return null; }, querySelectorAll() { return []; }, focus() {},
    };
  };
  const node = (id: string) => { if (!elements.has(id)) elements.set(id, makeNode()); return elements.get(id); };
  const notify = (state: SyncState, detail: Record<string, unknown> = {}) => {
    syncState = state;
    listeners.get("studyhub:sync-state")?.({ type: "studyhub:sync-state", detail: { state, ...detail } });
  };
  const notifyAuth = (state: string) => listeners.get("studyhub:auth-state")?.({ type: "studyhub:auth-state", detail: { state } });
  const cloud: any = {
    isSignedIn: () => true,
    isOnlineStudyReady: () => syncState === "confirmed",
    getStudySyncState: () => syncState,
    getProfileGeneration: () => profileGeneration,
    isProfileGenerationCurrent: (value: number) => Number(value) === profileGeneration && syncState !== "signed-out",
    serverNow: () => serverTime,
    saveLocalOnly: () => { localSaveCalls += 1; },
    syncNow: async () => false,
  };
  const navigatorObject = { onLine: true };
  const windowObject: any = {
    StudyHubCloud: cloud,
    StudyKitSessionClock: {
      now: () => serverTime,
      isReady: () => true,
      deadlineAfter: (duration: number) => serverTime + duration,
      remainingUntil: (deadline: number) => Math.max(0, Number(deadline) - serverTime),
      remainingMs: (saved: any) => Math.max(0, Number(saved.deadline) - serverTime),
      syncServerNow() {},
    },
    saveAppData: () => { saveAppDataCalls += 1; notify("pending"); },
    addEventListener: (type: string, listener: (event?: any) => void) => { listeners.set(type, listener); },
    removeEventListener() {}, dispatchEvent() { return true; },
    confirm: () => true, open() {},
  };
  const context: any = {
    window: windowObject,
    document: {
      getElementById: node,
      createElement: makeNode,
      addEventListener() {},
      querySelector() { return null; },
      querySelectorAll(selector: string) { return selector === ".study-kit-format:checked" ? [{ value: "multipleChoice" }] : selector === ".study-kit-youtube button" ? [node("studyKitYoutubeButton")] : []; },
      body: { append() {}, appendChild() {} },
    },
    navigator: navigatorObject,
    curSubject: () => subject,
    curClass: () => clazz,
    appData: snapshot,
    crypto: { randomUUID: () => `smart-${++idCounter}` },
    setTimeout: (fn: () => void, delay = 0) => { const id = nextTimer++; timers.push({ id, fn, delay }); return id; },
    clearTimeout: (id: number) => { const index = timers.findIndex(timer => timer.id === id); if (index >= 0) timers.splice(index, 1); },
    setInterval: (fn: () => void, delay = 0) => { const id = nextTimer++; timers.push({ id, fn, delay }); return id; },
    clearInterval: (id: number) => { const index = timers.findIndex(timer => timer.id === id); if (index >= 0) timers.splice(index, 1); },
    speechSynthesis: { cancel() {} },
    console: { error() {}, warn() {}, log() {} },
  };
  runInNewContext(clientSource, context);
  return {
    window: windowObject, cloud, snapshot, clazz, kit: clazz.studyKits[0], elements, timers, notify, notifyAuth, getNode: node,
    setProfileGeneration: (value: number) => { profileGeneration = value; },
    browserOffline: () => { navigatorObject.onLine = false; syncState = "offline"; listeners.get("offline")?.({ type: "offline" }); },
    browserOnline: () => { navigatorObject.onLine = true; syncState = "confirmed"; listeners.get("online")?.({ type: "online" }); },
    get syncState() { return syncState; }, get saveAppDataCalls() { return saveAppDataCalls; }, get localSaveCalls() { return localSaveCalls; },
  };
}

function registerRouteHandler() {
  const routes = new Map<string, Function[]>();
  const target: Record<string, unknown> = {};
  const app = new Proxy(target, {
    get(_object, property) {
      return (path: unknown, ...handlers: Function[]) => {
        if (typeof path === "string") routes.set(`${String(property)} ${path}`, handlers);
        return app;
      };
    },
  }) as unknown as Express;
  registerStudyHubRoutes(app);
  const handlers = routes.get("put /api/study/state");
  if (!handlers?.length) throw new Error("No se registró PUT /api/study/state");
  return handlers[handlers.length - 1];
}

function fakeResponse() {
  const result: { status: number; headers: Record<string, string>; body?: any } = { status: 200, headers: {} };
  const response: any = {
    status(code: number) { result.status = code; return response; },
    set(name: string, value: string) { result.headers[name.toLowerCase()] = value; return response; },
    json(body: unknown) { result.body = body; return response; },
  };
  return { result, response };
}

function syntheticDatabase(initialSnapshot: any, proofRows: any[]) {
  let current: any = { userId: 7, revision: 1, payload: initialSnapshot };
  let operationsSelects = 0;
  const query = (table: unknown) => {
    const rows = table === studyCloudState ? [current] : table === studyOperations ? (++operationsSelects >= 3 ? proofRows : []) : [];
    const chain: any = {
      where() { return chain; }, limit() { return chain; }, for() { return chain; },
      then(resolve: (value: unknown[]) => unknown, reject: (reason: unknown) => unknown) { return Promise.resolve(rows).then(resolve, reject); },
    };
    return chain;
  };
  const tx: any = {
    select() { return { from: (table: unknown) => query(table) }; },
    insert(table: unknown) { return { values: async (_values: unknown) => { if (table === studyOperations) return []; return []; } }; },
    update(table: unknown) { return { set: (values: any) => ({ where: async () => { if (table === studyCloudState) current = { ...current, ...values }; } }) }; },
  };
  const db: any = { transaction: async (callback: (transaction: unknown) => unknown) => callback(tx) };
  return { db, get current() { return current; } };
}

describe("Smart Study: persistencia de sesión y transición cloud", () => {
  it("genera una sesión con el cliente v18, conserva estado active durante pending y el PUT real responde 200 confirmado", async () => {
    const { snapshot, kit, proofId } = makeCloudSnapshot();
    expect(validateStudyStatePayload(snapshot)).toBe(true);
    const originalProofHash = studyKitProofHash(kit);
    const proofRows = studyKitProofOperationRows(7, proofId, kit, 1);
    const harness = createClientHarness(structuredClone(snapshot));
    harness.window.studyKitStart(kit.id, "formal");

    const savedSessions = harness.kit.sessions;
    const deadline = savedSessions[0].deadline;
    const remainingMs = savedSessions[0].remainingMs;
    expect(harness.syncState).toBe("pending");
    expect(savedSessions).toHaveLength(1);
    expect(savedSessions[0].status).toBe("active");
    expect(deadline).toBeGreaterThan(serverTime);
    expect(studyKitProofHash(harness.kit)).toBe(originalProofHash);
    expect(harness.saveAppDataCalls).toBe(1);
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("Sincronizando");
    harness.notify("syncing");
    expect(savedSessions[0].status).toBe("active");
    expect(savedSessions[0].deadline).toBe(deadline);
    expect(savedSessions[0].remainingMs).toBe(remainingMs);
    const pendingHint = harness.timers.find(timer => timer.delay === 15_000);
    expect(pendingHint).toBeDefined();
    pendingHint?.fn();
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("Reintentar sincronización");
    expect(validateStudyStatePayload(harness.snapshot)).toBe(true);

    const getDb = vi.spyOn(databaseHelpers, "getDb").mockResolvedValue(syntheticDatabase(snapshot, proofRows).db);
    try {
      const handler = registerRouteHandler();
      const { result, response } = fakeResponse();
      const headers = { "x-estudiohub-request": "1" };
      const request: any = {
        body: { baseRevision: 1, operationId: "smartstudy_session_sync_123", payload: harness.snapshot },
        studyUser: { id: 7 }, headers,
        get: (name: string) => headers[name.toLowerCase() as keyof typeof headers] || "",
      };
      await handler(request, response);
      expect(result.status).toBe(200);
      expect(result.body).toMatchObject({ revision: 2, confirmed: true });
      expect(result.body.code).toBeUndefined();
    } finally {
      getDb.mockRestore();
    }
  });

  it("muestra el HTTP/code real si falla, conserva la sesión y solo la reanuda después de confirmación", async () => {
    const { snapshot, kit } = makeCloudSnapshot();
    const harness = createClientHarness(structuredClone(snapshot));
    harness.window.studyKitStart(kit.id, "practice");
    const sessionId = harness.kit.sessions[0].id;
    const error = { httpStatus: 422, code: "invalid_study_kit_integrity", error: "La nube no confirmó el Study Kit." };
    harness.notify("error", error);

    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
    expect(harness.kit.sessions[0].status).toBe("paused");
    expect(harness.localSaveCalls).toBe(1);
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("HTTP 422");
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("invalid_study_kit_integrity");
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("Reintentar sincronización");

    let attempts = 0;
    harness.cloud.syncNow = async () => { attempts += 1; harness.notify("error", error); return false; };
    expect(await harness.window.studyKitRetryCloudSync()).toBe(false);
    expect(attempts).toBe(1);
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);

    harness.cloud.syncNow = async () => { attempts += 1; harness.notify("syncing"); harness.notify("confirmed"); return harness.syncState === "confirmed"; };
    expect(await harness.window.studyKitRetryCloudSync()).toBe(false);
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
    expect(harness.kit.sessions[0].status).toBe("active");
    expect(harness.syncState).toBe("pending");
    expect(harness.elements.get("studyKitStatus").innerHTML).not.toContain("HTTP 422");
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("Sincronizando");

    harness.notify("confirmed");
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
    expect(harness.kit.sessions[0].status).toBe("active");
    expect(harness.elements.get("studyKitStatus").textContent).toContain("sesión reanudada");
    expect(attempts).toBe(2);
  });

  it("pausa ante HTTP 401, muestra que hay que reconectar y conserva la sesión", () => {
    const { snapshot, kit } = makeCloudSnapshot();
    const harness = createClientHarness(structuredClone(snapshot));
    harness.window.studyKitStart(kit.id, "practice");
    const sessionId = harness.kit.sessions[0].id;

    harness.notify("signed-out", { httpStatus: 401, code: "authentication_required", error: "La sesión de Google venció." });

    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0]).toMatchObject({ id: sessionId, status: "paused" });
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("HTTP 401");
    expect(harness.elements.get("studyKitStatus").innerHTML).toContain("authentication_required");
  });

  it("pausa ante conflicto o desconexión y espera confirmación cloud explícita para reanudar", () => {
    const { snapshot, kit } = makeCloudSnapshot();
    const harness = createClientHarness(structuredClone(snapshot));
    harness.window.studyKitStart(kit.id, "practice");
    const sessionId = harness.kit.sessions[0].id;
    harness.notify("conflict");
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
    expect(harness.kit.sessions[0].status).toBe("paused");
    expect(harness.elements.get("studyKitPlay").innerHTML).toContain("conflicto");

    harness.notify("confirmed");
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
    expect(harness.kit.sessions[0].status).toBe("active");
    expect(harness.syncState).toBe("pending");
    harness.notify("confirmed");
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
    expect(harness.elements.get("studyKitStatus").textContent).toContain("sesión reanudada");

    harness.browserOffline();
    expect(harness.kit.sessions[0].status).toBe("paused");
    harness.browserOnline();
    expect(harness.kit.sessions[0].status).toBe("paused");
    expect(harness.elements.get("studyKitStatus").textContent).toContain("Esperando la confirmación");
    harness.notify("confirmed");
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
    expect(harness.kit.sessions[0].status).toBe("active");
    harness.notify("confirmed");
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0].id).toBe(sessionId);
  });

  it("conserva el límite de diez sesiones y no duplica el ID al reanudar", () => {
    const { snapshot, kit } = makeCloudSnapshot();
    kit.sessions = Array.from({ length: 10 }, (_, index) => ({
      id: `session-old-${index}`, kitId: kit.id, kind: "quiz", mode: "practice", status: "finished", startedAt: serverTime - 1000 - index,
      updatedAt: serverTime - 1000 - index, timestampBasis: "server", index: 1, remainingMs: 0, deadline: 0,
      questions: [{ id: "q1" }], answers: {}, drafts: {}, finished: true,
    }));
    const harness = createClientHarness(structuredClone(snapshot));
    harness.window.studyKitStart(kit.id, "practice");
    const sessionId = harness.kit.sessions[0].id;
    expect(harness.kit.sessions).toHaveLength(10);
    expect(harness.kit.sessions.filter((session: any) => session.id === sessionId)).toHaveLength(1);
    expect(validateStudyStatePayload(harness.snapshot)).toBe(true);

    harness.notify("confirmed");
    harness.window.studyKitResumeSession(kit.id, sessionId);
    expect(harness.kit.sessions).toHaveLength(10);
    expect(harness.kit.sessions.filter((session: any) => session.id === sessionId)).toHaveLength(1);
    expect(harness.kit.sessions.find((session: any) => session.id === sessionId).status).toBe("active");
    expect(validateStudyStatePayload(harness.snapshot)).toBe(true);
  });

  it("descarta respuestas Gemini tardías de generación y transcripción tras cambiar la generación del perfil", async () => {
    const { snapshot, kit } = makeCloudSnapshot();
    const harness = createClientHarness(structuredClone(snapshot));
    const generationDeferred: { resolve?: (value: unknown) => void } = {};
    harness.cloud.requestStudyAI = () => new Promise(resolve => { generationDeferred.resolve = resolve; });
    const generate = harness.window.studyKitGenerate();
    for (let turn = 0; turn < 5 && !generationDeferred.resolve; turn += 1) await Promise.resolve();
    expect(generationDeferred.resolve).toBeTypeOf("function");
    harness.setProfileGeneration(2);
    generationDeferred.resolve?.({ kit: structuredClone(kit) });
    await generate;
    expect(harness.clazz.studyKits).toHaveLength(1);

    harness.setProfileGeneration(3);
    harness.getNode("studyKitYoutubeUrl").value = "https://www.youtube.com/watch?v=old-profile";
    const transcriptDeferred: { resolve?: (value: unknown) => void } = {};
    harness.cloud.requestStudyAI = () => new Promise(resolve => { transcriptDeferred.resolve = resolve; });
    const importTranscript = harness.window.studyKitAddYouTube();
    for (let turn = 0; turn < 5 && !transcriptDeferred.resolve; turn += 1) await Promise.resolve();
    expect(transcriptDeferred.resolve).toBeTypeOf("function");
    harness.setProfileGeneration(4);
    transcriptDeferred.resolve?.({ text: "Transcripción de otro perfil. ".repeat(8), videoId: "old-profile" });
    await importTranscript;
    expect(harness.clazz.studyKitSources).toEqual([]);
    expect(harness.kit.sessions).toHaveLength(0);
  });

  it("guarda la sesión pausada en el perfil anterior al cambiar identidad y la reanuda con el mismo ID", () => {
    const { snapshot, kit } = makeCloudSnapshot();
    const originalProofHash = studyKitProofHash(kit);
    const harness = createClientHarness(structuredClone(snapshot));
    harness.window.studyKitStart(kit.id, "formal");
    const sessionId = harness.kit.sessions[0].id;
    expect(harness.kit.sessions[0].status).toBe("active");

    harness.notifyAuth("changing");
    harness.notify("signed-out");
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0]).toMatchObject({ id: sessionId, kitId: kit.id, status: "paused", deadline: 0, timestampBasis: "server" });
    expect(harness.kit.sessions[0].remainingMs).toBeGreaterThan(0);
    const savedRemainingMs = harness.kit.sessions[0].remainingMs;
    expect(harness.localSaveCalls).toBe(1);
    expect(harness.kit.sessions.some((session: any) => session.id === sessionId)).toBe(true);
    expect(studyKitProofHash(harness.kit)).toBe(originalProofHash);
    expect(harness.timers.some(timer => timer.delay === 1_000)).toBe(false);

    harness.window.studyKitResumeSession(kit.id, sessionId);
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0]).toMatchObject({ id: sessionId, status: "paused" });
    harness.notify("confirmed");
    harness.window.studyKitResumeSession(kit.id, sessionId);
    expect(harness.kit.sessions).toHaveLength(1);
    expect(harness.kit.sessions[0]).toMatchObject({ id: sessionId, status: "active", remainingMs: savedRemainingMs, deadline: serverTime + savedRemainingMs });
    expect(studyKitProofHash(harness.kit)).toBe(originalProofHash);
  });
});
