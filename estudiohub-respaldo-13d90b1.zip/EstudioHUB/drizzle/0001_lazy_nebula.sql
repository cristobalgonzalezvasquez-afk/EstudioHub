CREATE TABLE `study_cloud_state` (
	`userId` int NOT NULL,
	`revision` int NOT NULL DEFAULT 0,
	`payload` json NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `study_cloud_state_userId` PRIMARY KEY(`userId`)
);
--> statement-breakpoint
CREATE TABLE `study_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`localKey` varchar(160) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(160) NOT NULL,
	`size` bigint NOT NULL,
	`checksum` varchar(64) NOT NULL,
	`content` longblob NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `study_files_id` PRIMARY KEY(`id`),
	CONSTRAINT `study_files_user_local_key_uq` UNIQUE(`userId`,`localKey`)
);
--> statement-breakpoint
CREATE TABLE `study_operations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`operationId` varchar(80) NOT NULL,
	`resultRevision` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `study_operations_id` PRIMARY KEY(`id`),
	CONSTRAINT `study_operations_user_operation_uq` UNIQUE(`userId`,`operationId`)
);
--> statement-breakpoint
CREATE TABLE `study_sessions` (
	`tokenHash` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `study_sessions_tokenHash` PRIMARY KEY(`tokenHash`)
);
--> statement-breakpoint
ALTER TABLE `study_cloud_state` ADD CONSTRAINT `study_cloud_state_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `study_files` ADD CONSTRAINT `study_files_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `study_operations` ADD CONSTRAINT `study_operations_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `study_sessions` ADD CONSTRAINT `study_sessions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;