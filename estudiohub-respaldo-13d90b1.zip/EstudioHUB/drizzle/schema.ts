import { bigint, customType, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Provider subject identifier (Google sub) used to isolate the private student profile. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

const privateLongBlob = customType<{ data: Buffer; driverData: Buffer }>({ dataType: () => "longblob" });

/** Hashed, short-lived, one-use Google login nonces; raw values are never persisted. */
export const studyAuthNonces = mysqlTable("study_auth_nonces", {
  nonceHash: varchar("nonceHash", { length: 64 }).primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Opaque random browser sessions; only a SHA-256 hash of the cookie token is stored. */
export const studySessions = mysqlTable("study_sessions", {
  tokenHash: varchar("tokenHash", { length: 64 }).primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** One versioned, canonical application snapshot per private student profile. */
export const studyCloudState = mysqlTable("study_cloud_state", {
  userId: int("userId").notNull().primaryKey().references(() => users.id, { onDelete: "cascade" }),
  revision: int("revision").notNull().default(0),
  payload: json("payload").$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Idempotency receipts prevent a retried offline operation from creating duplicates. */
export const studyOperations = mysqlTable("study_operations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  operationId: varchar("operationId", { length: 80 }).notNull(),
  payloadHash: varchar("payloadHash", { length: 64 }).notNull().default(""),
  resultRevision: int("resultRevision").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [uniqueIndex("study_operations_user_operation_uq").on(table.userId, table.operationId)]);

/** Private document bytes live in the owner's database row, never at a public asset URL. */
export const studyFiles = mysqlTable("study_files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  localKey: varchar("localKey", { length: 160 }).notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 160 }).notNull(),
  size: bigint("size", { mode: "number" }).notNull(),
  checksum: varchar("checksum", { length: 64 }).notNull(),
  content: privateLongBlob("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("study_files_user_local_key_uq").on(table.userId, table.localKey)]);
