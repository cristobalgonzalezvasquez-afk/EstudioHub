CREATE TABLE `study_auth_nonces` (
	`nonceHash` varchar(64) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `study_auth_nonces_nonceHash` PRIMARY KEY(`nonceHash`)
);
