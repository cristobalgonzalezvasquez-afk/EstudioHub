const CACHE_NAME = 'estudiohub-shell-v27';
const SHELL_URLS = ['/', '/studyhub-enhancements-v16.css', '/studyhub-study-kit-v16.css', '/studyhub-study-kit-v18.js', '/studyhub-study-kit-compat-v1.js', '/studyhub-session-clock-v2.js', '/studyhub-sync-merge-v16.js', '/studyhub-training-v16.js', '/studyhub-cloud-v20.js', '/manifest.webmanifest', '/favicon.png'];
const SHELL_ASSETS = SHELL_URLS.slice(1);
const PRECACHE_TIMEOUT_MS = 15000;

async function precacheResource(cache, url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), PRECACHE_TIMEOUT_MS);
  try {
    const response = await fetch(url, { cache: 'reload', signal: controller.signal });
    if (!response.ok || response.type === 'opaque') throw new Error(`No se pudo precargar ${url}`);
    const body = await response.arrayBuffer();
    if (controller.signal.aborted) throw new Error(`La precarga agotó el tiempo para ${url}`);
    await cache.put(url, new Response(body, { status: response.status, statusText: response.statusText, headers: response.headers }));
  } finally {
    clearTimeout(timeout);
  }
}

async function findCachedShell(path) {
  const available = (await caches.keys()).filter(name => /^estudiohub-shell-v\d+$/.test(name));
  const version = name => Number(name.match(/-v(\d+)$/)?.[1] || 0);
  const names = [CACHE_NAME, ...available.filter(name => name !== CACHE_NAME).sort((a, b) => version(b) - version(a) || b.localeCompare(a))];
  for (const name of names) {
    const response = await (await caches.open(name)).match(path);
    if (response) return response;
  }
  return null;
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const results = await Promise.allSettled(SHELL_URLS.map(url => precacheResource(cache, url)));
    const failedIndex = results.findIndex(result => result.status === 'rejected');
    if (failedIndex !== -1) {
      await caches.delete(CACHE_NAME);
      throw new Error(`No se completó la precarga del shell: ${SHELL_URLS[failedIndex]}`);
    }
    const complete = await Promise.all(SHELL_URLS.map(async url => !!(await cache.match(url))));
    if (!complete.every(Boolean)) {
      await caches.delete(CACHE_NAME);
      throw new Error('La nueva caché del shell quedó incompleta.');
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const current = await caches.open(CACHE_NAME);
    const complete = await Promise.all(SHELL_URLS.map(async url => !!(await current.match(url))));
    if (complete.every(Boolean)) {
      const names = await caches.keys();
      await Promise.all(names.filter(name => name.startsWith('estudiohub-shell-') && name !== CACHE_NAME).map(name => caches.delete(name)));
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || url.pathname.startsWith('/api/') || url.pathname.startsWith('/manus-storage/') || url.pathname.startsWith('/__') || url.pathname.startsWith('/assets/')) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const network = fetch(request, { cache: 'no-store' }).then(response => {
        if (response.ok) void cache.put('/', response.clone()).catch(() => {});
        return response;
      });
      try {
        return await Promise.race([network, new Promise((_, reject) => setTimeout(() => reject(new Error('network timeout')), 2600))]);
      } catch {
        return await cache.match('/') || await findCachedShell('/') || new Response('EstudioHUB no se ha cargado en este dispositivo todavía. Conéctate una vez y vuelve a intentar.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
      }
    })());
    return;
  }
  if (SHELL_ASSETS.includes(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME), cached = await cache.match(url.pathname);
      const network = fetch(request).then(response => { if (response.ok) void cache.put(url.pathname, response.clone()).catch(() => {}); return response; });
      if (cached) { void network.catch(() => {}); return cached; }
      try { return await network; } catch { return await findCachedShell(url.pathname) || new Response('', { status: 504 }); }
    })());
  }
});
