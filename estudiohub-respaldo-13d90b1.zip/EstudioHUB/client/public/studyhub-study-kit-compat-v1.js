(function (global) {
  'use strict';

  const aliases = Object.freeze({
    multipleChoice: ['questions'],
    trueFalse: ['trueFalseQuestions'],
    shortAnswer: ['shortAnswers'],
    matchingPairs: ['pairs'],
    diagramLabels: ['diagramLabeling'],
    flashcards: ['cards'],
  });

  function normalize(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return value;
    const result = { ...value };
    for (const [canonical, names] of Object.entries(aliases)) {
      const candidates = [value[canonical], ...names.map(name => value[name])].filter(Array.isArray);
      if (candidates.length) result[canonical] = candidates.find(items => items.length > 0) || candidates[0];
    }
    return result;
  }

  function normalizeInPlace(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const normalized = normalize(value);
    let changed = false;
    for (const canonical of Object.keys(aliases)) {
      if (normalized[canonical] !== value[canonical]) {
        value[canonical] = normalized[canonical];
        changed = true;
      }
    }
    return changed;
  }

  global.StudyKitCompatibility = Object.freeze({ normalize, normalizeInPlace });
})(typeof window !== 'undefined' ? window : globalThis);
