/* Study Kit EstudioHUB: actividades Gemini online, centradas en material de la asignatura. */
(function () {
  'use strict';

  const MAX_SOURCE_CHARS = 100000;
  const MAX_FILE_COUNT = 8;
  const MAX_CLASS_COUNT = 10;
  const KIT_ARRAY_ALIASES = { multipleChoice: 'questions', trueFalse: 'trueFalseQuestions', shortAnswer: 'shortAnswers', matchingPairs: 'pairs', diagramLabels: 'diagramLabeling', flashcards: 'cards' };
  const STUDY_FILE_EXTENSIONS = new Set(['pdf','doc','docx','xls','xlsx','txt','md','csv','tsv','json','xml','png','jpg','jpeg','webp','bmp']);
  const $ = id => document.getElementById(id);
  const str = value => String(value ?? '');
  const esc = value => str(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const safeInlineId = value => /^[A-Za-z0-9_-]{1,100}$/.test(str(value)) ? str(value) : '';
  const newId = prefix => `${prefix || 'sk'}-${(crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`).replace(/[^A-Za-z0-9_-]/g, '')}`;
  let session = null;
  let timer = null;
  let saveSessionTimer = null;
  const sourceSelection = { ownerClassId: '', classIds: new Set(), fileKeys: new Set() };

  function currentClass() {
    try {
      const subject = typeof curSubject === 'function' ? curSubject() : window.curSubject?.();
      const active = typeof curClass === 'function' ? curClass(subject) : window.curClass?.(subject);
      return active || subject?.classes?.find(item => item.id === subject.activeClass) || subject?.classes?.[0] || null;
    } catch { return null; }
  }
  function ensureClass(value = currentClass()) {
    if (!value) return null;
    value.studyKitSources = (Array.isArray(value.studyKitSources) ? value.studyKitSources : []).filter(source => source && typeof source === 'object').map(source => {
      const label = str(source.label || source.name || source.title || 'Material agregado').slice(0, 255);
      return { ...source, id: str(source.id).slice(0, 200) || newId('src'), label, name: label, type: ['image', 'image-ocr'].includes(source.type) ? 'image' : 'youtube', text: str(source.text).slice(0, MAX_SOURCE_CHARS) };
    });
    value.studyKits = Array.isArray(value.studyKits) ? value.studyKits : [];
    value.studyKits.forEach(normalizeKitAliases);
    value.studyKitText = typeof value.studyKitText === 'string' ? value.studyKitText : '';
    // Retain legacy TEA fields for backup compatibility, but never use them as a Study Kit source.
    value.trainingText = typeof value.trainingText === 'string' ? value.trainingText : '';
    value.trainingHistory = Array.isArray(value.trainingHistory) ? value.trainingHistory : [];
    value.trainingProgress = value.trainingProgress && typeof value.trainingProgress === 'object' ? value.trainingProgress : { level: 1, attempts: 0, average: 0, weakTopics: [] };
    return value;
  }

  function allClassRefs() {
    try {
      if (typeof appData === 'undefined') return [];
      return (appData.subjects || []).flatMap(subject => (subject.classes || []).map(clazz => ({ subject, clazz }))).filter(ref => ref.clazz?.id);
    } catch { return []; }
  }
  function classRef(id) { return allClassRefs().find(ref => String(ref.clazz.id) === String(id)) || null; }
  function fileExtension(file) { return str(file?.name).split('.').pop().toLowerCase(); }
  function supportedStudyFile(file) {
    const ext = fileExtension(file), mime = str(file?.type || file?.mimeType).split(';')[0].toLowerCase();
    if (!STUDY_FILE_EXTENSIONS.has(ext)) return false;
    if (['png'].includes(ext)) return !mime || mime === 'image/png' || mime === 'application/octet-stream';
    if (['jpg','jpeg'].includes(ext)) return !mime || ['image/jpeg','image/jpg','application/octet-stream'].includes(mime);
    if (['webp','bmp'].includes(ext)) return !mime || mime === `image/${ext}` || mime === 'image/x-ms-bmp' || mime === 'application/octet-stream';
    if (ext === 'pdf') return !mime || mime === 'application/pdf' || mime === 'application/octet-stream';
    return true;
  }
  function initSelection(c) {
    if (!c) return;
    if (sourceSelection.ownerClassId !== String(c.id)) {
      sourceSelection.ownerClassId = String(c.id);
      sourceSelection.classIds = new Set([String(c.id)]);
      sourceSelection.fileKeys = new Set((c.files || []).filter(supportedStudyFile).slice(0, MAX_FILE_COUNT).map(file => str(file.key)).filter(Boolean));
    }
    const validClassIds = new Set(allClassRefs().map(ref => safeInlineId(ref.clazz.id)).filter(Boolean));
    for (const id of [...sourceSelection.classIds]) if (!validClassIds.has(id)) sourceSelection.classIds.delete(id);
    const validFileKeys = new Set(allClassRefs().flatMap(ref => (ref.clazz.files || []).filter(supportedStudyFile).map(file => safeInlineId(file.key)).filter(Boolean)));
    for (const key of [...sourceSelection.fileKeys]) if (!validFileKeys.has(key)) sourceSelection.fileKeys.delete(key);
  }
  function onlineReady() { return window.StudyHubCloud?.isOnlineStudyReady?.() === true; }
  function currentServerTime() {
    const value = window.StudyHubCloud?.serverNow?.();
    return Number.isSafeInteger(value) && value >= 0 ? value : null;
  }
  function requireServerTime() {
    const value = currentServerTime();
    if (value === null) throw new Error('La nube aún no confirmó la hora del servidor. Espera la sincronización antes de iniciar o reanudar esta sesión.');
    return value;
  }
  function isTimedSession(value) { return !value?.finished && (Number(value?.deadline) > 0 || value?.kind === 'matching' || value?.mode === 'formal'); }
  function normalizeKitAliases(kit) {
    if (!kit || typeof kit !== 'object' || Array.isArray(kit)) return kit;
    if (window.StudyKitCompatibility?.normalizeInPlace) window.StudyKitCompatibility.normalizeInPlace(kit);
    else for (const [canonical, alias] of Object.entries(KIT_ARRAY_ALIASES)) {
      if (Array.isArray(kit[alias]) && kit[alias].length && (!Array.isArray(kit[canonical]) || !kit[canonical].length)) kit[canonical] = kit[alias];
    }
    return kit;
  }
  function normalizeStudyKitState(state) {
    if (!state || typeof state !== 'object' || !Array.isArray(state.subjects)) return false;
    let changed = false;
    for (const subject of state.subjects) for (const clazz of Array.isArray(subject?.classes) ? subject.classes : []) {
      for (const kit of Array.isArray(clazz?.studyKits) ? clazz.studyKits : []) {
        const aliasesChanged = Object.entries(KIT_ARRAY_ALIASES).some(([canonical, alias]) => Array.isArray(kit?.[alias]) && kit[alias].length > 0 && (!Array.isArray(kit?.[canonical]) || kit[canonical].length === 0));
        normalizeKitAliases(kit);
        if (aliasesChanged) changed = true;
        for (const saved of Array.isArray(kit?.sessions) ? kit.sessions : []) {
          if (!isTimedSession(saved) || saved.status !== 'active') continue;
          if (saved.timestampBasis === 'server' && Number.isSafeInteger(saved.updatedAt)) continue;
          const remaining = Number(saved.remainingMs);
          saved.remainingMs = Number.isFinite(remaining) ? Math.max(0, Math.min(12 * 60 * 60 * 1000, Math.floor(remaining))) : 0;
          saved.deadline = 0; saved.status = 'paused'; delete saved.timestampBasis; changed = true;
        }
      }
    }
    return changed;
  }
  window.normalizeStudyKitState = normalizeStudyKitState;
  function remainingUntil(deadline) { return window.StudyKitSessionClock?.remainingUntil?.(Number(deadline)) ?? null; }
  function setMessage(id, message, error = false) {
    const element = $(id);
    if (!element) return;
    element.textContent = message;
    element.classList.toggle('is-error', error);
    element.classList.toggle('is-success', !error);
  }
  function persist() {
    try { window.saveAppData?.(); } catch (error) { console.error('Study Kit save failed', error); }
  }
  function scheduleSync() {
    window.StudyHubCloud?.syncNow?.().catch?.(() => {});
  }
  function withCloudReady(requireConfirmedCloud = true) {
    if (!navigator.onLine) throw new Error('Study Kit requiere conexión a Internet. Tus materiales locales no se modificaron.');
    if (!window.StudyHubCloud?.isSignedIn?.()) throw new Error('Inicia sesión con Google para usar Study Kit.');
    if (requireConfirmedCloud && !onlineReady()) throw new Error('Study Kit requiere que la nube confirme la sincronización antes de iniciar. Espera el estado «nube confirmada».');
  }
  async function requestAI(path, payload, timeout = 120000) {
    withCloudReady(false);
    const cloud = window.StudyHubCloud;
    if (typeof cloud?.requestStudyAI !== 'function') throw new Error('La sesión cloud todavía se está preparando. Espera a que indique «Sincronizado · nube confirmada» y vuelve a intentar.');
    return cloud.requestStudyAI(path, payload, timeout);
  }
  function selectedClassRefs() {
    initSelection(currentClass());
    return allClassRefs().filter(ref => safeInlineId(ref.clazz.id) && sourceSelection.classIds.has(String(ref.clazz.id)));
  }
  function collectMaterials() {
    const refs = selectedClassRefs();
    if (!refs.length) throw new Error('Selecciona al menos una clase para crear el Study Kit.');
    if (refs.length > MAX_CLASS_COUNT) throw new Error(`Selecciona como máximo ${MAX_CLASS_COUNT} clases.`);
    const sourceLabels = [], sourceParts = [], fileKeys = [], fileLabels = [], seenSubjects = new Set();
    for (const { subject, clazz } of refs) {
      const subjectName = str(subject.name || subject.code || 'Ramo').slice(0, 80), className = str(clazz.name || 'Clase').slice(0, 80);
      const label = `${subjectName} · ${className}`.slice(0, 180);
      sourceLabels.push(label);
      if (!seenSubjects.has(String(subject.id)) && str(subject.notes).trim()) {
        seenSubjects.add(String(subject.id));
        sourceParts.push(`[${subjectName} · Apuntes del ramo]\n${str(subject.notes).trim()}`);
      } else seenSubjects.add(String(subject.id));
      const classText = [
        str(clazz.notes).trim() && `Apuntes de ${label}:\n${str(clazz.notes).trim()}`,
        str(clazz.key).trim() && `Ideas clave de ${label}:\n${str(clazz.key).trim()}`,
        str(clazz.studyKitText).trim() && `Texto adicional de ${label}:\n${str(clazz.studyKitText).trim()}`,
      ].filter(Boolean);
      sourceParts.push(...classText);
      for (const source of clazz.studyKitSources || []) {
        if (source?.type !== 'youtube' || !str(source.text).trim()) continue;
        sourceParts.push(`[Transcripción pública ${label} · ${str(source.name || 'YouTube').slice(0, 100)}]\n${str(source.text).trim()}`);
      }
      for (const file of clazz.files || []) {
        const key = str(file.key);
        if (!key || !sourceSelection.fileKeys.has(key) || !supportedStudyFile(file)) continue;
        if (fileKeys.includes(key)) continue;
        fileKeys.push(key);
        fileLabels.push({ fileKey: key, label: `${label} · ${str(file.name || 'Archivo').slice(0, 80)}`.slice(0, 180) });
      }
    }
    if (fileKeys.length > MAX_FILE_COUNT) throw new Error(`Selecciona como máximo ${MAX_FILE_COUNT} archivos; quita alguno para continuar.`);
    const sourceText = sourceParts.join('\n\n--- FUENTE ---\n\n');
    if (sourceText.length > MAX_SOURCE_CHARS) throw new Error('Los apuntes seleccionados superan 100.000 caracteres. Reduce el texto o selecciona menos clases.');
    return { sourceText, sourceLabels: [...new Set(sourceLabels)].slice(0, 10), sourceClassIds: refs.map(ref => String(ref.clazz.id)).slice(0, MAX_CLASS_COUNT), fileKeys, fileLabels };
  }
  function selectedFileCount() { initSelection(currentClass()); return sourceSelection.fileKeys.size; }
  function sourceChoiceHTML() {
    const refs = allClassRefs(), selected = sourceSelection.classIds;
    if (!refs.length) return '<p class="study-kit-muted">Crea una clase para usar Study Kit.</p>';
    const rows = refs.map(({ subject, clazz }) => {
      const classId = safeInlineId(clazz.id), label = `${str(subject.name || subject.code || 'Ramo')} · ${str(clazz.name || 'Clase')}`;
      if (!classId) return `<div class="study-kit-class-option"><span>${esc(label)}</span><small class="study-kit-muted">No disponible para Study Kit: identificador de clase no válido.</small></div>`;
      const checked = selected.has(classId);
      const files = (clazz.files || []).filter(supportedStudyFile);
      const fileRows = checked ? (files.length ? files.map(file => {
        const key = safeInlineId(file.key), fileChecked = key && sourceSelection.fileKeys.has(key);
        return `<label class="study-kit-file-option"><input type="checkbox" ${fileChecked ? 'checked' : ''} ${key ? '' : 'disabled'} onchange="studyKitToggleFile('${classId}','${key}',this.checked)"><span><i class="fa-solid ${/\.(pdf)$/i.test(file.name) ? 'fa-file-pdf' : /\.(docx?|xlsx?)$/i.test(file.name) ? 'fa-file-word' : /\.(png|jpe?g|webp|bmp)$/i.test(file.name) ? 'fa-image' : 'fa-file-lines'}"></i> ${esc(file.name || 'Archivo')}</span><small>${(Number(file.size || 0) / 1048576).toFixed(1)} MiB</small></label>`;
      }).join('') : '<small class="study-kit-muted">Esta clase aporta sus apuntes; no tiene archivos compatibles.</small>') : '';
      return `<div class="study-kit-class-option" data-class-search="${esc(label.toLocaleLowerCase('es'))}"><label class="study-kit-class-check"><input type="checkbox" ${checked ? 'checked' : ''} onchange="studyKitToggleClass('${classId}',this.checked)"><span><b>${esc(label)}</b><small>${files.length} archivo(s) compatible(s) · también se usarán los apuntes de la clase</small></span></label>${checked ? `<div class="study-kit-file-options">${fileRows}</div>` : ''}</div>`;
    }).join('');
    return `<div class="study-kit-class-picker"><label class="study-kit-search">Buscar ramo o clase<input id="studyKitClassSearch" type="search" placeholder="Nombre del ramo o clase…" oninput="studyKitFilterClasses(this.value)"></label><div class="study-kit-class-list">${rows}</div><p class="study-kit-muted">${sourceSelection.classIds.size} clase(s) seleccionada(s), ${selectedFileCount()} de ${MAX_FILE_COUNT} archivos. Gemini recibe PDF/fotos originales; Word/Excel se convierten a PDF en el servidor. Máximo 25 MiB por archivo y 45 MiB combinados.</p></div>`;
  }
  window.studyKitToggleClass = function (id, checked) {
    initSelection(currentClass()); const ref = classRef(id); if (!ref) return;
    const classId = String(ref.clazz.id);
    if (checked && !sourceSelection.classIds.has(classId) && sourceSelection.classIds.size >= MAX_CLASS_COUNT) {
      setMessage('studyKitStatus', `Puedes seleccionar hasta ${MAX_CLASS_COUNT} clases.`, true); window.studyKitRefreshChoices(); return;
    }
    if (checked) {
      sourceSelection.classIds.add(classId);
      for (const file of (ref.clazz.files || []).filter(supportedStudyFile)) {
        const key = str(file.key); if (key && sourceSelection.fileKeys.size < MAX_FILE_COUNT) sourceSelection.fileKeys.add(key);
      }
    } else {
      sourceSelection.classIds.delete(classId);
      for (const file of ref.clazz.files || []) sourceSelection.fileKeys.delete(str(file.key));
    }
    window.studyKitRefreshChoices();
  };
  window.studyKitToggleFile = function (classId, key, checked) {
    initSelection(currentClass()); const ref = classRef(classId);
    if (!ref || !sourceSelection.classIds.has(String(classId)) || !ref.clazz.files?.some(file => String(file.key) === String(key) && supportedStudyFile(file))) return;
    if (checked && !sourceSelection.fileKeys.has(key) && sourceSelection.fileKeys.size >= MAX_FILE_COUNT) {
      setMessage('studyKitStatus', `Puedes seleccionar hasta ${MAX_FILE_COUNT} archivos.`, true); window.studyKitRefreshChoices(); return;
    }
    if (checked) sourceSelection.fileKeys.add(key); else sourceSelection.fileKeys.delete(key);
    window.studyKitRefreshChoices();
  };
  window.studyKitRefreshChoices = function () {
    const choices = $('studyKitMaterialChoices'); if (!choices) return;
    const search = str($('studyKitClassSearch')?.value);
    choices.innerHTML = sourceChoiceHTML();
    const input = $('studyKitClassSearch'); if (input) input.value = search;
    if (search) window.studyKitFilterClasses(search);
  };
  window.studyKitFilterClasses = function (value) {
    const needle = str(value).trim().toLocaleLowerCase('es');
    document.querySelectorAll('.study-kit-class-option').forEach(row => { row.hidden = !!needle && !str(row.dataset.classSearch).includes(needle); });
  };
  window.studyKitUploadFiles = async function (list) {
    const c = currentClass(), files = Array.from(list || []); if (!c || !files.length) return;
    const allowed = files.filter(file => supportedStudyFile({ name:file.name, type:file.type }));
    if (allowed.length !== files.length) setMessage('studyKitStatus', 'Se omitieron archivos no compatibles. Se aceptan PDF, Word/Excel, texto e imágenes PNG/JPEG/WebP/BMP.', true);
    if (allowed.some(file => file.size > 25 * 1024 * 1024)) { setMessage('studyKitStatus', 'Cada archivo debe pesar como máximo 25 MiB.', true); return; }
    const remaining = MAX_FILE_COUNT - selectedFileCount();
    if (allowed.length > remaining) { setMessage('studyKitStatus', `Selecciona como máximo ${remaining} archivo(s) más para este Study Kit.`, true); return; }
    const before = new Set((c.files || []).map(file => str(file.key)));
    try {
      if (typeof addClassFiles !== 'function') throw new Error('No se encontró el cargador de archivos de la clase.');
      await addClassFiles(allowed);
      const updated = currentClass(); if (!updated) return;
      initSelection(updated); sourceSelection.classIds.add(String(updated.id));
      for (const file of updated.files || []) if (!before.has(str(file.key)) && supportedStudyFile(file) && sourceSelection.fileKeys.size < MAX_FILE_COUNT) sourceSelection.fileKeys.add(str(file.key));
      setTimeout(scheduleSync, 900); window.renderSubjectPanel?.();
      setMessage('studyKitStatus', 'Los archivos se guardaron en la clase y se sincronizarán. Study Kit solo los enviará cuando la nube confirme la carga.');
    } catch (error) { setMessage('studyKitStatus', error.message || 'No se pudieron guardar los archivos.', true); }
  };
  let manualTextSaveTimer = null;
  window.studyKitSaveManualText = function (value) {
    const c = currentClass(); if (!c) return;
    c.studyKitText = str(value).slice(0, 20000); persist();
    clearTimeout(manualTextSaveTimer); manualTextSaveTimer = setTimeout(scheduleSync, 900);
  };
  function htmlStatus(c) {
    if (!navigator.onLine) return 'Sin conexión: Study Kit está pausado. No se analizarán materiales ni se aceptarán respuestas hasta recuperar Internet y nube confirmada.';
    if (!window.StudyHubCloud?.isSignedIn?.()) return 'Inicia sesión con Google para activar Study Kit y confirmar el perfil en la nube.';
    return onlineReady() ? 'Online · sesión Google activa · nube confirmada.' : 'Conectado: Study Kit espera la confirmación cloud antes de abrir actividades.';
  }
  function formatCounts(kit) {
    kit = normalizeKitAliases(kit);
    const count = key => Array.isArray(kit[key]) ? kit[key].length : 0;
    return `${count('multipleChoice')} alternativas · ${count('trueFalse')} V/F · ${count('shortAnswer')} respuesta corta · ${count('matchingPairs')} parejas · ${count('ordering')} ordenamiento · ${count('diagramLabels')} esquemas · ${count('flashcards')} tarjetas`;
  }
  function sessionLabel(saved) {
    const mode = saved.kind === 'flashcards' ? 'Tarjetas' : saved.kind.startsWith('matching') ? 'Pareados' : saved.mode === 'formal' ? 'Simulacro' : 'Smart Study';
    const status = saved.status === 'finished' || saved.finished ? 'terminada' : saved.status === 'active' ? 'en curso' : 'pausada';
    const total = saved.kind === 'quiz' ? saved.questions?.length || 0 : saved.kind === 'flashcards' ? saved.cards?.length || 0 : saved.pairs?.length || 0;
    return `${mode} · ${status} · ${Math.min(Number(saved.index || 0) + 1, total || 1)}/${total || 1}`;
  }
  function kitCard(kit) {
    kit = normalizeKitAliases(kit);
    const id = safeInlineId(kit.id);
    if (!id) return '<article class="study-kit-item"><p class="study-kit-muted">Este Study Kit tiene un identificador no válido y no se abrirá por seguridad.</p></article>';
    const failedQuestions = Array.isArray(kit.failedQuestionIds) ? kit.failedQuestionIds.length : 0;
    const failedPairs = Array.isArray(kit.failedPairIds) ? kit.failedPairIds.length : 0;
    const failures = failedQuestions + failedPairs;
    const questions = questionPool(kit).length;
    const due = dueFlashcards(kit).length;
    const guide = kit.studyGuide || {};
    const sessions = Array.isArray(kit.sessions) ? kit.sessions.filter(saved => safeInlineId(saved?.id)).slice().sort((a,b)=>Number(b.updatedAt||b.startedAt)-Number(a.updatedAt||a.startedAt)).slice(0,8) : [];
    const sources = [...(kit.sourceLabels || []), ...(kit.sourceFiles || []).map(file => file.label || file.name)].filter(Boolean);
    const locked = onlineReady() ? '' : 'disabled aria-disabled="true" title="Requiere Internet, sesión Google y nube confirmada"';
    return `<article class="study-kit-item"><div class="study-kit-item-head"><div><h5>${esc(kit.title || 'Study Kit')}</h5><p>${esc(kit.difficulty || 'Intermedio')} · ${esc(formatCounts(kit))}</p><p>${esc(kit.history?.length || 0)} intento(s) · ${failures} error(es) pendiente(s) · ${due} tarjeta(s) vencida(s)</p>${sources.length ? `<details class="study-kit-source-summary"><summary>Fuentes de este kit (${sources.length})</summary><ul>${sources.map(name=>`<li>${esc(name)}</li>`).join('')}</ul></details>` : ''}</div><span class="study-kit-chip">${questions} preguntas</span></div><div class="study-kit-actions">${guide.summary || guide.keyPoints?.length ? `<button type="button" ${locked} onclick="studyKitShowGuide('${esc(id)}')">Guía y resumen</button>` : ''}${questions ? `<button type="button" class="primary" ${locked} onclick="studyKitStart('${esc(id)}','practice')">Smart Study</button><button type="button" class="secondary" ${locked} onclick="studyKitStart('${esc(id)}','formal')">Simulacro formal</button>` : ''}${failedQuestions ? `<button type="button" ${locked} onclick="studyKitStart('${esc(id)}','practice',true)">Reintentar preguntas falladas (${failedQuestions})</button>` : ''}${kit.matchingPairs?.length ? `<button type="button" ${locked} onclick="studyKitStartMatching('${esc(id)}')">Términos pareados</button>` : ''}${failedPairs ? `<button type="button" ${locked} onclick="studyKitStartMatching('${esc(id)}',true)">Reintentar parejas falladas (${failedPairs})</button>` : ''}${kit.flashcards?.length ? `<button type="button" ${locked} onclick="studyKitStartFlashcards('${esc(id)}')">Repasar tarjetas</button>` : ''}<button type="button" class="danger" onclick="studyKitDelete('${esc(id)}')" aria-label="Eliminar Study Kit">Eliminar</button></div>${sessions.length ? `<details class="study-kit-sessions"><summary>Sesiones guardadas (${kit.sessions.length})</summary>${sessions.map(saved=>`<div class="study-kit-saved-session"><span>${esc(sessionLabel(saved))}</span><button type="button" ${locked} onclick="studyKitResumeSession('${esc(id)}','${esc(saved.id)}')">${saved.status === 'finished' || saved.finished ? 'Ver resultado' : 'Continuar'}</button></div>`).join('')}</details>` : ''}</article>`;
  }
  function sourceList(c) {
    const sources = c.studyKitSources.filter(item => item.type === 'youtube');
    return sources.length ? `<ul class="study-kit-source-list">${sources.map(item => { const id = safeInlineId(item.id); return `<li><div><b>${esc(item.name || item.title || 'Transcripción')}</b><small>Subtítulos públicos · ${Number(str(item.text).length).toLocaleString()} caracteres</small></div>${id ? `<button type="button" onclick="studyKitRemoveSource('${id}')" aria-label="Quitar transcripción">×</button>` : ''}</li>`; }).join('')}</ul>` : '<p class="study-kit-muted">Las transcripciones públicas de YouTube son opcionales; PDF, fotos y documentos se adjuntan directamente.</p>';
  }

  window.studyKitRenderCurrentSession = function () { if (session) renderSession(); };
  window.studyKitPanelHTML = function (rawClass) {
    const c = ensureClass(rawClass);
    if (!c) return '';
    initSelection(c);
    const kits = c.studyKits.map(kitCard).join('') || '<p class="study-kit-muted">Aún no hay Study Kits. Selecciona las clases y materiales que quieras estudiar y crea uno con Gemini.</p>';
    const disabled = !onlineReady();
    return `<section class="study-kit-panel" aria-labelledby="studyKitHeading">
      <div class="study-kit-hero"><div><span class="study-kit-eyebrow">GEMINI · ONLINE</span><h4 id="studyKitHeading"><i class="fa-solid fa-wand-magic-sparkles"></i> Estudio IA · Study Kit</h4><p>Selecciona varias clases y sus materiales. Gemini analiza los archivos originales y guarda tus sesiones para retomarlas después.</p></div><span class="study-kit-cloud-badge">${disabled ? 'Conexión requerida' : 'Nube confirmada'}</span></div>
      <div class="study-kit-status" id="studyKitCloudStatus" role="status" aria-live="polite">${esc(htmlStatus(c))}</div>
      <div class="study-kit-source-tools"><div><h5>Ramos, clases y materiales</h5><p>No se extrae texto en el navegador. Gemini recibe PDF y fotos como archivos originales; Word/Excel se convierten a PDF en el servidor.</p></div><label class="study-kit-upload">Añadir archivos a esta clase<input type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.md,.csv,.tsv,.json,.xml,.png,.jpg,.jpeg,.webp,.bmp" onchange="studyKitUploadFiles(this.files);this.value=''"></label></div>
      <div id="studyKitMaterialChoices">${sourceChoiceHTML()}</div>
      <div class="study-kit-youtube"><label for="studyKitYoutubeUrl">Enlace público de YouTube (subtítulos disponibles)</label><div><input id="studyKitYoutubeUrl" type="url" placeholder="https://www.youtube.com/watch?v=…" inputmode="url" maxlength="500"><button type="button" id="studyKitYoutube" onclick="studyKitAddYouTube()" ${disabled ? 'disabled' : ''}>Añadir transcripción</button></div></div>
      ${sourceList(c)}
      <label class="study-kit-source-text" for="studyKitManualText"><b>Texto adicional (opcional)</b><span>Se combina con los apuntes de las clases seleccionadas.</span><textarea id="studyKitManualText" rows="4" maxlength="20000" placeholder="Pega aquí texto que quieras estudiar…" oninput="studyKitSaveManualText(this.value)">${esc(c.studyKitText || '')}</textarea></label>
      <fieldset class="study-kit-fieldset"><legend>Qué incluir</legend><div class="study-kit-format-grid">
        ${[['multipleChoice','Alternativas'],['trueFalse','Verdadero / Falso'],['shortAnswer','Respuesta corta'],['matchingPairs','Términos pareados'],['ordering','Ordenamiento'],['diagramLabels','Etiquetar esquema']].map(([value,label], index) => `<label><input class="study-kit-format" type="checkbox" value="${value}" ${index < 5 ? 'checked' : ''}><span>${label}</span></label>`).join('')}
      </div></fieldset>
      <div class="study-kit-config"><label>Dificultad<select id="studyKitDifficulty"><option>Fácil</option><option selected>Intermedio</option><option>Avanzado/Certamen</option></select></label><label>Preguntas<select id="studyKitCount"><option>5</option><option selected>10</option><option>15</option><option>20</option></select></label><label>Tiempo de simulacro (requerido)<select id="studyKitMinutes"><option>10</option><option selected>20</option><option>30</option><option>45</option><option>60</option></select></label></div>
      <div class="study-kit-extras"><label><input id="studyKitFlashcards" type="checkbox" checked> Añadir fichas de repetición espaciada</label><label><input id="studyKitPodcast" type="checkbox"> Crear guion de audio explicativo</label></div>
      <button type="button" class="study-kit-generate" id="studyKitGenerate" onclick="studyKitGenerate()" ${disabled ? 'disabled' : ''}><i class="fa-solid fa-sparkles"></i> Generar Study Kit con Gemini</button>
      <div class="study-kit-status" id="studyKitStatus" role="status" aria-live="polite"></div>
      <div class="study-kit-progress-summary"><b>Dominio en Study Kit</b><span>Nivel ${studyKitProgress(c).level} / 3 · ${studyKitProgress(c).attempts} intento(s) · ${studyKitProgress(c).average.toFixed(0)}% reciente</span>${studyKitProgress(c).weakTopics.length ? `<small>Puntos débiles: ${esc(studyKitProgress(c).weakTopics.join(', '))}</small>` : ''}</div>
      <div class="study-kit-list" id="studyKitList">${kits}</div><div id="studyKitPlay" class="study-kit-play" aria-live="polite"></div>
      <p class="study-kit-footnote">Study Kit analiza en línea los archivos elegidos con Gemini, requiere sesión Google y nube confirmada, y guarda sesiones reanudables en tu perfil. El procesamiento local de actividades IA se retiró; las demás funciones de EstudioHUB mantienen su modo offline.</p>
    </section>`;
  };

  function questionPool(kit) {
    kit = normalizeKitAliases(kit);
    const result = [];
    for (const q of kit.multipleChoice || kit.questions || []) result.push({ ...q, type: 'multipleChoice' });
    for (const q of kit.trueFalse || kit.trueFalseQuestions || []) result.push({ ...q, type: 'trueFalse' });
    for (const q of kit.shortAnswer || kit.shortAnswers || []) result.push({ ...q, type: 'shortAnswer' });
    for (const q of kit.ordering || []) result.push({ ...q, type: 'ordering' });
    for (const q of kit.diagramLabels || kit.diagramLabeling || []) result.push({ ...q, type: 'diagramLabels' });
    for (const q of kit.followUps || []) result.push({ ...q, type: q.type || 'multipleChoice', isFollowUp: true });
    const questions = result.map(normalizeQuestion).filter(Boolean);
    const pairs = (Array.isArray(kit.matchingPairs) ? kit.matchingPairs : []).filter(pair => str(pair?.left).trim() && str(pair?.right).trim()).slice(0, 20);
    if (pairs.length) {
      const definitions = shuffle(pairs.map((pair, index) => ({ leftIndex: index, text: str(pair.right) })));
      const safeKitId = str(kit.id).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 70);
      questions.push({ id: `matching_${safeKitId}`, type: 'matchingSet', question: 'Relaciona cada concepto con su definición.', topic: 'Términos pareados', matchingPairs: pairs, definitions, answerKey: pairs.map((pair, index) => definitions.findIndex(definition => definition.leftIndex === index)), sourceQuote: str(pairs[0].sourceQuote), sourceFileId:str(pairs[0].sourceFileId), sourcePage:pairs[0].sourcePage });
    }
    return questions;
  }
  function normalizeQuestion(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const aliases = { multiple_choice: 'multipleChoice', 'multiple-choice': 'multipleChoice', true_false: 'trueFalse', 'true/false': 'trueFalse', short_answer: 'shortAnswer', 'short-answer': 'shortAnswer', diagram_labeling: 'diagramLabels', 'diagram-labeling': 'diagramLabels', matching: 'matchingPairs' };
    const type = aliases[raw.type] || raw.type || 'multipleChoice';
    const isFollowUp = raw.isFollowUp === true;
    const id = /^[A-Za-z0-9_-]{1,100}$/.test(str(raw.id)) ? str(raw.id) : newId('q');
    const question = str(raw.question || raw.prompt).trim();
    const sourceQuote = str(raw.sourceQuote || raw.evidence).trim();
    if (!question || !sourceQuote) return null;
    if (type === 'multipleChoice') {
      const options = (Array.isArray(raw.options) ? raw.options : []).map(str).map(x=>x.trim()).filter(Boolean);
      const correctIndex = raw.correctIndex == null && isFollowUp ? -1 : Number(raw.correctIndex ?? raw.answerIndex);
      if (options.length < 2 || (!isFollowUp && (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= options.length)) || (isFollowUp && correctIndex !== -1 && (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= options.length))) return null;
      return { ...raw, id, type, question, options, correctIndex, sourceQuote, topic: str(raw.topic || 'Concepto clave'), isFollowUp };
    }
    if (type === 'trueFalse') return { ...raw, id, type, question, answer: typeof raw.answer === 'boolean' ? raw.answer : isFollowUp ? null : raw.answer === 'true', sourceQuote, topic: str(raw.topic || 'Concepto clave'), isFollowUp };
    if (type === 'shortAnswer') return { ...raw, id, type, question, expectedAnswer: str(raw.expectedAnswer || raw.answer || raw.correctAnswer), rubric: Array.isArray(raw.rubric) ? raw.rubric.map(str) : [], sourceQuote, topic: str(raw.topic || 'Concepto clave'), isFollowUp };
    if (type === 'ordering') {
      const items = Array.isArray(raw.items) ? raw.items.map(str) : [];
      const correctOrder = Array.isArray(raw.correctOrder) ? raw.correctOrder.map(Number) : [];
      if (items.length < (isFollowUp ? 3 : 2) || (!isFollowUp && (correctOrder.length !== items.length || new Set(correctOrder).size !== items.length || correctOrder.some(n=>!Number.isInteger(n)||n<0||n>=items.length)))) return null;
      return { ...raw, id, type, question, items, correctOrder, sourceQuote, topic: str(raw.topic || 'Secuencia'), isFollowUp };
    }
    if (type === 'diagramLabels') {
      const labels = Array.isArray(raw.labels) ? raw.labels.map(item => ({ prompt: str(item?.prompt || item?.label || item?.slot), options: Array.isArray(item?.options) ? item.options.map(str).map(value=>value.trim()).filter(Boolean) : [], correctIndex: Number(item?.correctIndex) })) : [];
      if (labels.length < 2 || labels.length > 6 || labels.some(item=>!item.prompt || item.options.length < 2 || !Number.isInteger(item.correctIndex) || item.correctIndex < 0 || item.correctIndex >= item.options.length)) return null;
      return { ...raw, id, type, question, diagramDescription: str(raw.diagramDescription || raw.diagram || ''), labels, sourceQuote, topic: str(raw.topic || 'Esquema'), isFollowUp };
    }
    return null;
  }
  function findKit(id) {
    const safeId = safeInlineId(id); if (!safeId) return null;
    const current = ensureClass();
    const local = current?.studyKits.find(kit => safeInlineId(kit.id) === safeId);
    if (local) return normalizeKitAliases(local);
    for (const { clazz } of allClassRefs()) {
      const kit = (Array.isArray(clazz.studyKits) ? clazz.studyKits : []).find(item => safeInlineId(item?.id) === safeId);
      if (kit) return normalizeKitAliases(kit);
    }
    return null;
  }
  function materialsForKit(kit) {
    return {
      sourceText: str(kit?.sourceText),
      sourceLabels: Array.isArray(kit?.sourceLabels) ? kit.sourceLabels : [],
      sourceClassIds: Array.isArray(kit?.sourceClassIds) ? kit.sourceClassIds : [],
      fileKeys: Array.isArray(kit?.sourceFiles) ? kit.sourceFiles.map(file => str(file.fileKey)).filter(Boolean) : [],
      fileLabels: Array.isArray(kit?.sourceFiles) ? kit.sourceFiles.map(file => ({ fileKey:str(file.fileKey), sourceId:str(file.sourceId), label:str(file.label || file.name) })).filter(file => file.fileKey) : [],
    };
  }
  function normalizedStudyText(value) { return str(value).normalize('NFKC').replace(/\s+/g, ' ').trim().toLocaleLowerCase('es'); }
  function quoteInNotes(kit, quote) { const normalized = normalizedStudyText(quote); return normalized.length >= 12 && normalizedStudyText(kit?.sourceText).includes(normalized); }
  function sourceIdsIn(value) {
    const result = new Set();
    const visit = item => {
      if (Array.isArray(item)) { item.forEach(visit); return; }
      if (!item || typeof item !== 'object') return;
      if (typeof item.sourceFileId === 'string' && item.sourceFileId) result.add(item.sourceFileId);
      Object.values(item).forEach(visit);
    };
    visit(value); return result;
  }
  function materialsForItems(kit, items) {
    const all = materialsForKit(kit), list = Array.isArray(items) ? items : [items], sourceIds = new Set();
    for (const item of list) for (const id of sourceIdsIn(item)) sourceIds.add(id);
    const needsUnattributedFiles = list.some(item => sourceIdsIn(item).size === 0 && !quoteInNotes(kit, item?.sourceQuote));
    if (needsUnattributedFiles) return all;
    if (!sourceIds.size) return { ...all, fileKeys: [], fileLabels: [] };
    const files = (kit?.sourceFiles || []).filter(file => sourceIds.has(str(file.sourceId)));
    if (files.length !== sourceIds.size) throw new Error('No se encontró una de las fuentes privadas de este Study Kit. Vuelve a sincronizar el perfil antes de continuar.');
    return {
      ...all,
      fileKeys: files.map(file => str(file.fileKey)).filter(Boolean),
      fileLabels: files.map(file => ({ fileKey:str(file.fileKey), sourceId:str(file.sourceId), label:str(file.label || file.name) })).filter(file => file.fileKey),
    };
  }
  function saveSessionSnapshot() {
    if (!session?.kitId || !session.id) return;
    const kit = findKit(session.kitId); if (!kit) return;
    try {
      const snapshot = JSON.parse(JSON.stringify(session));
      const deadlineRemaining = snapshot.deadline > 0 ? remainingUntil(snapshot.deadline) : null;
      const remaining = deadlineRemaining === null ? Number(snapshot.pausedRemaining || snapshot.remainingMs || 0) : deadlineRemaining;
      snapshot.remainingMs = Math.max(0, Math.min(12 * 60 * 60 * 1000, Math.floor(remaining)));
      const serverTimestamp = currentServerTime();
      snapshot.status = snapshot.finished && snapshot.gradeResults ? 'finished' : (!onlineReady() || serverTimestamp === null || snapshot.status === 'paused' || snapshot.pausedOffline || snapshot.pausedRemaining ? 'paused' : 'active');
      snapshot.deadline = snapshot.status === 'active' ? Number(snapshot.deadline || 0) : 0;
      if (Number.isSafeInteger(serverTimestamp)) { snapshot.updatedAt = serverTimestamp; snapshot.timestampBasis = 'server'; }
      else if (snapshot.timestampBasis !== 'server') delete snapshot.timestampBasis;
      delete snapshot.pausedOffline; delete snapshot.pausedRemaining; delete snapshot.pausedForClock; delete snapshot.evaluating; delete snapshot._lastSavedBucket;
      snapshot.grading = false;
      kit.sessions = Array.isArray(kit.sessions) ? kit.sessions : [];
      const existing = kit.sessions.findIndex(item => item.id === snapshot.id);
      if (existing >= 0) kit.sessions[existing] = snapshot; else kit.sessions.unshift(snapshot);
      kit.sessions.sort((a, b) => Number(b.updatedAt || b.startedAt) - Number(a.updatedAt || a.startedAt));
      kit.sessions = kit.sessions.slice(0, 10);
      persist();
      clearTimeout(saveSessionTimer); saveSessionTimer = setTimeout(scheduleSync, 800);
    } catch (error) { console.error('No se pudo guardar el progreso de Study Kit', error); }
  }
  function refreshList() {
    const c = ensureClass(), list = $('studyKitList');
    if (c && list) list.innerHTML = c.studyKits.map(kitCard).join('') || '<p class="study-kit-muted">Aún no hay Study Kits. Selecciona clases y materiales para crear el primero con Gemini.</p>';
    const state = $('studyKitCloudStatus'); if (state) state.textContent = htmlStatus(c);
    const generate = $('studyKitGenerate'); if (generate) generate.disabled = !onlineReady();
    const youtube = $('studyKitYoutube'); if (youtube) youtube.disabled = !onlineReady();
  }
  function validateKitCitations(kit) {
    kit = normalizeKitAliases(kit);
    const sourceFiles = Array.isArray(kit.sourceFiles) ? kit.sourceFiles : [];
    const sourceIds = new Map(sourceFiles.map(file => [str(file.sourceId), file]));
    const items = [...questionPool(kit), ...(kit.matchingPairs || []), ...(kit.flashcards || []), ...(kit.studyGuide?.glossary || [])];
    if (kit.studyGuide?.sourceQuote) items.push(kit.studyGuide);
    for (const item of items) {
      const quote = str(item.sourceQuote), sourceId = str(item.sourceFileId), source = sourceId ? sourceIds.get(sourceId) : null;
      if (quote.trim().length < 12 || quote.length > 400) throw new Error('Gemini devolvió una referencia de material incompleta; el kit no se guardó.');
      if (sourceId && !source) throw new Error('Gemini devolvió un archivo de procedencia que no fue seleccionado; el kit no se guardó.');
      if (!sourceId && item.sourcePage !== undefined) throw new Error('Gemini devolvió una página sin archivo de procedencia; el kit no se guardó.');
      if (!sourceId && sourceFiles.length && !quoteInNotes(kit, quote)) throw new Error('Gemini no identificó el archivo de origen de una pregunta; el kit no se guardó para evitar perder su material al reanudar.');
      if (sourceId && item.sourcePage !== undefined) {
        const mime = str(source.mimeType).split(';')[0].toLowerCase(), page = Number(item.sourcePage);
        if (!Number.isSafeInteger(page) || page < 1 || page > 1_000 || !mime.startsWith('image/') && mime !== 'application/pdf' || mime.startsWith('image/') && page !== 1) throw new Error('Gemini devolvió una página no válida para el archivo de procedencia.');
      }
    }
  }

  window.studyKitGenerate = async function () {
    const c = ensureClass(); if (!c) return;
    let materials;
    try { withCloudReady(); materials = collectMaterials(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    if (!materials.sourceText.trim() && !materials.fileKeys.length) { setMessage('studyKitStatus', 'Selecciona apuntes, archivos o transcripciones para generar el Study Kit.', true); return; }
    const formats = [...document.querySelectorAll('.study-kit-format:checked')].map(input => input.value);
    const count = Number($('studyKitCount')?.value || 10);
    if (!formats.length || formats.length > count) { setMessage('studyKitStatus', 'Selecciona al menos una modalidad y no más modalidades que preguntas. Aumenta la cantidad o desmarca alguna.', true); return; }
    const button = $('studyKitGenerate'); if (button) { button.disabled = true; button.textContent = 'Preparando guía y actividades…'; }
    setMessage('studyKitStatus', `Gemini está analizando ${materials.sourceClassIds.length} clase(s) y ${materials.fileKeys.length} archivo(s) seleccionados…`);
    try {
      const data = await requestAI('/api/gemini/study-kit', { sourceClassIds: materials.sourceClassIds, fileKeys: materials.fileKeys, difficulty: $('studyKitDifficulty')?.value || 'Intermedio', count, formats, includeFlashcards: !!$('studyKitFlashcards')?.checked, includePodcast: !!$('studyKitPodcast')?.checked });
      const raw = data.kit || data;
      const kit = {
        ...raw, id: /^[A-Za-z0-9_-]{1,100}$/.test(str(raw.id)) ? str(raw.id) : newId('kit'), title: str(raw.title || 'Study Kit de las clases seleccionadas').slice(0,120), difficulty: str(raw.difficulty || $('studyKitDifficulty')?.value || 'Intermedio'), createdAt: new Date().toISOString(), sourceText: typeof raw.sourceText === 'string' ? raw.sourceText : materials.sourceText, sourceLabels: Array.isArray(raw.sourceLabels) ? raw.sourceLabels : materials.sourceLabels, sourceClassIds: Array.isArray(raw.sourceClassIds) ? raw.sourceClassIds : materials.sourceClassIds, sourceLength: Number.isSafeInteger(raw.sourceLength) ? raw.sourceLength : materials.sourceText.length, sourceFiles: Array.isArray(raw.sourceFiles) ? raw.sourceFiles : [], sessions: [],
        studyGuide: raw.studyGuide && typeof raw.studyGuide === 'object' ? raw.studyGuide : {},
        multipleChoice: Array.isArray(raw.multipleChoice) ? raw.multipleChoice : [], trueFalse: Array.isArray(raw.trueFalse) ? raw.trueFalse : [], shortAnswer: Array.isArray(raw.shortAnswer) ? raw.shortAnswer : [], ordering: Array.isArray(raw.ordering) ? raw.ordering : [], diagramLabels: Array.isArray(raw.diagramLabels) ? raw.diagramLabels : [], matchingPairs: Array.isArray(raw.matchingPairs) ? raw.matchingPairs : [], flashcards: Array.isArray(raw.flashcards) ? raw.flashcards : [], followUps: [], failedQuestionIds: [], history: [], spacedRepetition: {}
      };
      normalizeKitAliases(kit);
      const usedIds = new Set();
      const assignIds = (items, prefix) => items.map((item, index) => { const candidate = str(item?.id); const id = /^[A-Za-z0-9_-]{1,100}$/.test(candidate) && !usedIds.has(candidate) ? candidate : `${prefix}-${index + 1}-${newId('id')}`; usedIds.add(id); return { ...item, id }; });
      for (const [key, prefix] of [['multipleChoice','mc'],['trueFalse','tf'],['shortAnswer','sa'],['ordering','ord'],['diagramLabels','diag'],['matchingPairs','pair'],['flashcards','card']]) kit[key] = assignIds(kit[key], prefix);
      if (!questionPool(kit).length && !kit.matchingPairs.length && !kit.flashcards.length && !kit.studyGuide.summary) throw new Error('La salida de Gemini no contiene actividades válidas.');
      validateKitCitations(kit);
      c.studyKits.unshift(kit); persist(); refreshList();
      setMessage('studyKitStatus', 'Study Kit guardado en esta asignatura. Los cambios se sincronizarán con la nube.');
      setTimeout(scheduleSync, 900);
    } catch (error) { setMessage('studyKitStatus', error.message || 'No se pudo generar el Study Kit.', true); }
    finally { if (button) { button.disabled = !onlineReady(); button.innerHTML = '<i class="fa-solid fa-sparkles"></i> Generar Study Kit con Gemini'; } }
  };

  function stableSourceId(prefix, value) { return `${prefix}-${str(value).replace(/[^A-Za-z0-9_-]/g,'').slice(0,70) || newId('src')}`; }
  function addSource(c, source) {
    const id = str(source.id || newId('src'));
    const index = c.studyKitSources.findIndex(item => item.id === id);
    const label = str(source.label || source.name || source.title || 'Material agregado').slice(0, 255);
    const value = { ...source, id, label, name: label, type: ['image', 'image-ocr'].includes(source.type) ? 'image' : 'youtube', text: str(source.text).trim().slice(0, MAX_SOURCE_CHARS), addedAt: new Date().toISOString() };
    if (index >= 0) c.studyKitSources[index] = value; else c.studyKitSources.unshift(value);
    persist(); refreshList();
  }
  window.studyKitAddYouTube = async function () {
    const c = ensureClass(); if (!c) return;
    try { withCloudReady(false); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    const input = $('studyKitYoutubeUrl'), url = str(input?.value).trim();
    if (!url) { setMessage('studyKitStatus', 'Pega un enlace público de YouTube.', true); return; }
    setMessage('studyKitStatus', 'Buscando subtítulos públicos del video…');
    const buttons = [...document.querySelectorAll('.study-kit-youtube button')], button = buttons[0]; if (button) button.disabled = true;
    try {
      const data = await requestAI('/api/study/youtube-transcript', { url }, 60000);
      if (!str(data.text).trim() || str(data.text).trim().length < 100) throw new Error('El video no tiene suficientes subtítulos públicos. Añade el resumen o los apuntes manualmente.');
      const videoId = str(data.videoId || url).replace(/[^A-Za-z0-9_-]/g,'').slice(0,80);
      addSource(c, { id: stableSourceId('youtube', videoId), type: 'youtube', name: `YouTube · ${str(data.title || videoId).slice(0,100)}`, text: str(data.text).slice(0,40000), url: url.slice(0,500) });
      if (input) input.value = '';
      setMessage('studyKitStatus', 'Transcripción añadida. Las actividades se generarán solo desde ese texto y los demás materiales de la clase.');
    } catch (error) { setMessage('studyKitStatus', error.message || 'No se pudo importar la transcripción.', true); }
    finally { if (button) button.disabled = !onlineReady(); }
  };
  window.studyKitRemoveSource = function (id) {
    const c = ensureClass(); if (!c) return;
    const source = c.studyKitSources.find(item => item.id === id);
    if (!source || !confirm(`¿Quitar la fuente «${source.name || source.title || 'Material'}» del Study Kit? El archivo original de la clase no se eliminará.`)) return;
    c.studyKitSources = c.studyKitSources.filter(item => item.id !== id); persist(); refreshList();
  };
  window.studyKitDelete = function (id) {
    const c = ensureClass(); if (!c) return;
    const kit = c.studyKits.find(item => item.id === id);
    if (!kit || !confirm(`¿Eliminar «${kit.title}» y sus intentos guardados de esta asignatura?`)) return;
    c.studyKits = c.studyKits.filter(item => item.id !== id); persist(); refreshList();
  };

  window.studyKitShowGuide = function (id) {
    const kit = findKit(id), play = $('studyKitPlay'); if (!kit || !play) return;
    try { withCloudReady(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    const guide = kit.studyGuide || {}, points = Array.isArray(guide.keyPoints) ? guide.keyPoints : [], glossary = Array.isArray(guide.glossary) ? guide.glossary : [], questions = Array.isArray(guide.questions) ? guide.questions : [];
    play.innerHTML = `<article class="study-kit-guide"><header><div><span>GUÍA DE ESTUDIO</span><h4>${esc(kit.title)}</h4></div><button type="button" onclick="document.getElementById('studyKitPlay').replaceChildren()" aria-label="Cerrar guía">×</button></header><p>${esc(guide.summary || 'No se generó un resumen.')}</p>${points.length ? `<h5>Puntos centrales</h5><ul>${points.map(item=>`<li>${esc(item)}</li>`).join('')}</ul>` : ''}${glossary.length ? `<h5>Glosario</h5><dl>${glossary.map(item=>`<dt>${esc(item.term || item.concept)}</dt><dd>${esc(item.definition || item.meaning)}</dd>`).join('')}</dl>` : ''}${questions.length ? `<h5>Preguntas para recordar</h5><ol>${questions.map(item=>`<li>${esc(item)}</li>`).join('')}</ol>` : ''}${sourceCitationHTML(guide, id)}${guide.podcastScript ? `<div class="study-kit-podcast"><h5>Guion de audio</h5><p>${esc(guide.podcastScript)}</p><button type="button" onclick="studyKitSpeak('${esc(id)}')"><i class="fa-solid fa-volume-high"></i> Escuchar</button><button type="button" onclick="studyKitStopSpeaking()">Detener</button></div>` : ''}</article>`;
  };
  window.studyKitSpeak = function (id) {
    try { withCloudReady(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    const kit = findKit(id), script = str(kit?.studyGuide?.podcastScript || '');
    if (!script || !('speechSynthesis' in window)) { setMessage('studyKitStatus', 'La lectura en voz alta no está disponible en este navegador.', true); return; }
    speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(script); utterance.lang = 'es-CL'; speechSynthesis.speak(utterance);
  };
  window.studyKitStopSpeaking = function () { if ('speechSynthesis' in window) speechSynthesis.cancel(); };

  function shuffle(items) {
    const result = items.slice();
    for (let i = result.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [result[i], result[j]] = [result[j], result[i]]; }
    return result;
  }
  window.studyKitStart = function (id, mode, failedOnly = false) {
    const kit = findKit(id); if (!kit) return;
    let serverTimestamp;
    try { withCloudReady(); serverTimestamp = requireServerTime(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    let questions = questionPool(kit);
    if (failedOnly) questions = questions.filter(question => (kit.failedQuestionIds || []).includes(question.id));
    if (!questions.length) { setMessage('studyKitStatus', failedOnly ? 'No hay preguntas falladas pendientes.' : 'Este Study Kit no contiene preguntas interactivas.'); return; }
    const minutes = mode === 'formal' ? Math.max(1, Math.min(180, Number($('studyKitMinutes')?.value || 20))) : 0;
    const remainingMs = minutes * 60_000, deadline = minutes ? window.StudyKitSessionClock?.deadlineAfter?.(remainingMs) : 0;
    if (minutes && !Number.isSafeInteger(deadline)) { setMessage('studyKitStatus', 'No se pudo iniciar el temporizador porque falta una hora de servidor confirmada.', true); return; }
    session = { id:newId('session'), kind: 'quiz', kitId: id, mode, status:'active', questions, answers: {}, drafts:{}, index: 0, startedAt: serverTimestamp, updatedAt:serverTimestamp, timestampBasis:'server', remainingMs, deadline, grading: false, finished: false, gradeResults: null };
    saveSessionSnapshot();
    if (minutes) startTimer();
    renderSession();
  };
  window.studyKitResumeSession = function (kitId, sessionId) {
    const safeKitId = safeInlineId(kitId), safeSessionId = safeInlineId(sessionId);
    const kit = findKit(safeKitId), saved = kit?.sessions?.find(item => safeInlineId(item?.id) === safeSessionId);
    if (!saved) { setMessage('studyKitStatus', 'No se encontró la sesión guardada.', true); return; }
    let serverTimestamp;
    try { withCloudReady(); serverTimestamp = requireServerTime(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    const timed = isTimedSession(saved);
    const remaining = timed
      ? saved.timestampBasis === 'server' ? window.StudyKitSessionClock?.remainingMs?.(saved) : Math.max(0, Number(saved.remainingMs || 0))
      : Math.max(0, Number(saved.remainingMs || 0));
    if (timed && !Number.isSafeInteger(remaining)) { setMessage('studyKitStatus', 'No se reanudó el temporizador: falta una hora de servidor confirmada. La sesión permanece guardada.', true); return; }
    session = JSON.parse(JSON.stringify(saved));
    session.remainingMs = remaining; session.grading = false; session.evaluating = false; session.pausedOffline = false; session.pausedRemaining = 0;
    session.updatedAt = serverTimestamp; session.timestampBasis = 'server';
    if (session.finished && session.kind === 'matching') session.kind = 'matching-result';
    if (!session.finished) {
      session.status = 'active';
      session.deadline = timed ? serverTimestamp + remaining : 0;
      if (timed) startTimer();
    } else session.deadline = 0;
    saveSessionSnapshot(); renderSession();
  };
  function questionOptions(q) { return q.type === 'trueFalse' ? ['Verdadero','Falso'] : q.options || []; }
  function correctAnswer(q) {
    if (q.isFollowUp) return '';
    if (q.type === 'multipleChoice') return q.options[q.correctIndex] || '';
    if (q.type === 'trueFalse') return q.answer ? 'Verdadero' : 'Falso';
    if (q.type === 'shortAnswer') return q.expectedAnswer || '';
    if (q.type === 'ordering') return q.correctOrder.map(index => q.items[index]).join(' → ');
    if (q.type === 'diagramLabels') return q.labels.map(label=>label.options[label.correctIndex]).join(' · ');
    if (q.type === 'matchingSet') return q.matchingPairs.map(pair => `${pair.left} → ${pair.right}`).join(' · ');
    return '';
  }
  function matchingGradeRow(q, userAnswer) {
    const selected = Array.isArray(userAnswer) ? userAnswer : [];
    const matchingDetails = q.matchingPairs.map((pair, index) => {
      const definition = q.definitions[Number(selected[index])];
      const correct = definition?.leftIndex === index;
      return { id:pair.id || `pair-${index}`, correct, topic:str(pair.left), question:str(pair.left), userAnswer:definition?.text || '', correctAnswer:str(pair.right), explanation:str(pair.explanation), sourceQuote:str(pair.sourceQuote), sourceFileId:str(pair.sourceFileId), sourcePage:pair.sourcePage };
    });
    const correct = matchingDetails.length > 0 && matchingDetails.every(item => item.correct);
    return { id:q.id, question:q.question, topic:q.topic, userAnswer:selected, correct, correctCount:matchingDetails.filter(item=>item.correct).length, totalCount:matchingDetails.length, feedback:matchingDetails.map(item => `${item.topic}: ${item.correct ? 'correcto' : `la definición correcta es ${item.correctAnswer}`}${item.explanation ? `. ${item.explanation}` : ''}`).join(' '), correctAnswer:correctAnswer(q), sourceQuote:q.sourceQuote, matchingDetails };
  }
  function scoreRows(rows) {
    return rows.reduce((score,row)=>{score.correct+=Number.isFinite(row.correctCount)?row.correctCount:(row.correct?1:0);score.total+=Number.isFinite(row.totalCount)?row.totalCount:1;return score;},{correct:0,total:0});
  }
  function answerText(value) {
    if (value == null) return '';
    if (typeof value === 'boolean') return value ? 'Verdadero' : 'Falso';
    if (typeof value === 'string') return value;
    if (Array.isArray(value)) return value.map(answerText).filter(Boolean).join(' · ');
    if (typeof value === 'object') return str(value.selectedOption || value.answer || JSON.stringify(value));
    return String(value);
  }
  function sourceCitationHTML(item, kitId = session?.kitId) {
    const quote = str(item?.sourceQuote).trim(), sourceId = str(item?.sourceFileId), kit = findKit(kitId);
    const source = sourceId && kit?.sourceFiles?.find(file => str(file.sourceId) === sourceId);
    const label = source ? str(source.label || source.name) : sourceId;
    const page = Number.isSafeInteger(item?.sourcePage) ? Number(item.sourcePage) : 0;
    if (!quote && !label) return '';
    return `<blockquote class="study-kit-source-citation"><b>Fuente${label ? `: ${esc(label)}` : ''}${page ? ` · página ${page}` : ''}</b>${quote ? `<span>“${esc(quote)}”</span>` : ''}</blockquote>`;
  }
  function selectedIndexFor(q, saved) {
    if (q.type === 'trueFalse' && typeof saved === 'boolean') return saved ? 0 : 1;
    if (Number.isInteger(saved)) return saved;
    if (Number.isInteger(saved?.selectedIndex)) return saved.selectedIndex;
    return -1;
  }
  function answerControl(q, answer, finalResult) {
    const saved = answer?.userAnswer ?? session.drafts?.[q.id];
    if (q.type === 'multipleChoice' || q.type === 'trueFalse') {
      const options = questionOptions(q), savedIndex = selectedIndexFor(q, saved);
      const correctIndex = q.isFollowUp ? options.findIndex(option => option.trim().toLocaleLowerCase('es') === answerText(answer?.correctAnswer).trim().toLocaleLowerCase('es')) : q.type === 'trueFalse' ? (q.answer ? 0 : 1) : q.correctIndex;
      return `<div class="study-kit-options">${options.map((option,index)=>{
        let klass=''; if (finalResult) { if (index === correctIndex) klass='is-correct'; else if (savedIndex === index && !answer?.correct) klass='is-wrong'; }
        return `<label class="study-kit-option ${klass}"><input type="radio" name="studyKitAnswer" value="${index}" ${savedIndex === index ? 'checked' : ''} ${finalResult || session.grading ? 'disabled' : ''}><span>${esc(option)}</span>${finalResult && index===correctIndex ? '<b>✓</b>' : finalResult && savedIndex===index && !answer?.correct ? '<b>×</b>' : ''}</label>`;
      }).join('')}</div>`;
    }
    if (q.type === 'matchingSet') {
      const selected = Array.isArray(saved) ? saved : [];
      return `<div class="study-kit-match-answer">${q.matchingPairs.map((pair,index)=>{const chosen=Number(selected[index]), correctIndex=Number(q.answerKey[index]), klass=finalResult?(chosen===correctIndex?'is-correct':'is-wrong'):'';return `<label class="${klass}"><b>${esc(pair.left)}</b><select class="study-kit-pair-answer" data-pos="${index}" ${finalResult || session.grading ? 'disabled' : ''}><option value="">Elige la definición…</option>${q.definitions.map((definition,definitionIndex)=>`<option value="${definitionIndex}" ${chosen===definitionIndex?'selected':''}>${esc(definition.text)}</option>`).join('')}</select>${finalResult&&chosen!==correctIndex?`<small>Correcta: ${esc(pair.right)}</small>`:''}</label>`;}).join('')}</div>`;
    }
    if (q.type === 'shortAnswer') return `<label class="study-kit-answer-label">Tu respuesta<textarea id="studyKitShortAnswer" rows="3" ${finalResult || session.grading ? 'disabled' : ''}>${esc(saved || '')}</textarea></label>`;
    if (q.type === 'ordering') return `<ol class="study-kit-order">${q.items.map((item,index)=>`<li><span>Posición ${index+1}</span><select class="study-kit-order-choice" data-pos="${index}" ${finalResult || session.grading ? 'disabled' : ''}><option value="">Selecciona un paso…</option>${q.items.map((choice,choiceIndex)=>`<option value="${choiceIndex}" ${Array.isArray(saved)&&Number(saved[index])===choiceIndex?'selected':''}>${esc(choice)}</option>`).join('')}</select></li>`).join('')}</ol>`;
    if (q.type === 'diagramLabels') return `<div class="study-kit-diagram"><p>${esc(q.diagramDescription || 'Completa las etiquetas del esquema:')}</p>${q.labels.map((label,index)=>{ const selected = Array.isArray(saved) ? Number(saved[index]) : -1; return `<label>${esc(label.prompt)}<select class="study-kit-label-choice" data-pos="${index}" ${finalResult || session.grading ? 'disabled' : ''}><option value="">Selecciona una etiqueta…</option>${label.options.map((option,choiceIndex)=>`<option value="${choiceIndex}" ${selected===choiceIndex?'selected':''}>${esc(option)}</option>`).join('')}</select></label>`; }).join('')}</div>`;
    return '';
  }
  function captureDraft() {
    if (!session || session.kind !== 'quiz' || session.finished) return;
    const q = session.questions[session.index], play = $('studyKitPlay'); if (!q || !play) return;
    let draft;
    if (q.type === 'multipleChoice' || q.type === 'trueFalse') {
      const checked = play.querySelector('input[name="studyKitAnswer"]:checked'); if (!checked) return;
      draft = q.type === 'trueFalse' ? Number(checked.value) === 0 : Number(checked.value);
    } else if (q.type === 'shortAnswer') draft = $('studyKitShortAnswer')?.value || '';
    else if (q.type === 'ordering' || q.type === 'diagramLabels' || q.type === 'matchingSet') {
      const selector = q.type === 'ordering' ? '.study-kit-order-choice' : q.type === 'diagramLabels' ? '.study-kit-label-choice' : '.study-kit-pair-answer';
      draft = [...play.querySelectorAll(selector)].map(node => node.value === '' ? -1 : Number(node.value));
    } else return;
    session.drafts = session.drafts || {}; session.drafts[q.id] = draft; saveSessionSnapshot();
  }
  window.studyKitSaveDraft = captureDraft;
  document.addEventListener('input', event => { if (event.target?.closest?.('#studyKitPlay')) captureDraft(); });
  document.addEventListener('change', event => { if (event.target?.closest?.('#studyKitPlay')) captureDraft(); });
  function renderPracticeFeedback(q, answer) {
    const chosenIndex = selectedIndexFor(q, answer.userAnswer);
    const chosenReason = q.type === 'multipleChoice' && chosenIndex >= 0 ? str(q.explanations?.[chosenIndex]) : '';
    const correctReason = q.type === 'multipleChoice' && !q.isFollowUp && q.correctIndex >= 0 ? str(q.explanations?.[q.correctIndex]) : '';
    const expected = answerText(answer.correctAnswer ?? correctAnswer(q));
    const matchingDetails = q.type === 'matchingSet' && Array.isArray(answer.matchingDetails) ? answer.matchingDetails : [];
    return `<div class="study-kit-feedback ${answer.correct ? 'correct' : 'incorrect'}"><strong>${answer.correct ? 'Tu respuesta es correcta.' : 'Te equivocaste en esta.'}</strong><p>${esc(answer.feedback || (answer.correct ? q.explanation : 'Revisa la respuesta correcta y vuelve a estudiar este concepto.'))}</p>${chosenReason ? `<p><b>Por qué es ${answer.correct ? 'correcta' : 'incorrecta'} tu opción:</b> ${esc(chosenReason)}</p>` : ''}${correctReason ? `<p><b>Por qué la opción correcta es correcta:</b> ${esc(correctReason)}</p>` : ''}${matchingDetails.length ? `<ul>${matchingDetails.map(item=>`<li><b>${esc(item.topic)}:</b> ${esc(item.userAnswer || 'Sin respuesta')} · ${item.correct?'correcto':`correcta: ${item.correctAnswer}`}. ${esc(item.explanation || '')}${sourceCitationHTML(item)}</li>`).join('')}</ul>` : ''}${!answer.correct && expected && q.type !== 'matchingSet' ? `<p><b>Respuesta correcta:</b> ${esc(expected)}</p>` : ''}${sourceCitationHTML({ ...answer, sourceFileId:answer.sourceFileId || q.sourceFileId, sourcePage:answer.sourcePage ?? q.sourcePage })}</div>`;
  }
  function renderSession() {
    const play = $('studyKitPlay'); if (!play || !session) return;
    if (!onlineReady() && !session.finished) { play.innerHTML='<div class="study-kit-muted">Study Kit pausado: conéctate, inicia sesión con Google y espera la confirmación de la nube para continuar.</div>'; return; }
    if (session.kind === 'matching') { renderMatching(play); updateClock(); return; }
    if (session.kind === 'matching-result') return renderMatchingResult(play);
    if (session.kind === 'flashcards') return session.finished ? renderFlashcardsFinished() : renderFlashcard(play);
    const q = session.questions[session.index], answer = session.answers[q?.id], answerReady = !!answer && !answer.pending, finalResult = session.mode === 'formal' ? session.finished : answerReady;
    if (!q) return finishSession();
    const typeName = { multipleChoice:'Selección múltiple', trueFalse:'Verdadero / Falso', shortAnswer:'Respuesta corta', ordering:'Ordenamiento', diagramLabels:'Etiquetado de esquema', matchingSet:'Términos pareados' }[q.type] || 'Pregunta';
    const answerControlHTML = answerControl(q, answer, finalResult);
    const feedback = answer?.pending ? (session.evaluating ? '' : '<div class="study-kit-status" role="status"><b>La respuesta se conservó, pero Gemini no alcanzó a corregirla.</b><p>Comprueba la conexión y la nube; luego puedes reintentar la evaluación.</p></div>') : answerReady && session.mode === 'practice' ? renderPracticeFeedback(q, answer) : '';
    const result = session.finished ? renderFinalResult() : '';
    play.innerHTML = `<article class="study-kit-session"><header><div><span>${session.mode==='formal'?'SIMULACRO FORMAL':'SMART STUDY'} · ${esc(typeName)}</span><h4>${esc(session.kitId ? findKit(session.kitId)?.title : '')}</h4></div><button type="button" onclick="studyKitCloseSession()" aria-label="Cerrar actividad">×</button></header>${!session.finished ? `<div class="study-kit-session-meta"><span>Pregunta ${session.index+1} de ${session.questions.length}</span>${session.deadline ? '<span id="studyKitClock"></span>' : ''}</div><div class="study-kit-progress"><span style="width:${Math.round((session.index+1)/session.questions.length*100)}%"></span></div><div class="study-kit-question"><span class="study-kit-topic">${esc(q.topic || 'Concepto clave')}${q.isFollowUp?' · Refuerzo adaptativo':''}</span><h5>${esc(q.question)}</h5>${answerControlHTML}${session.mode==='formal'&&!session.finished?'<p class="study-kit-muted">La corrección se mostrará al finalizar el simulacro.</p>':''}${session.evaluating?'<p class="study-kit-status">Gemini está analizando tu respuesta…</p>':''}${feedback}</div>${session.finished?result:`<div class="study-kit-session-actions">${session.mode==='practice'&&(!answer||answer.pending)?`<button type="button" class="primary" onclick="studyKitSubmitCurrent()" ${session.evaluating?'disabled':''}>${answer?.pending?'Reintentar evaluación':'Comprobar con Gemini'}</button>`:''}${session.mode==='formal'&&!answer?'<button type="button" class="primary" onclick="studyKitSubmitCurrent()">Guardar respuesta</button>':''}${answerReady?`<button type="button" class="primary" onclick="studyKitNext()">${session.index+1<session.questions.length?'Siguiente':'Finalizar'}</button>`:''}${session.mode==='formal'?`<button type="button" onclick="studyKitFinishFormal()">Terminar evaluación</button>`:''}</div>`}`:result}</article>`;
    if (session.deadline) updateClock();
  }
  function renderFinalResult() {
    const r = session.gradeResults || {};
    if (session.grading) return '<div class="study-kit-status">Calificando y preparando retroalimentación final…</div>';
    if (session.gradeError) return `<div class="study-kit-feedback incorrect"><strong>No se pudo calificar todavía.</strong><p>${esc(session.gradeError)}</p><button type="button" onclick="studyKitRetryGrade()">Reintentar calificación</button></div>`;
    const total = Number(r.total || session.questions.length), correct = Number(r.correct || 0), grade = Number(r.grade ?? (total ? (1 + 6 * correct / total).toFixed(1) : 1));
    const details = Array.isArray(r.items) ? r.items : [];
    return `<div class="study-kit-result"><span>RESULTADO FINAL</span><h5>Nota ${grade.toFixed ? grade.toFixed(1) : grade} · ${correct} / ${total}</h5><p>${session.mode==='formal'?'La retroalimentación aparece solo después de entregar el simulacro.':'Práctica terminada.'}</p><div class="study-kit-review">${details.map(item=>`<section class="study-kit-feedback ${item.correct?'correct':'incorrect'}"><b>${item.correct?'Correcta':'Revisar'} · ${esc(item.topic || item.question || 'Pregunta')}</b><p>${esc(item.feedback || '')}</p>${Array.isArray(item.matchingDetails)?`<ul>${item.matchingDetails.map(pair=>`<li><b>${esc(pair.topic)}:</b> ${esc(pair.userAnswer || 'Sin respuesta')} · ${pair.correct?'correcto':`correcta: ${esc(pair.correctAnswer)}`}. ${esc(pair.explanation || '')}${sourceCitationHTML(pair)}</li>`).join('')}</ul>`:''}${!item.correct && answerText(item.correctAnswer) && !Array.isArray(item.matchingDetails) ? `<p><b>Respuesta esperada:</b> ${esc(answerText(item.correctAnswer))}</p>`:''}${!Array.isArray(item.matchingDetails)?sourceCitationHTML(item):''}</section>`).join('')}</div><button type="button" onclick="studyKitCloseSession()">Volver a Study Kit</button></div>`;
  }
  window.studyKitSubmitCurrent = async function () {
    if (!session || session.finished || session.grading || session.evaluating) return;
    const q = session.questions[session.index], play = $('studyKitPlay'); if (!q || !play) return;
    if (session.mode === 'practice' && session.answers[q.id] && !session.answers[q.id].pending) return;
    if (session.mode === 'formal') { try { withCloudReady(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; } }
    let answer;
    if (q.type === 'multipleChoice' || q.type === 'trueFalse') {
      const selected = play.querySelector('input[name="studyKitAnswer"]:checked');
      if (!selected) { alert('Selecciona una respuesta antes de continuar.'); return; }
      answer = q.type === 'trueFalse' ? Number(selected.value) === 0 : Number(selected.value);
    } else if (q.type === 'shortAnswer') {
      answer = str($('studyKitShortAnswer')?.value).trim(); if (!answer) { alert('Escribe una respuesta breve antes de continuar.'); return; }
    } else if (q.type === 'ordering') {
      answer = [...play.querySelectorAll('.study-kit-order-choice')].map(select=>select.value===''?null:Number(select.value));
      if (answer.some(value=>value===null)) { alert('Completa todos los pasos del ordenamiento.'); return; }
    } else if (q.type === 'diagramLabels') {
      answer = [...play.querySelectorAll('.study-kit-label-choice')].map(select=>select.value===''?null:Number(select.value));
      if (answer.some(value=>value===null)) { alert('Completa todas las etiquetas del esquema.'); return; }
    } else if (q.type === 'matchingSet') {
      answer = [...play.querySelectorAll('.study-kit-pair-answer')].map(select=>select.value===''?null:Number(select.value));
      if (answer.some(value=>value===null)) { alert('Asocia todos los conceptos antes de continuar.'); return; }
    }
    if (session.mode === 'formal') {
      try { withCloudReady(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
      session.answers[q.id] = q.type === 'matchingSet' ? { ...matchingGradeRow(q, answer), userAnswer:answer, feedback:'' } : { userAnswer:answer, correct:null, feedback:'' };
      delete session.drafts?.[q.id]; session.index++; saveSessionSnapshot();
      if (session.index >= session.questions.length) await finishFormal(); else renderSession();
      return;
    }
    if (q.type === 'matchingSet') {
      try { withCloudReady(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
      session.answers[q.id] = matchingGradeRow(q, answer); delete session.drafts?.[q.id]; saveSessionSnapshot(); renderSession(); return;
    }
    session.answers[q.id] = { userAnswer:answer, correct:null, pending:true };
    delete session.drafts?.[q.id]; saveSessionSnapshot();
    try {
      withCloudReady(false); session.evaluating = true; renderSession();
      const kit = findKit(session.kitId), materials = materialsForItems(kit, [q]);
      const data = await requestAI('/api/gemini/study-answer', { ...materials, question:q, answer });
      if (typeof data.correct !== 'boolean' || !str(data.feedback).trim()) throw new Error('La evaluación no devolvió retroalimentación válida. Tu respuesta sigue en la pantalla; puedes reintentar.');
      const result = { userAnswer:answer, correct:data.correct, feedback:str(data.feedback), correctAnswer:answerText(data.correctAnswer) || correctAnswer(q), sourceQuote:str(data.sourceQuote || q.sourceQuote), sourceFileId:str(data.sourceFileId || q.sourceFileId), ...(Number.isSafeInteger(data.sourcePage) ? { sourcePage:data.sourcePage } : Number.isSafeInteger(q.sourcePage) ? { sourcePage:q.sourcePage } : {}), topic:q.topic };
      session.answers[q.id] = result; session.evaluating = false;
      if (!result.correct && data.followUpQuestion && !q.isFollowUp) {
        const follow = normalizeQuestion({ ...data.followUpQuestion, id:data.followUpQuestion.id || newId('follow'), isFollowUp:true, parentId:q.id });
        if (follow) {
          session.questions.splice(session.index + 1, 0, follow);
          const kit = findKit(session.kitId);
          if (kit) { kit.followUps = Array.isArray(kit.followUps) ? kit.followUps : []; if (!kit.followUps.some(item => item.id === follow.id)) kit.followUps.push(follow); persist(); }
        }
      }
      saveSessionSnapshot(); renderSession();
    } catch (error) { session.evaluating = false; session.answers[q.id] = { userAnswer:answer, correct:null, pending:true }; saveSessionSnapshot(); setMessage('studyKitStatus', error.message || 'No se pudo evaluar; vuelve a intentar con conexión.', true); renderSession(); }
  };
  window.studyKitNext = function () {
    if (!session) return;
    try { withCloudReady(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    if (session.evaluating || !session.answers[session.questions[session.index]?.id] || session.answers[session.questions[session.index]?.id].pending) return;
    if (session.index + 1 < session.questions.length) { session.index++; saveSessionSnapshot(); renderSession(); } else void finishSession();
  };
  window.studyKitFinishFormal = function () { if (session?.mode === 'formal') void finishFormal(); };
  async function finishFormal() {
    if (!session || session.mode !== 'formal' || session.finished || session.grading) return;
    try { withCloudReady(); } catch (error) { setMessage('studyKitStatus', error.message, true); return; }
    if (!confirm('¿Entregar el simulacro ahora? La corrección se revelará al finalizar.')) return;
    session.finished = true; session.status='paused'; stopTimer(); session.grading = true; saveSessionSnapshot(); renderSession();
    await gradeFormal();
  }
  async function gradeFormal() {
    if (!session) return;
    try {
      const kit = findKit(session.kitId); if (!kit) throw new Error('No se encontró el Study Kit.');
      const questions = session.questions.slice();
      const geminiQuestions = questions.filter(q => q.type !== 'matchingSet');
      const items = geminiQuestions.map(q => ({ id:q.id, type:q.type, question:q.question, options:q.options, correctIndex:q.correctIndex, expectedAnswer:q.expectedAnswer, rubric:q.rubric, items:q.items, correctOrder:q.correctOrder, labels:q.labels, answer:session.answers[q.id]?.userAnswer ?? '', sourceQuote:q.sourceQuote, sourceFileId:q.sourceFileId, sourcePage:q.sourcePage, topic:q.topic }));
      const materials = materialsForItems(kit, items);
      const data = items.length ? await requestAI('/api/gemini/grade', { ...materials, items }) : { items:[] };
      const grades = Array.isArray(data.items) ? data.items : [];
      const gradeById = new Map(grades.filter(item => typeof item?.id === 'string').map(item => [item.id, item]));
      if (grades.length !== items.length || gradeById.size !== items.length || grades.some(item=>typeof item.correct!=='boolean') || items.some(item=>!gradeById.has(item.id))) throw new Error('La calificación llegó incompleta o no coincide por ID; no se borraron tus respuestas.');
      const rows = questions.map(q => {
        const saved = session.answers[q.id] || {};
        if (q.type === 'matchingSet') return matchingGradeRow(q, saved.userAnswer || []);
        const grade = gradeById.get(q.id);
        return { ...grade, id:q.id, question:q.question, topic:q.topic, sourceQuote:str(grade.sourceQuote || q.sourceQuote), sourceFileId:str(grade.sourceFileId || q.sourceFileId), ...(Number.isSafeInteger(grade.sourcePage) ? { sourcePage:grade.sourcePage } : Number.isSafeInteger(q.sourcePage) ? { sourcePage:q.sourcePage } : {}), userAnswer:saved.userAnswer };
      });
      const {correct,total} = scoreRows(rows);
      session.gradeResults = { items:rows, correct, total, grade:Number((1 + 6 * (total ? correct/total : 0)).toFixed(1)) };
      session.answers = Object.fromEntries(rows.map(item=>[item.id,{...session.answers[item.id], ...item, userAnswer:session.answers[item.id]?.userAnswer}]));
      session.grading = false; session.gradeError = '';
      commitSession(session, rows);
    } catch (error) { session.grading = false; session.status='paused'; session.gradeError = error.message || 'Comprueba tu conexión e inténtalo de nuevo.'; saveSessionSnapshot(); }
    renderSession();
  }
  window.studyKitRetryGrade = function () { if (!session || session.mode!=='formal') return; try { withCloudReady(false); } catch (error) { setMessage('studyKitStatus', error.message, true); return; } session.gradeError=''; session.grading=true; saveSessionSnapshot(); renderSession(); void gradeFormal(); };
  function stopTimer() { if (timer) clearInterval(timer); timer = null; }
  function formatClock(totalSeconds) {
    const seconds = Math.max(0, Math.ceil(Number(totalSeconds) || 0));
    return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  }
  function updateClock() {
    if (!session?.deadline) return;
    const clock = $('studyKitClock'), remaining = remainingUntil(session.deadline);
    if (clock) clock.textContent = remaining === null ? 'Pausado · esperando hora de nube' : `Tiempo ${formatClock(remaining / 1000)}`;
  }
  function finishSession() {
    if (!session || session.finished) return;
    if (Array.isArray(session.questions) && session.questions.some(question => session.answers[question.id]?.pending)) { setMessage('studyKitStatus', 'Termina la corrección pendiente antes de cerrar el intento.', true); return; }
    stopTimer(); session.finished=true; session.status='finished';
    const rows=session.questions.map(q=>q.type==='matchingSet'?matchingGradeRow(q,session.answers[q.id]?.userAnswer||[]):({ id:q.id, correct:!!session.answers[q.id]?.correct, userAnswer:session.answers[q.id]?.userAnswer, feedback:session.answers[q.id]?.feedback || 'Sin respuesta registrada.', correctAnswer:session.answers[q.id]?.correctAnswer ?? correctAnswer(q), sourceQuote:session.answers[q.id]?.sourceQuote || q.sourceQuote, sourceFileId:session.answers[q.id]?.sourceFileId || q.sourceFileId, sourcePage:session.answers[q.id]?.sourcePage ?? q.sourcePage, topic:q.topic, question:q.question }));
    const {correct,total}=scoreRows(rows);
    session.gradeResults={items:rows,correct,total,grade:Number((1+6*(total?correct/total:0)).toFixed(1))};
    commitSession(session, rows); renderSession();
  }
  function studyKitProgress(c) {
    const attempts = (c?.studyKits || []).flatMap(kit => (Array.isArray(kit.history) ? kit.history : []).map(item => ({ ...item, kitId:item.kitId || kit.id }))).filter(item => ['studyKit','matching-game','spaced-repetition'].includes(item.activity));
    const all = attempts.slice(-8), weak = {};
    for (const item of all) for (const error of item.errors || []) { const label = error.topic || str(error.question || 'Concepto pendiente').slice(0, 54); weak[label] = (weak[label] || 0) + 1; }
    const weakTopics = Object.entries(weak).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name]) => name);
    const recent = attempts.slice(-5), average = recent.length ? recent.reduce((sum, item) => sum + Number(item.ratio || 0), 0) / recent.length * 100 : 0;
    const level = average >= 85 && recent.length >= 3 ? 3 : average >= 70 && recent.length >= 2 ? 2 : 1;
    return { level, attempts: attempts.length, average, weakTopics };
  }
  function commitSession(active, rows) {
    const c=ensureClass(), kit=findKit(active.kitId); if (!c || !kit) return;
    const {correct,total}=scoreRows(rows),ratio=total?correct/total:0;
    const errors=rows.flatMap(row=>Array.isArray(row.matchingDetails)?row.matchingDetails.filter(pair=>!pair.correct).map(pair=>({topic:pair.topic,question:pair.question,explanation:pair.explanation||`La definición correcta es: ${pair.correctAnswer}`,sourceQuote:pair.sourceQuote||''})):row.correct?[]:[{ topic:row.topic||'Concepto clave', question:row.question||'', explanation:row.feedback||'', sourceQuote:row.sourceQuote||'' }]);
    const attempt={ id:newId('attempt'), at:new Date().toISOString(), mode:active.mode, activity:'studyKit', kitId:kit.id, correct,total,ratio,grade:Number((1+6*ratio).toFixed(1)), expired:!!(active.deadline&&remainingUntil(active.deadline)===0), errors, answers:rows.map(row=>({questionId:row.id,correct:row.correct,correctCount:row.correctCount,totalCount:row.totalCount,topic:row.topic,question:row.question,userAnswer:row.userAnswer,correctAnswer:row.correctAnswer,feedback:row.feedback,sourceQuote:row.sourceQuote,matchingDetails:row.matchingDetails})) };
    kit.history=Array.isArray(kit.history)?kit.history:[]; kit.history.push(attempt);
    const failed=new Set(kit.failedQuestionIds||[]);
    for(const q of active.questions){const row=rows.find(item=>item.id===q.id);if(row?.correct)failed.delete(q.id);else failed.add(q.id);if(q.parentId&&row?.correct)failed.delete(q.parentId);}
    kit.failedQuestionIds=[...failed];
    const failedPairs=new Set(kit.failedPairIds||[]);for(const row of rows)for(const pair of row.matchingDetails||[]){if(pair.correct)failedPairs.delete(pair.id);else failedPairs.add(pair.id);}kit.failedPairIds=[...failedPairs];
    saveSessionSnapshot();
    persist(); setTimeout(scheduleSync,700); refreshList();
  }
  window.studyKitCloseSession = function () {
    if (session) {
      if (!session.finished && session.deadline) { const remaining = remainingUntil(session.deadline); session.pausedRemaining = remaining === null ? Math.max(0, Number(session.remainingMs || 0)) : remaining; }
      if (!session.finished) { session.deadline = 0; session.status = 'paused'; }
      saveSessionSnapshot();
    }
    stopTimer(); session=null; const play=$('studyKitPlay'); if(play) play.replaceChildren(); refreshList();
  };

  function dueFlashcards(kit) {
    const cards=Array.isArray(kit.flashcards)?kit.flashcards:[], schedules=kit.spacedRepetition||{}, now=currentServerTime();
    return cards.filter(card=>!Number(schedules[card.id]?.dueAt)||now===null||Number(schedules[card.id].dueAt)<=now);
  }
  window.studyKitStartFlashcards = function(id) {
    const kit=findKit(id); if(!kit||!kit.flashcards?.length)return;
    let serverTimestamp;
    try{withCloudReady();serverTimestamp=requireServerTime();}catch(error){setMessage('studyKitStatus',error.message,true);return;}
    let cards=dueFlashcards(kit); if(!cards.length)cards=kit.flashcards;
    session={id:newId('session'),kind:'flashcards',kitId:id,mode:'flashcards',status:'active',cards:shuffle(cards),index:0,flipped:false,ratings:[],startedAt:serverTimestamp,updatedAt:serverTimestamp,timestampBasis:'server',remainingMs:0,finished:false}; saveSessionSnapshot(); renderSession();
  };
  function renderFlashcard(play) {
    const card=session.cards[session.index]; if(!card){finishFlashcards();return;}
    play.innerHTML=`<article class="study-kit-session study-kit-flash-session"><header><div><span>REPETICIÓN ESPACIADA · ${session.index+1} / ${session.cards.length}</span><h4>${esc(findKit(session.kitId)?.title||'Tarjetas')}</h4></div><button type="button" onclick="studyKitCloseSession()">×</button></header><button type="button" class="study-kit-flashcard ${session.flipped?'flipped':''}" onclick="studyKitFlipCard()"><small>${session.flipped?'RESPUESTA':'TÉRMINO'}</small><span>${esc(session.flipped?card.back:card.front)}</span><em>${session.flipped?'Pulsa para volver':'Pulsa para revelar'}</em></button>${session.flipped?`${sourceCitationHTML(card)}<div class="study-kit-session-actions"><button type="button" onclick="studyKitRateCard('again')">Otra vez · 15 min</button><button type="button" class="primary" onclick="studyKitRateCard('good')">Bien · 1 día</button><button type="button" class="secondary" onclick="studyKitRateCard('easy')">Fácil · 3+ días</button></div>`:''}</article>`;
  }
  window.studyKitFlipCard = function(){if(session?.kind!=='flashcards')return;try{withCloudReady();}catch(error){setMessage('studyKitStatus',error.message,true);return;}session.flipped=!session.flipped;saveSessionSnapshot();renderSession();};
  window.studyKitRateCard = function(rating) {
    if(!session||session.kind!=='flashcards'||!session.flipped)return;
    let serverTimestamp;
    try{withCloudReady();serverTimestamp=requireServerTime();}catch(error){setMessage('studyKitStatus',error.message,true);return;}
    const kit=findKit(session.kitId), card=session.cards[session.index]; if(!kit||!card)return;
    kit.spacedRepetition=kit.spacedRepetition||{}; const old=kit.spacedRepetition[card.id]||{repetitions:0,intervalDays:0,ease:2.5};
    let repetitions=Number(old.repetitions)||0, intervalDays=Number(old.intervalDays)||0, ease=Number(old.ease)||2.5;
    if(rating==='again'){repetitions=0;intervalDays=0.01;ease=Math.max(1.3,ease-0.2);} else {repetitions++;intervalDays=repetitions===1?1:repetitions===2?3:Math.max(1,Math.round(intervalDays*ease));if(rating==='easy'){intervalDays=Math.max(3,Math.round(intervalDays*1.3));ease=Math.min(3,ease+0.15);}}
    const dueAt=serverTimestamp+intervalDays*86400000; kit.spacedRepetition[card.id]={repetitions,intervalDays,ease,dueAt,lastRating:rating};
    session.ratings.push({cardId:card.id,question:card.front,topic:card.topic||'Tarjeta',correct:rating!=='again',sourceQuote:card.sourceQuote,rating}); persist();
    if(session.index+1<session.cards.length){session.index++;session.flipped=false;saveSessionSnapshot();renderSession();}else finishFlashcards();
  };
  function finishFlashcards(){if(!session||session.kind!=='flashcards'||session.finished)return;const c=ensureClass(),kit=findKit(session.kitId),ratings=session.ratings||[];if(!c||!kit)return;const correct=ratings.filter(item=>item.correct).length,total=ratings.length,ratio=total?correct/total:0;const attempt={id:newId('attempt'),at:new Date().toISOString(),mode:'flashcards',activity:'spaced-repetition',kitId:kit.id,correct,total,ratio,grade:Number((1+6*ratio).toFixed(1)),errors:ratings.filter(item=>!item.correct).map(item=>({topic:item.topic,question:item.question,sourceQuote:item.sourceQuote}))};kit.history=Array.isArray(kit.history)?kit.history:[];kit.history.push(attempt);session.finished=true;session.gradeResults={correct,total,grade:attempt.grade,items:[]};saveSessionSnapshot();persist();setTimeout(scheduleSync,700);renderFlashcardsFinished();refreshList();}
  function renderFlashcardsFinished(){const play=$('studyKitPlay');if(!play||!session)return;const r=session.gradeResults||{},syncText=onlineReady()?'El avance quedó confirmado en tu perfil cloud.':'El avance se guardó localmente y se sincronizará cuando vuelva a confirmarse la nube.';play.innerHTML=`<article class="study-kit-result"><span>REPASO COMPLETADO</span><h5>${Number(r.correct||0)} / ${Number(r.total||0)} tarjetas · nota ${Number(r.grade||1).toFixed(1)}</h5><p>${syncText}</p><button type="button" onclick="studyKitCloseSession()">Volver a Study Kit</button></article>`;}

  window.studyKitStartMatching = function(id, failedOnly = false){
    const kit=findKit(id);if(!kit||!kit.matchingPairs?.length)return;
    let serverTimestamp;
    try{withCloudReady();serverTimestamp=requireServerTime();}catch(error){setMessage('studyKitStatus',error.message,true);return;}
    const failed=new Set(kit.failedPairIds||[]),pairs=(failedOnly?kit.matchingPairs.filter((pair,index)=>failed.has(pair.id||`pair-${index}`)):kit.matchingPairs).slice(0,20);
    if(!pairs.length){setMessage('studyKitStatus','No hay parejas falladas pendientes.');return;}
    const definitions=shuffle(pairs.map((pair,index)=>({leftIndex:index,text:pair.right})));
    const deadline=window.StudyKitSessionClock?.deadlineAfter?.(60_000);
    if(!Number.isSafeInteger(deadline)){setMessage('studyKitStatus','No se inició el reto: falta una hora de servidor confirmada.',true);return;}
    session={id:newId('session'),kind:'matching',kitId:id,mode:'matching',status:'active',pairs,definitions,selectedLeft:-1,matches:{},index:0,deadline,remainingMs:60000,startedAt:serverTimestamp,updatedAt:serverTimestamp,timestampBasis:'server',finished:false};saveSessionSnapshot();startTimer();renderSession();
  };
  function renderMatching(play){
    const kit=findKit(session.kitId),remainingValue=remainingUntil(session.deadline),remaining=remainingValue===null?0:Math.max(0,Math.ceil(remainingValue/1000));
    play.innerHTML=`<article class="study-kit-session"><header><div><span>MATCHING GAME · RETO DE 60 SEGUNDOS</span><h4>${esc(kit?.title||'Términos pareados')}</h4></div><button type="button" onclick="studyKitCloseSession()">×</button></header><div class="study-kit-session-meta"><span id="studyKitClock">Tiempo 01:${String(remaining).padStart(2,'0')}</span><span>Une cada concepto con su definición</span></div><div class="study-kit-match-columns"><div><h5>Conceptos</h5>${session.pairs.map((pair,index)=>`<button type="button" class="study-kit-match-choice ${session.selectedLeft===index?'selected':''} ${Object.prototype.hasOwnProperty.call(session.matches,index)?'matched':''}" onclick="studyKitChooseLeft(${index})">${esc(pair.left)}${Object.prototype.hasOwnProperty.call(session.matches,index)?`<small>Unido: ${esc(session.definitions[session.matches[index]].text)}</small>`:''}</button>`).join('')}</div><div><h5>Definiciones</h5>${session.definitions.map((def,index)=>`<button type="button" class="study-kit-match-choice ${Object.values(session.matches).includes(index)?'matched':''}" onclick="studyKitChooseRight(${index})">${esc(def.text)}</button>`).join('')}</div></div><div class="study-kit-session-actions"><button type="button" class="primary" onclick="studyKitFinishMatching()">Comprobar parejas</button></div></article>`;
  }
  function renderMatchingResult(play){const rows=session.gradeResults?.items||[];play.innerHTML=`<article class="study-kit-result"><span>TERMINOS PAREADOS COMPLETADOS</span><h5>${Number(session.gradeResults?.correct||0)} / ${Number(session.gradeResults?.total||0)} correctas · nota ${Number(session.gradeResults?.grade||1).toFixed(1)}</h5><div class="study-kit-review">${rows.map(row=>`<section class="study-kit-feedback ${row.correct?'correct':'incorrect'}"><b>${row.correct?'Correcto':'Revisar'} · ${esc(row.question)}</b><p>${esc(row.feedback)}</p>${sourceCitationHTML(row)}</section>`).join('')}</div><button type="button" onclick="studyKitCloseSession()">Volver a Study Kit</button></article>`;}
  window.studyKitChooseLeft=function(index){if(session?.kind!=='matching')return;try{withCloudReady();}catch(error){setMessage('studyKitStatus',error.message,true);return;}session.selectedLeft=index;saveSessionSnapshot();renderSession();};
  window.studyKitChooseRight=function(index){if(session?.kind!=='matching'||session.selectedLeft<0)return;try{withCloudReady();}catch(error){setMessage('studyKitStatus',error.message,true);return;}const used=Object.entries(session.matches).some(([left,right])=>Number(left)!==session.selectedLeft&&Number(right)===index);if(used){setMessage('studyKitStatus','Esa definición ya está emparejada con otro concepto.',true);return;}session.matches[session.selectedLeft]=index;session.selectedLeft=-1;saveSessionSnapshot();renderSession();};
  window.studyKitFinishMatching=function(){
    if(!session||session.kind!=='matching')return;
    try{withCloudReady();}catch(error){setMessage('studyKitStatus',error.message,true);return;}
    const kit=findKit(session.kitId),c=ensureClass();if(!kit||!c)return;
    const rows=session.pairs.map((pair,index)=>{const chosen=session.definitions[session.matches[index]??-1];const correct=chosen?.leftIndex===index;return{id:pair.id||`pair-${index}`,correct,topic:pair.left,question:pair.left,feedback:correct?(pair.explanation||'Pareja correcta, de acuerdo con la definición del material.'):`La definición correspondiente es: ${pair.right}. ${pair.explanation||''}`,correctAnswer:pair.right,sourceQuote:pair.sourceQuote};});
    const correct=rows.filter(row=>row.correct).length,total=rows.length,ratio=total?correct/total:0;
    const failedPairs=new Set(kit.failedPairIds||[]);for(const row of rows){if(row.correct)failedPairs.delete(row.id);else failedPairs.add(row.id);}kit.failedPairIds=[...failedPairs];
    const attempt={id:newId('attempt'),at:new Date().toISOString(),mode:'practice',activity:'matching-game',kitId:kit.id,correct,total,ratio,grade:Number((1+6*ratio).toFixed(1)),errors:rows.filter(row=>!row.correct).map(row=>({topic:row.topic,question:row.question,sourceQuote:row.sourceQuote}))};
    kit.history=Array.isArray(kit.history)?kit.history:[];kit.history.push(attempt);stopTimer();
    session.kind='matching-result';session.finished=true;session.status='finished';session.gradeResults={items:rows,correct,total,grade:attempt.grade};
    saveSessionSnapshot();persist();setTimeout(scheduleSync,700);renderMatchingResult($('studyKitPlay'));refreshList();
  };

  function timerTick(){
    if(!session?.deadline||session.finished)return;
    const remaining=remainingUntil(session.deadline);
    if(!onlineReady()||remaining===null){session.pausedRemaining=remaining===null?Math.max(0,Number(session.remainingMs||0)):remaining;session.remainingMs=session.pausedRemaining;session.deadline=0;session.status='paused';session.pausedOffline=!onlineReady();session.pausedForClock=remaining===null;const clock=$('studyKitClock');if(clock)clock.textContent=remaining===null?'Pausado · esperando hora de nube':'Pausado · esperando nube';stopTimer();saveSessionSnapshot();return;}
    session.remainingMs=remaining;
    const left=Math.max(0,Math.ceil(remaining/1000)),clock=$('studyKitClock');
    if(clock)clock.textContent=`Tiempo ${String(Math.floor(left/60)).padStart(2,'0')}:${String(left%60).padStart(2,'0')}`;
    const bucket=Math.floor(left/15);if(session._lastSavedBucket!==bucket){session._lastSavedBucket=bucket;saveSessionSnapshot();}
    if(left===0){if(session.kind==='matching')window.studyKitFinishMatching();else if(session.mode==='formal'){session.finished=true;stopTimer();session.grading=true;renderSession();void gradeFormal();}else finishSession();}
  }
  function startTimer(){stopTimer();if(!session?.deadline||!window.StudyKitSessionClock?.isReady?.())return false;timer=setInterval(timerTick,1000);return true;}
  function handleSyncState(){
    refreshList();
    const play=$('studyKitPlay');
    if(!onlineReady()){
      if('speechSynthesis' in window) speechSynthesis.cancel();
      if(session&&!session.finished){session.pausedOffline=true;session.status='paused';if(session.deadline){const remaining=remainingUntil(session.deadline);session.pausedRemaining=remaining===null?Math.max(0,Number(session.remainingMs||0)):remaining;session.remainingMs=session.pausedRemaining;session.deadline=0;}stopTimer();saveSessionSnapshot();}
      if(play&&(!session||!session.finished)&&play.innerHTML.trim())play.innerHTML='<div class="study-kit-muted">Study Kit pausado: vuelve a conectar, iniciar sesión con Google y esperar la confirmación de la nube para continuar.</div>';
      return;
    }
    if((session?.pausedOffline||session?.pausedForClock)&&!session.finished){
      const serverTimestamp=currentServerTime();if(serverTimestamp===null){setMessage('studyKitStatus','La sesión sigue pausada hasta confirmar la hora del servidor.',true);return;}
      const resumeTimed=isTimedSession(session),remaining=Math.max(0,Number(session.pausedRemaining??session.remainingMs??0));
      session.pausedOffline=false;session.pausedForClock=false;session.status='active';session.updatedAt=serverTimestamp;session.timestampBasis='server';
      session.deadline=resumeTimed?serverTimestamp+remaining:0;session.remainingMs=remaining;session.pausedRemaining=0;if(resumeTimed)startTimer();saveSessionSnapshot();renderSession();return;
    }
  }
  window.addEventListener('online',handleSyncState);
  window.addEventListener('offline',handleSyncState);
  window.addEventListener('studyhub:sync-state',handleSyncState);
})();
