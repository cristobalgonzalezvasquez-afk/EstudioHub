/* Merge determinista de perfiles: los cambios independientes se combinan; en un mismo campo gana la nube confirmada. */
(function (global) {
  'use strict';
  const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
  const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const identityOf = item => !isObject(item) ? null : typeof item.id === 'string' && item.id ? `id:${item.id}` : typeof item.key === 'string' && item.key ? `key:${item.key}` : null;
  function hasDuplicateIdentity(items) {
    const seen = new Set();
    for (const item of items) { const id = identityOf(item); if (!id || seen.has(id)) return !!id; seen.add(id); }
    return false;
  }

  function merge3(base, local, remote, path = '', conflicts = []) {
    if (Array.isArray(base) && Array.isArray(local) && Array.isArray(remote)) {
      const all = [...base, ...local, ...remote];
      if (all.every(item => identityOf(item) !== null) && [base, local, remote].some(hasDuplicateIdentity)) {
        conflicts.push(`${path || '/'}/(duplicate-id)`);
        return { value: clone(remote), conflicts };
      }
    }
    if (equal(local, base)) return { value: clone(remote), conflicts };
    if (equal(remote, base) || equal(local, remote)) return { value: clone(local), conflicts };

    if (Array.isArray(base) && Array.isArray(local) && Array.isArray(remote)) {
      const all = [...base, ...local, ...remote];
      if (all.every(item => identityOf(item) !== null)) {
        const baseById = new Map(base.map(item => [identityOf(item), item]));
        const localById = new Map(local.map(item => [identityOf(item), item]));
        const remoteById = new Map(remote.map(item => [identityOf(item), item]));
        const ids = [...new Set([...remote.map(identityOf), ...local.map(identityOf), ...base.map(identityOf)])];
        const value = [];
        for (const id of ids) {
          const pathId = id.startsWith('id:') ? id.slice(3) : id;
          const merged = merge3(baseById.get(id), localById.get(id), remoteById.get(id), `${path}/${pathId}`, conflicts).value;
          if (merged !== undefined) value.push(merged);
        }
        return { value, conflicts };
      }
      conflicts.push(path || '/');
      return { value: clone(remote), conflicts };
    }

    if (isObject(base) && isObject(local) && isObject(remote)) {
      const value = {};
      const keys = new Set([...Object.keys(base), ...Object.keys(local), ...Object.keys(remote)]);
      for (const key of keys) {
        const merged = merge3(base[key], local[key], remote[key], `${path}/${key}`, conflicts).value;
        if (merged !== undefined) value[key] = merged;
      }
      return { value, conflicts };
    }

    conflicts.push(path || '/');
    return { value: clone(remote), conflicts };
  }

  global.StudyHubSyncMerge = Object.freeze({ merge3 });
})(typeof window !== 'undefined' ? window : globalThis);
