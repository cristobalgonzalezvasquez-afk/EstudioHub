/* Capa de identidad, sincronización, archivos privados y Gemini para el HTML original. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const META_DB = 'estudiohub_sync_v1', META_STORE = 'metadata';
  const profileKey = id => `estudiohub_data_v3_user_${id}`;
  const metaPrefix = id => `profile:${id}:`;
  let user = null, serverAuth = false, clientId = '', authNonce = '', revision = 0, profileChanging = false, profileLoading = false, profileGeneration = 0;
  let baseSnapshot = null, applyingRemote = false, pending = false, syncing = false, conflictOpen = false, lastSyncError = null;
  let flushTimer = null, syncRetryTimer = null, syncRetryAttempt = 0, eventStream = null, remotePoll = null, currentMaterial = null, retrySoon = false, localFileGet = null;
  const chat = [];
  let activeChatContextHash = '';
  let guestSnapshot = getState(), noticeTimer = null;
  const csrf = { 'X-EstudioHUB-Request': '1' };
  const originalSave = window.saveAppData;
  const syncIdleWaiters = new Set();

  function setStatus(sync, profile) {
    const s = $('studyhubSyncStatus'), p = $('studyhubProfileStatus');
    if (s) s.textContent = sync;
    if (p) p.textContent = profile;
    refreshProfileTrigger();
    renderProfilePanel();
    announceSyncState();
  }
  function resolveStudySyncState(flags) {
    if (flags.profileChanging || flags.profileLoading) return 'signed-out';
    if (!flags.user || !flags.serverAuth) return 'signed-out';
    if (!flags.online) return 'offline';
    if (flags.conflictOpen) return 'conflict';
    if (flags.syncing) return 'syncing';
    if (flags.pending) return flags.hasError ? 'error' : 'pending';
    return 'confirmed';
  }
  function getStudySyncState() {
    return resolveStudySyncState({ user: Boolean(user), serverAuth, online: navigator.onLine, conflictOpen, syncing, pending, hasError: !!lastSyncError, profileChanging, profileLoading });
  }
  function announceSyncState() {
    const state = getStudySyncState(), error = state === 'error' || state === 'signed-out' && Number(lastSyncError?.status) === 401 ? lastSyncError : null;
    try { window.dispatchEvent(new CustomEvent('studyhub:sync-state', { detail: { state, ready: state === 'confirmed', status: $('studyhubSyncStatus')?.textContent || '', error: typeof error?.message === 'string' ? error.message : '', code: typeof error?.code === 'string' ? error.code : '', httpStatus: Number(error?.status) || 0 } })); } catch { /* el evento solo refresca controles visuales */ }
  }
  function announceProfileChanging() { try { window.dispatchEvent(new CustomEvent('studyhub:auth-state', { detail: { state: 'changing' } })); } catch { /* el evento solo invalida la sesión activa del Study Kit */ } }
  function beginProfileTransition() {
    if (profileChanging) return false;
    profileChanging = true;
    clearTimeout(flushTimer); flushTimer = null; clearSyncRetry();
    eventStream?.abort(); eventStream = null;
    if (remotePoll) clearInterval(remotePoll); remotePoll = null;
    announceProfileChanging(); announceSyncState();
    return true;
  }
  function restoreProfileStreams() { if (serverAuth && user && !profileChanging && !profileLoading) { openEventStream(); startCloudFileSync(); } }
  function waitForSyncIdle(timeoutMs = 35000) {
    if (!syncing) return Promise.resolve(true);
    return new Promise(resolve => {
      let settled = false, timer = null;
      const finish = idle => { if (settled) return; settled = true; clearTimeout(timer); syncIdleWaiters.delete(waiter); resolve(idle); };
      const waiter = () => finish(true);
      timer = setTimeout(() => finish(false), timeoutMs);
      syncIdleWaiters.add(waiter);
    });
  }
  function resolveSyncIdleWaiters() { for (const waiter of [...syncIdleWaiters]) waiter(); }
  function syncProfileIsCurrent(profileId, generation) { return profileGeneration === generation && String(user?.id || '') === profileId; }
  function isActiveProfileGeneration(generation) { return Number(generation) === profileGeneration && !!serverAuth && !!user && !profileChanging && !profileLoading; }
  function showLocalNotice(message) { const s = $('studyhubSyncStatus'); if (s) s.title = String(message || ''); let box = $('studyhubNotice'); if (!box) { box = document.createElement('div'); box.id = 'studyhubNotice'; box.className = 'hub-toast'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); document.body.append(box); } box.textContent = String(message || ''); box.hidden = false; clearTimeout(noticeTimer); noticeTimer = setTimeout(() => { if (box.isConnected) box.hidden = true; }, 8500); }
  async function discardRejectedStudyKit(error) {
    const diagnostic = error?.integrity;
    if (error?.code !== 'invalid_study_kit_integrity' || typeof diagnostic?.kitId !== 'string' || !diagnostic.kitId || !user?.id) return false;
    const snapshot = getState();
    if (!snapshot || !Array.isArray(snapshot.subjects)) return false;
    const matches = [];
    for (const subject of snapshot.subjects) for (const clazz of Array.isArray(subject?.classes) ? subject.classes : []) {
      if (!Array.isArray(clazz?.studyKits)) continue;
      clazz.studyKits.forEach((kit, index) => { if (kit?.id === diagnostic.kitId) matches.push({ clazz, index, kit }); });
    }
    if (matches.length !== 1) return false;
    const { clazz, index, kit } = matches[0];
    const fields = Array.isArray(diagnostic.fields) ? diagnostic.fields.join(', ') : 'sin campos detallados';
    const detail = `Diagnóstico ${String(diagnostic.branch || '?')}: ${String(diagnostic.reason || 'integridad')} (${fields}).`;
    const title = String(kit.title || 'Study Kit').slice(0, 100);
    if (!window.confirm(`La nube rechazó «${title}». ${detail}\n\n¿Quitar únicamente este kit del contenido activo? Antes guardaré una copia recuperable local de la instantánea completa; luego se sincronizará el resto del perfil.`)) return false;
    try {
      await saveRecovery(user.id, snapshot, revision, 'Copia local anterior a descartar un Study Kit rechazado por integridad');
      await clearPendingOperation();
    } catch {
      showLocalNotice('No se descartó el Study Kit: no pude guardar primero una copia recuperable. Los datos locales y la nube siguen intactos.');
      return false;
    }
    clazz.studyKits.splice(index, 1);
    setState(snapshot);
    localSave();
    refreshUI();
    pending = true;
    clearSyncRetry(true);
    retrySoon = true;
    showLocalNotice('Se guardó una copia recuperable local y se quitó solo el Study Kit rechazado. El resto del perfil se volverá a sincronizar.');
    return true;
  }
  function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
  function getState() { try { return clone(appData); } catch { return null; } }
  function setState(value) { appData = typeof window.normalize === 'function' ? window.normalize(clone(value)) : clone(value); }
  function localSave() { applyingRemote = true; try { originalSave?.(); } finally { applyingRemote = false; } }
  function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

  let metaDb = null, metaDbOpen = null;
  function metaOpen() {
    if (metaDb) return Promise.resolve(metaDb);
    if (metaDbOpen) return metaDbOpen;
    metaDbOpen = new Promise((resolve, reject) => {
      const request = indexedDB.open(META_DB, 1);
      request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains(META_STORE)) request.result.createObjectStore(META_STORE); };
      request.onsuccess = () => { metaDb = request.result; metaDb.onversionchange = () => { metaDb?.close(); metaDb = null; metaDbOpen = null; }; const db = metaDb; metaDbOpen = null; resolve(db); };
      request.onerror = () => { const error = request.error || new Error('No se pudo abrir la base de sincronización.'); metaDbOpen = null; reject(error); };
    });
    return metaDbOpen;
  }
  async function metaGet(key) {
    try { const db = await metaOpen(); return await new Promise((resolve, reject) => { const r = db.transaction(META_STORE, 'readonly').objectStore(META_STORE).get(key); r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error); }); }
    catch { return null; }
  }
  async function metaSet(key, value) {
    const db = await metaOpen();
    return new Promise((resolve, reject) => { const tx = db.transaction(META_STORE, 'readwrite'); tx.objectStore(META_STORE).put(value, key); tx.oncomplete = () => resolve(true); tx.onerror = () => reject(tx.error); });
  }
  async function metaDel(key) {
    const db = await metaOpen();
    return new Promise((resolve, reject) => { const tx = db.transaction(META_STORE, 'readwrite'); tx.objectStore(META_STORE).delete(key); tx.oncomplete = () => resolve(true); tx.onerror = () => reject(tx.error); });
  }
  async function payloadFingerprint(value) {
    if (!globalThis.crypto?.subtle) throw new Error('No se puede verificar la operación sin HTTPS/WebCrypto.');
    const bytes = new TextEncoder().encode(JSON.stringify(value)), hash = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, '0')).join('');
  }
  function pendingOperationKey(profileId = String(user?.id || '')) { return profileId ? metaPrefix(profileId) + 'pending-operation' : ''; }
  async function getPendingOperation(payload, profileId = String(user?.id || '')) {
    const hash = await payloadFingerprint(payload), key = pendingOperationKey(profileId), saved = await metaGet(key);
    if (saved?.hash === hash && typeof saved.id === 'string') return { id: saved.id, hash };
    const next = { id: crypto.randomUUID(), hash }; await metaSet(key, next); return next;
  }
  async function clearPendingOperation(profileId = String(user?.id || '')) { const key = pendingOperationKey(profileId); if (key) await metaDel(key); }
  async function saveBase(snapshot, rev, profileId = String(user?.id || '')) {
    if (!profileId) return;
    if (String(user?.id || '') === profileId) { revision = rev; baseSnapshot = clone(snapshot); }
    await metaSet(metaPrefix(profileId) + 'base', { revision: rev, snapshot: clone(snapshot) });
  }
  async function saveRecovery(profileId, snapshot, rev, source) {
    const key = `${metaPrefix(profileId)}recovery:${Date.now()}:${crypto.randomUUID()}`;
    await metaSet(key, { snapshot: clone(snapshot), revision: rev, source, createdAt: new Date().toISOString() });
    return key;
  }

  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set('X-EstudioHUB-Request', '1');
    return fetch(path, { credentials: 'same-origin', cache: 'no-store', ...options, headers, signal: options.signal || AbortSignal.timeout(30000) });
  }
  function noteServerTime(data, requestStartedAt, responseReceivedAt) {
    const serverNow = Number(data?.serverNow);
    if (Number.isSafeInteger(serverNow)) window.StudyKitSessionClock?.syncServerNow?.(serverNow, requestStartedAt, responseReceivedAt);
  }
  function serverNow() { return window.StudyKitSessionClock?.now?.() ?? null; }
  function syncResponseError(response, message, data = {}) {
    const error = new Error(message || `La nube respondió con estado ${response.status}.`);
    error.status = response.status;
    error.code = typeof data.code === 'string' ? data.code : '';
    error.integrity = data.integrity && typeof data.integrity === 'object' ? data.integrity : null;
    const retryAfter = Number(response.headers.get('Retry-After'));
    if (Number.isFinite(retryAfter) && retryAfter > 0) error.retryAfterMs = Math.min(300000, retryAfter * 1000);
    return error;
  }
  function handleExpiredCloudSession(error) {
    if (Number(error?.status) !== 401 || !serverAuth) return false;
    if (typeof error.code !== 'string' || !error.code) error.code = 'authentication_required';
    serverAuth = false; profileGeneration += 1; pending = true; lastSyncError = error;
    eventStream?.abort(); eventStream = null;
    if (remotePoll) clearInterval(remotePoll); remotePoll = null;
    clearTimeout(flushTimer); flushTimer = null; clearSyncRetry(true);
    setStatus('Sesión Google vencida · guardado local', user?.name || user?.email || 'Perfil local');
    const code = typeof error?.code === 'string' && error.code ? ` (${error.code})` : '';
    showLocalNotice(`La sesión de Google venció (HTTP 401${code}). La sesión de estudio y el resto de los datos siguen guardados localmente; vuelve a conectar el perfil para sincronizar.`);
    announceSyncState();
    return true;
  }
  function clearSyncRetry(resetAttempt = false) {
    if (syncRetryTimer) clearTimeout(syncRetryTimer);
    syncRetryTimer = null;
    if (resetAttempt) syncRetryAttempt = 0;
  }
  function isRetryableSyncError(error) {
    if (error?.retryable === false) return false;
    const status = Number(error?.status);
    return !Number.isFinite(status) || status <= 0 || [408, 425, 429].includes(status) || status >= 500;
  }
  function scheduleSyncRetry(minimumDelay = 0) {
    if (!user || !serverAuth || !pending || !navigator.onLine || conflictOpen || profileChanging) return;
    clearSyncRetry();
    const base = Math.min(60_000, 1_000 * (2 ** Math.min(syncRetryAttempt, 6)));
    const delay = Math.max(Math.min(300_000, Number(minimumDelay) || 0), Math.round(base * (0.85 + Math.random() * 0.3)));
    syncRetryAttempt = Math.min(syncRetryAttempt + 1, 6);
    syncRetryTimer = setTimeout(() => { syncRetryTimer = null; void flushSync(); }, delay);
  }
  function findFileMeta(data, key) {
    const stack = [data], seen = new Set();
    while (stack.length) { const item = stack.pop(); if (!item || typeof item !== 'object' || seen.has(item)) continue; seen.add(item); if (!Array.isArray(item) && item.key === key) return item; for (const value of Array.isArray(item) ? item : Object.values(item)) if (value && typeof value === 'object') stack.push(value); }
    return null;
  }
  function stateSummary(data) {
    const subjects = Array.isArray(data?.subjects) ? data.subjects : [];
    let classes = 0, files = 0;
    for (const s of subjects) { classes += (s.classes || []).length; files += (s.files || []).length; for (const c of s.classes || []) files += (c.files || []).length; }
    files += (data?.library || data?.biblioteca || []).length;
    return { subjects: subjects.length, classes, files };
  }
  function hasUserContent(data) {
    if (!data || !Array.isArray(data.subjects)) return false;
    const defaults = new Set(['ing2', 'sist', 'est', 'eco2', 'cont', 'grh', 'costos']);
    if (data.subjects.some(s => !defaults.has(s.id))) return true;
    for (const s of data.subjects) {
      if (s.notes || (s.files || []).length || (s.classes || []).length || (s.tasks || []).length || (s.grades || []).some(g => g.grade || g.weight) || Number(s.passGrade || 4) !== 4) return true;
      if ((s.kanbanTasks || []).length || (s.customFormulas || []).length) return true;
    }
    const seen = new Set();
    function visit(x, key = '') {
      if (!x || typeof x !== 'object' || seen.has(x)) return false; seen.add(x);
      if (Array.isArray(x)) { if (['library', 'biblioteca', 'documents', 'formulas'].includes(key) && x.length) return true; return x.some(y => visit(y, key)); }
      for (const [k, v] of Object.entries(x)) {
        if (['notes', 'key', 'content', 'summary', 'customFormulas', 'quizzes', 'trainingHistory'].includes(k) && ((typeof v === 'string' && v.trim()) || (Array.isArray(v) && v.length))) return true;
        if (['cells', 'files', 'images'].includes(k) && v && typeof v === 'object' && (Array.isArray(v) ? v.length : Object.keys(v).length)) return true;
        if (visit(v, k)) return true;
      }
      return false;
    }
    return visit(data);
  }
  function equal(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
  function merge3(...args) {
    if (typeof window.StudyHubSyncMerge?.merge3 !== 'function') throw new Error('No se cargó el reconciliador de sincronización.');
    return window.StudyHubSyncMerge.merge3(...args);
  }

  function appOverlay(title, body, actions) {
    const overlay = document.createElement('div'); overlay.className = 'hub-dialog-backdrop'; overlay.setAttribute('role', 'dialog'); overlay.setAttribute('aria-modal', 'true');
    overlay.innerHTML = `<div class="hub-dialog"><h3>${escapeHtml(title)}</h3><div class="hub-dialog-body">${body}</div><div class="hub-dialog-actions"></div></div>`;
    const actionsBox = overlay.querySelector('.hub-dialog-actions');
    for (const action of actions) { const b = document.createElement('button'); b.textContent = action.label; b.className = action.primary ? 'primary' : ''; b.onclick = async () => { b.disabled = true; try { await action.run(); } finally { overlay.remove(); } }; actionsBox.append(b); }
    document.body.append(overlay); return overlay;
  }

  function ensureProfileDialog() {
    let overlay = $('studyhubProfileDialog');
    if (overlay) return overlay;
    overlay = document.createElement('div'); overlay.id = 'studyhubProfileDialog'; overlay.className = 'hub-dialog-backdrop'; overlay.hidden = true; overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `<div class="hub-dialog hub-profile-dialog" role="dialog" aria-modal="true" aria-labelledby="studyhubProfileTitle">
      <div class="hub-profile-head"><div><p class="hub-profile-eyebrow">CUENTA Y SINCRONIZACIÓN</p><h3 id="studyhubProfileTitle">Perfil</h3></div><button type="button" class="hub-profile-close" data-profile-close aria-label="Cerrar perfil">×</button></div>
      <p id="studyhubProfileStatus" class="hub-profile-status"></p><div id="studyhubProfileDetails"></div><p id="studyhubProfileMessage" class="hub-profile-message"></p>
      <div id="googleButtonHost" aria-label="Iniciar sesión con Google"></div><div id="studyhubProfileError" class="hub-profile-error" role="status" aria-live="polite" hidden></div>
      <details id="studyhubSyncTools" class="hub-profile-tools"><summary><i class="fa-solid fa-cloud-arrow-up" aria-hidden="true"></i><span>Sincronización y recuperación</span></summary>
        <div class="hub-profile-tools-content"><p id="studyhubSyncToolsHint" class="hub-profile-tools-hint">Inicia sesión con Google para sincronizar y administrar las versiones recuperables.</p>
          <div class="hub-profile-tools-actions">
            <button type="button" id="studyhubSyncNow" class="hub-profile-tool-button" hidden>Sincronizar ahora</button>
            <button type="button" id="studyhubFileArchiveButton" class="hub-profile-tool-button" hidden>Versiones recuperables (0)</button>
            <button type="button" id="studyhubRecoveryExport" class="hub-profile-tool-button" hidden>Descargar recuperación (0)</button>
          </div>
        </div>
      </details>
      <div id="studyhubProfileActions" class="hub-profile-actions"></div>
      <p class="hub-profile-footnote">No se guardan contraseñas ni tokens de Google en este perfil. Si el navegador separa la vista integrada de la pestaña normal, inicia sesión en el mismo modo de ventana que estés usando.</p>
    </div>`;
    document.body.append(overlay);
    overlay.querySelector('[data-profile-close]')?.addEventListener('click', closeProfile);
    overlay.addEventListener('click', event => { if (event.target === overlay) closeProfile(); });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && !overlay.hidden) closeProfile(); });
    overlay.querySelector('#studyhubSyncNow')?.addEventListener('click', () => void syncNow());
    overlay.querySelector('#studyhubFileArchiveButton')?.addEventListener('click', reviewFileArchives);
    overlay.querySelector('#studyhubRecoveryExport')?.addEventListener('click', () => void downloadLatestRecovery());
    return overlay;
  }
  function closeProfile() {
    const overlay = $('studyhubProfileDialog'); if (!overlay) return;
    overlay.hidden = true; overlay.setAttribute('aria-hidden', 'true'); $('studyhubProfileButton')?.focus();
  }
  function profileInitials(value) { return String(value || 'E').trim().split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toLocaleUpperCase('es') || 'E'; }
  function refreshProfileTrigger() {
    const button = $('studyhubProfileButton'), indicator = $('studyhubProfileIndicator'); if (!button) return;
    button.classList.toggle('is-connected', !!(serverAuth && user));
    button.setAttribute('aria-label', serverAuth && user ? `Perfil de ${user.name || user.email || 'Estudiante'}; sesión activa` : 'Abrir Perfil e iniciar sesión con Google');
    button.title = serverAuth && user ? `${user.name || user.email || 'Estudiante'} · sesión Google activa` : 'Perfil local o iniciar sesión con Google';
    if (indicator) indicator.classList.toggle('active', !!(serverAuth && user));
  }
  function setProfileError(message) {
    const node = $('studyhubProfileError'); if (!node) return;
    node.textContent = String(message || ''); node.hidden = !message;
  }
  function renderProfilePanel() {
    const overlay = $('studyhubProfileDialog'); if (!overlay || overlay.hidden) return;
    const status = $('studyhubProfileStatus'), details = $('studyhubProfileDetails'), message = $('studyhubProfileMessage'), host = $('googleButtonHost'), actions = $('studyhubProfileActions');
    if (!status || !details || !message || !host || !actions) return;
    const toolsHint = $('studyhubSyncToolsHint'); if (toolsHint) toolsHint.hidden = !!user;
    const tools = $('studyhubSyncTools'); if (tools && pending) tools.open = true;
    const syncText = $('studyhubSyncStatus')?.textContent || (pending ? 'Pendiente de sincronizar' : 'Solo en este dispositivo');
    if (serverAuth && user) {
      const last = user.lastSignedIn && Number.isFinite(Date.parse(user.lastSignedIn)) ? new Date(user.lastSignedIn).toLocaleString('es-CL') : '';
      status.textContent = 'Cuenta Google conectada'; status.classList.add('is-connected');
      details.innerHTML = `<div class="hub-profile-person"><div class="hub-profile-avatar" aria-hidden="true">${escapeHtml(profileInitials(user.name || user.email))}</div><div><strong>${escapeHtml(user.name || 'Estudiante')}</strong><p>${escapeHtml(user.email || 'Correo no disponible')}</p></div></div><dl class="hub-profile-facts"><div><dt>Proveedor</dt><dd>${escapeHtml(user.provider || user.loginMethod || 'Google')}</dd></div><div><dt>ID de perfil</dt><dd>${escapeHtml(user.id)}</dd></div><div><dt>Sesión</dt><dd>Activa</dd></div><div><dt>Sincronización</dt><dd>${escapeHtml(syncText)}</dd></div>${last ? `<div><dt>Último acceso</dt><dd>${escapeHtml(last)}</dd></div>` : ''}</dl>`;
      message.textContent = 'Este perfil está asociado a tu cuenta Google. Sus datos y archivos se mantienen separados de otros perfiles.';
      host.hidden = true;
      actions.innerHTML = '<button type="button" class="hub-profile-secondary" data-profile-switch>Cambiar cuenta</button><button type="button" class="hub-profile-danger" data-profile-logout>Cerrar sesión</button>';
      actions.querySelector('[data-profile-switch]')?.addEventListener('click', () => void switchAccount());
      actions.querySelector('[data-profile-logout]')?.addEventListener('click', () => void logout());
    } else {
      const localName = user?.name || user?.email || 'Perfil local';
      status.textContent = user ? 'Perfil local · sesión cloud no confirmada' : 'Perfil local'; status.classList.remove('is-connected');
      details.innerHTML = `<div class="hub-profile-person"><div class="hub-profile-avatar" aria-hidden="true">${escapeHtml(profileInitials(localName))}</div><div><strong>${escapeHtml(localName)}</strong><p>${user ? 'Copia disponible en este dispositivo' : 'Sin cuenta Google conectada'}</p></div></div>${user?.id ? `<dl class="hub-profile-facts"><div><dt>ID de perfil</dt><dd>${escapeHtml(user.id)}</dd></div></dl>` : ''}`;
      message.textContent = !navigator.onLine ? 'Sin conexión: puedes seguir usando el perfil local. Conéctate para iniciar sesión y sincronizar.' : user ? 'La copia local se conserva. Inicia sesión para volver a validar y sincronizar este perfil.' : 'Inicia sesión con Google para ver tu perfil privado y sincronizar entre dispositivos.';
      host.hidden = !navigator.onLine;
      actions.innerHTML = user && navigator.onLine ? '<button type="button" class="hub-profile-secondary" data-profile-switch>Cambiar cuenta</button>' : '';
      actions.querySelector('[data-profile-switch]')?.addEventListener('click', () => void switchAccount());
    }
  }
  function openProfile() {
    const overlay = ensureProfileDialog(); overlay.hidden = false; overlay.setAttribute('aria-hidden', 'false');
    renderProfilePanel();
    refreshProfileToolState(); void refreshRecoveryButton();
    if (!serverAuth && navigator.onLine) { setProfileError(''); void loadGoogleConfig(); }
    overlay.querySelector('[data-profile-close]')?.focus();
  }
  async function switchAccount() {
    const signedOut = await logout(); if (!signedOut) return;
    window.google?.accounts?.id?.disableAutoSelect?.();
    const overlay = ensureProfileDialog(); overlay.hidden = false; overlay.setAttribute('aria-hidden', 'false');
    renderProfilePanel();
    if (navigator.onLine) await loadGoogleConfig();
    else setProfileError('Conéctate a Internet para elegir otra cuenta Google.');
  }

  function showMigrationChoice(guest) {
    reveal();
    const sum = stateSummary(guest);
    return new Promise(resolve => appOverlay('Datos locales encontrados', `<p>Esta cuenta Google aún no tiene una copia en la nube. En este dispositivo hay datos locales: <b>${sum.subjects} ramos</b>, <b>${sum.classes} clases</b> y <b>${sum.files} referencias a archivos</b>.</p><p>La importación conserva el original en este dispositivo. No se borrará información local.</p>`, [
      { label: 'Importar datos locales', primary: true, run: () => resolve('import') },
      { label: 'Empezar con el perfil cloud', run: () => resolve('blank') },
    ]));
  }
  function showInitialChoice(local, remote, remoteRevision, title = 'Hay datos en dos lugares') {
    reveal();
    const sum = stateSummary(local);
    return new Promise(resolve => appOverlay(title, `<p>La cuenta ya tiene una versión confirmada en nube y también existe otra copia en este dispositivo (<b>${sum.subjects} ramos</b>, <b>${sum.classes} clases</b>, <b>${sum.files} archivos</b>).</p><p>Para evitar mezclar perfiles o sobrescribir cambios, no se combinarán automáticamente. Puedes usar la nube o reemplazarla explícitamente con la copia local. Si la otra copia ya pertenece a esta cuenta, se guardará en recuperación local; si es un perfil invitado, permanecerá intacta y separada. No se borrarán archivos locales.</p>`, [
      { label: 'Usar la nube', primary: true, run: () => resolve('cloud') },
      { label: 'Reemplazar nube con este dispositivo', run: () => resolve('device') },
    ]));
  }
  function showGoogleOrGuestChoice(accountState, guestState, hasCloudCopy) {
    reveal(); const account = stateSummary(accountState), guest = stateSummary(guestState);
    return new Promise(resolve => appOverlay('Hay datos en dos perfiles', `<p>${hasCloudCopy ? 'Esta cuenta Google ya tiene datos cloud' : 'Esta cuenta Google tiene datos locales aún no sincronizados'} (<b>${account.subjects} ramos</b>, ${account.files} referencias a archivos). También hay un perfil invitado separado (<b>${guest.subjects} ramos</b>, ${guest.files} referencias a archivos).</p><p>No se mezclarán automáticamente. Elige qué perfil abrir. El perfil invitado quedará intacto en este dispositivo y podrás volver a él después de cerrar sesión.</p>`, [
      { label: hasCloudCopy ? 'Continuar con la cuenta Google' : 'Conservar y sincronizar la copia de cuenta', primary: true, run: () => resolve('account') },
      { label: 'Volver al perfil invitado', run: () => resolve('guest') },
    ]));
  }

  async function loadAccountProfile(account, guestBeforeLogin, transitionStarted = false) {
    if ((profileChanging && !transitionStarted) || profileLoading) throw new Error('Ya hay un cambio o carga de perfil en curso.');
    if (syncing && !(await waitForSyncIdle())) throw new Error('La sincronización sigue activa; no se cambió de perfil y tus datos permanecen guardados.');
    profileLoading = true;
    if (!transitionStarted) { beginProfileTransition(); profileGeneration += 1; }
    guestSnapshot = clone(guestBeforeLogin);
    user = account; serverAuth = true;
    pending = false; lastSyncError = null; conflictOpen = false; revision = 0; baseSnapshot = null;
    localStorage.setItem('estudiohub_last_profile', JSON.stringify({ id: account.id, name: account.name, email: account.email }));
    const accountStorageKey = profileKey(account.id), hadUserCache = localStorage.getItem(accountStorageKey) !== null;
    const guestState = clone(guestBeforeLogin);
    window.setEstudioStorageNamespace(String(account.id));
    window.loadAppData();
    profileChanging = false; announceSyncState();
    let localState = getState();
    let response, snapshot;
    try { const startedAt = performance.now(); response = await api('/api/study/state', { method: 'GET', signal: AbortSignal.timeout(15000) }); if (!response.ok) throw new Error('No se pudo leer la nube.'); snapshot = await response.json(); noteServerTime(snapshot, startedAt, performance.now()); }
    catch (error) { serverAuth = false; user = account; profileLoading = false; setStatus('Sin conexión · copia local', `Perfil local: ${account.name || account.email}`); reveal(); return; }
    const savedBase = await metaGet(metaPrefix(account.id) + 'base');
    if (snapshot.payload && hadUserCache && hasUserContent(guestState)) {
      const profileChoice = await showGoogleOrGuestChoice(localState, guestState, true);
      if (profileChoice === 'guest') { profileLoading = false; await logout(); return; }
    }
    if (snapshot.payload) {
      if (hadUserCache) { await syncReferencedFiles(localState); localState = getState() || localState; }
      if (hadUserCache && savedBase?.snapshot && Number.isInteger(savedBase.revision)) {
        const merged = merge3(savedBase.snapshot, localState, snapshot.payload);
        revision = snapshot.revision; baseSnapshot = clone(snapshot.payload);
        if (merged.conflicts.length) { await showConflictChoice(localState, snapshot, merged.conflicts, merged.value); }
        else { await preserveSnapshotFileCopies(merged.value, localState, 'Copia local recuperable', false); await preserveSnapshotFileCopies(merged.value, snapshot.payload, 'Copia cloud recuperable', false); setState(merged.value); localSave(); await saveBase(snapshot.payload, snapshot.revision); if (!equal(merged.value, snapshot.payload)) { pending = true; await flushSync(); } }
      } else if (hadUserCache && !equal(localState, snapshot.payload)) {
        const choice = await showInitialChoice(localState, snapshot.payload, snapshot.revision, 'Confirma qué copia usar');
        if (choice === 'device') {
          await saveRecovery(account.id, snapshot.payload, snapshot.revision, 'cloud-before-device-overwrite');
          const selected = clone(localState); await preserveSnapshotFileCopies(selected, snapshot.payload, 'Copia cloud recuperable', true);
          revision = snapshot.revision; baseSnapshot = clone(snapshot.payload); setState(selected); localSave(); pending = true; await flushSync();
        } else {
          await saveRecovery(account.id, localState, savedBase?.revision ?? null, 'device-before-cloud-adoption');
          const selected = clone(snapshot.payload); await preserveSnapshotFileCopies(selected, localState, 'Copia local recuperable', false);
          setState(selected); localSave(); await saveBase(snapshot.payload, snapshot.revision); pending = !equal(selected, snapshot.payload); if (pending) await flushSync();
          showLocalNotice('Se guardaron los adjuntos locales no elegidos en Versiones recuperables antes de usar la nube.');
        }
      } else if (!hadUserCache && hasUserContent(guestState)) {
        const choice = await showInitialChoice(guestState, snapshot.payload, snapshot.revision, 'Elige qué copia conservar');
        if (choice === 'device') {
          const refs = [...(window.collectFileRefs?.(guestState) || [])];
          const copied = refs.length && window.copyEstudioFileScope ? await window.copyEstudioFileScope('guest', `user_${account.id}`, refs) : { missing: refs, existing: [] };
          if (copied.missing.length || copied.conflicts.length) {
            setState(snapshot.payload); localSave(); await saveBase(snapshot.payload, snapshot.revision);
            showLocalNotice(`No se reemplazó la nube: faltan ${copied.missing.length} archivo(s) locales o hay ${copied.conflicts.length} clave(s) con contenido distinto en el perfil de cuenta. La nube permanece intacta y la copia invitada sigue separada; cierra sesión para revisarla.`);
          } else {
            await saveRecovery(account.id, snapshot.payload, snapshot.revision, 'cloud-before-guest-migration');
            revision = snapshot.revision; baseSnapshot = clone(snapshot.payload); setState(guestState); localSave(); pending = true; await flushSync();
          }
        } else {
          setState(snapshot.payload); localSave(); await saveBase(snapshot.payload, snapshot.revision);
          showLocalNotice('Se usó la copia cloud; los datos invitados y sus archivos siguen intactos y separados en este dispositivo. Cierra sesión para volver al perfil invitado.');
        }
      } else {
        setState(snapshot.payload); localSave(); await saveBase(snapshot.payload, snapshot.revision);
        if (hasUserContent(guestState)) showLocalNotice('Hay datos invitados en este dispositivo; se conservaron separados y no se mezclaron con este perfil.');
      }
    } else {
      revision = 0; baseSnapshot = null;
      if (hadUserCache && hasUserContent(guestState) && hasUserContent(localState)) {
        const profileChoice = await showGoogleOrGuestChoice(localState, guestState, false);
        if (profileChoice === 'guest') { profileLoading = false; await logout(); return; }
      }
      if (hadUserCache) { await syncReferencedFiles(localState); localState = getState() || localState; }
      if (hadUserCache && hasUserContent(guestState) && hasUserContent(localState)) {
        setState(localState); localSave(); pending = true; await flushSync();
      } else if (hadUserCache && hasUserContent(guestState) && !hasUserContent(localState)) {
        const choice = await showMigrationChoice(guestState);
        if (choice === 'import') {
          const refs = [...(window.collectFileRefs?.(guestState) || [])];
          const copied = refs.length && window.copyEstudioFileScope ? await window.copyEstudioFileScope('guest', `user_${account.id}`, refs) : { missing: refs, conflicts: [] };
          if (copied.missing.length || copied.conflicts.length) { setState(localState); localSave(); pending = false; showLocalNotice(`Se detuvo la importación: faltan ${copied.missing.length} archivo(s) o hay ${copied.conflicts.length} clave(s) con contenido distinto. El perfil invitado permanece intacto.`); }
          else { setState(guestState); localSave(); pending = true; await flushSync(); }
        } else { setState(localState); localSave(); pending = true; await flushSync(); showLocalNotice('La copia invitada permanece intacta y separada en este dispositivo; puedes volver a ella al cerrar sesión.'); }
      }
      else if (hadUserCache) { setState(localState); localSave(); pending = true; await flushSync(); }
      else if (hasUserContent(guestState)) {
        const choice = await showMigrationChoice(guestState);
        if (choice === 'import') { const refs = [...(window.collectFileRefs?.(guestState) || [])]; const copied = refs.length && window.copyEstudioFileScope ? await window.copyEstudioFileScope('guest', `user_${account.id}`, refs) : { missing: refs, conflicts: [] }; if (copied.missing.length || copied.conflicts.length) { setState(typeof window.defaultData === 'function' ? window.defaultData() : localState); localSave(); pending = false; showLocalNotice(`Se detuvo la importación: faltan ${copied.missing.length} archivo(s) o hay ${copied.conflicts.length} clave(s) con contenido distinto en el perfil. No se sobrescribió ningún archivo; los datos invitados originales siguen intactos.`); } else { setState(guestState); localSave(); pending = true; await flushSync(); } }
        else { setState(typeof window.defaultData === 'function' ? window.defaultData() : localState); localSave(); pending = true; await flushSync(); }
      } else { setState(localState); localSave(); pending = true; await flushSync(); }
    }
    if (serverAuth) {
      setStatus(pending ? 'Pendiente de confirmación' : 'Sincronizado · nube confirmada', account.name || account.email);
      openEventStream(); startCloudFileSync();
    }
    profileLoading = false; announceSyncState();
    if (pending) scheduleSyncRetry(250);
    reveal(); refreshUI();
  }

  async function applyRemote(snapshot) {
    if (snapshot.payload) setState(snapshot.payload); else if (typeof window.defaultData === 'function') setState(window.defaultData());
    localSave();
    await saveBase(snapshot.payload, snapshot.revision);
    pending = false; lastSyncError = null; setStatus('Sincronizado · nube confirmada', user?.name || user?.email || 'Perfil Google'); refreshUI();
  }

  async function showConflictChoice(localCandidate, snapshot, conflicts, mergedCandidate = null, isCurrent = () => true) {
    const stillCurrent = () => { if (isCurrent()) return true; conflictOpen = false; announceSyncState(); return false; };
    if (!stillCurrent()) return 'stale';
    reveal(); conflictOpen = true; pending = true; announceSyncState();
    const remote = snapshot?.payload || null;
    const remoteRevision = Number.isInteger(snapshot?.revision) ? snapshot.revision : revision;
    const hasConfirmedCloud = !!remote;
    try {
      if (hasConfirmedCloud && user?.id) { await saveRecovery(user.id, localCandidate, revision, 'automatic-cloud-wins-conflict'); if (!stillCurrent()) return 'stale'; }
      const selected = hasConfirmedCloud
        ? clone(mergedCandidate || remote)
        : clone(localCandidate || (typeof window.defaultData === 'function' ? window.defaultData() : {}));
      let cloudRecoveryArchived = false;
      if (hasConfirmedCloud) {
        const localFileMap = await preserveSnapshotFileCopies(selected, localCandidate, 'Copia local desplazada por nube · recuperable', false);
        if (!stillCurrent()) return 'stale';
        await preserveSnapshotFileCopies(selected, remote, 'Copia cloud recuperable', false);
        if (!stillCurrent()) return 'stale';
        cloudRecoveryArchived = await addRecoverySnapshotFile(selected, localCandidate, remoteRevision, conflicts, localFileMap);
        if (!stillCurrent()) return 'stale';
        if (!cloudRecoveryArchived) throw new Error('No se pudo preparar el snapshot recuperable; se conservó el estado local sin reemplazarlo.');
      }
      await saveBase(remote, remoteRevision);
      if (!stillCurrent()) return 'stale';
      setState(selected); localSave();
      pending = !hasConfirmedCloud || !equal(selected, remote);
      conflictOpen = false; lastSyncError = null; refreshUI();
      if (pending) {
        setStatus(hasConfirmedCloud ? 'Cambios fusionados · sincronizando' : 'Cambios locales pendientes de subir', user?.name || user?.email || 'Perfil local');
        scheduleSyncRetry(250);
      } else setStatus('Sincronizado · nube confirmada', user?.name || user?.email || 'Perfil Google');
      showLocalNotice(hasConfirmedCloud
        ? `Conflicto resuelto automáticamente: los cambios independientes se fusionaron y la nube confirmada prevaleció en ${conflicts.length} campo(s) coincidente(s). ${cloudRecoveryArchived ? 'La copia local quedó preparada en Versiones recuperables y seguirá pendiente hasta que la nube confirme la subida.' : 'La copia local permanece recuperable en este dispositivo.'}`
        : 'No había una revisión cloud que pudiera prevalecer. Se mantuvieron los cambios locales y se enviarán a la nube al confirmar la sincronización.');
      return hasConfirmedCloud ? 'cloud' : 'local';
    } catch (error) {
      if (!stillCurrent()) return 'stale';
      conflictOpen = false; pending = true; lastSyncError = error;
      setStatus('Pendiente · copia local conservada', user?.name || user?.email || 'Perfil local');
      showLocalNotice(`No se pudo archivar y verificar todas las versiones antes de resolver el conflicto: ${error.message || 'falló la verificación'}. No se reemplazó la copia local.`);
      if (isRetryableSyncError(error)) scheduleSyncRetry(Number(error?.retryAfterMs) || 0);
      return 'failed';
    }
  }

  async function listCloudFiles() {
    const response = await api('/api/files'); if (!response.ok) throw syncResponseError(response, 'No se pudo consultar los archivos cloud.');
    const data = await response.json(); return new Map((data.files || []).map(item => [item.localKey, item]));
  }
  async function fileChecksum(blob) {
    if (!globalThis.crypto?.subtle) throw new Error('Este navegador no permite comparar archivos de forma segura; abre EstudioHUB por HTTPS.');
    const hash = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
    return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, '0')).join('');
  }
  function normalizeCloudChecksum(value) {
    return String(value || '').trim().replace(/^W\//i, '').replace(/^"|"$/g, '').trim().toLowerCase();
  }
  function isCloudSha256(value) { return /^[a-f0-9]{64}$/.test(normalizeCloudChecksum(value)); }
  function cloudReadIsRetryable(error) {
    if (error?.retryable === false) return false;
    const status = Number(error?.status);
    if (Number.isFinite(status)) return [408, 425, 429].includes(status) || status >= 500;
    return ['TypeError', 'AbortError', 'TimeoutError'].includes(String(error?.name || ''));
  }
  async function retryCloudReadOnce(operation) {
    try { return await operation(); }
    catch (error) {
      if (!cloudReadIsRetryable(error)) throw error;
      const retryAfter = Math.min(2000, Math.max(250, Number(error?.retryAfterMs) || 0));
      await new Promise(resolve => setTimeout(resolve, retryAfter));
      return operation();
    }
  }
  const FILE_REF_KEYS = new Set(['key', 'tk', 'fileKey']);
  function remapFileReferences(value, fromKey, toKey, seen = new WeakSet()) {
    if (!value || typeof value !== 'object' || seen.has(value)) return;
    seen.add(value);
    for (const [key, item] of Object.entries(value)) {
      if (FILE_REF_KEYS.has(key) && item === fromKey) value[key] = toKey;
      else if (item && typeof item === 'object') remapFileReferences(item, fromKey, toKey, seen);
    }
  }
  async function addArchiveFile(state, key, fileName, source) {
    if (!Array.isArray(state.studyhubFileArchives)) state.studyhubFileArchives = [];
    const existing = state.studyhubFileArchives.find(item => item?.key === key);
    const blob = await localBlobForKey(key);
    if (!blob) throw new Error(`No se pudo verificar el archivo que iba a archivarse: ${fileName || key}.`);
    const checksum = await fileChecksum(blob), size = blob.size, mimeType = blob.type || 'application/octet-stream';
    if (existing) {
      if (existing.checksumAlgorithm !== 'sha256' || !/^[a-f0-9]{64}$/i.test(String(existing.checksum || '')) || !Number.isSafeInteger(existing.size)) return false;
      if (existing.size !== size || existing.checksum !== checksum) throw new Error(`La copia recuperable ${fileName || key} cambió respecto del checksum registrado; no se confirmó la operación.`);
      return false;
    }
    const name = String(fileName || key).replace(/[\\/\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 255) || key;
    state.studyhubFileArchives.push({ id: `archive_${crypto.randomUUID()}`, key, fileName: name, title: `${source}: ${name}`, source, checksumAlgorithm: 'sha256', checksum, size, mimeType, createdAt: new Date().toISOString() });
    return true;
  }
  async function localBlobForKey(key) { return localFileGet ? localFileGet(key) : FS.get(key); }
  async function allocatePrivateFileKey(remoteFiles) {
    for (let attempt = 0; attempt < 8; attempt++) {
      const key = `f_${crypto.randomUUID().replace(/-/g, '')}`;
      if (remoteFiles.has(key)) continue;
      if ((await localBlobForKey(key)) === undefined) return key;
    }
    throw new Error('No se pudo generar una clave nueva para conservar las dos versiones.');
  }
  async function downloadVerifiedCloudBlob(path, expectedChecksum, fileName, observedHeaders = []) {
    const expected = normalizeCloudChecksum(expectedChecksum);
    if (!isCloudSha256(expected)) {
      const error = new Error(`La nube no devolvió un SHA-256 válido para ${fileName || 'el archivo'}; no se modificó ninguna copia.`);
      error.code = 'CLOUD_FILE_CHECKSUM_INVALID';
      error.retryable = false;
      throw error;
    }
    return retryCloudReadOnce(async () => {
      const response = await api(path);
      if (!response.ok) throw syncResponseError(response, `No se pudo descargar la copia cloud de ${fileName || 'el archivo'}.`);
      const blob = await response.blob();
      const actualChecksum = await fileChecksum(blob);
      const responseHeaders = [
        normalizeCloudChecksum(response.headers.get('X-Content-Checksum')),
        normalizeCloudChecksum(response.headers.get('ETag'))
      ].filter(isCloudSha256);
      const headerMismatch = [...observedHeaders, ...responseHeaders]
        .map(normalizeCloudChecksum)
        .filter(isCloudSha256)
        .some(checksum => checksum !== expected);
      if (actualChecksum !== expected) {
        const error = new Error(`El SHA-256 del archivo ${fileName || 'cloud'} no coincide con el checksum registrado. Se conservaron todas las copias; no se reparó ni descartó ningún dato. Puedes reintentar la sincronización o recuperación.${headerMismatch ? ' Los encabezados de transporte discrepaban, pero no se usaron como verificación final.' : ''}`);
        error.code = 'CLOUD_FILE_CHECKSUM_MISMATCH';
        error.retryable = false;
        throw error;
      }
      return blob;
    });
  }
  async function downloadCloudFile(key, remote) {
    if (!serverAuth || !user || !navigator.onLine) throw new Error('Conéctate para recuperar y verificar la copia cloud antes de resolver el archivo.');
    const path = `/api/files/${encodeURIComponent(key)}`;
    const expected = normalizeCloudChecksum(remote?.checksum);
    if (!isCloudSha256(expected)) {
      const error = new Error(`No hay un checksum SHA-256 registrado válido para ${remote?.fileName || key}; no se modificó ninguna copia.`);
      error.code = 'CLOUD_FILE_CHECKSUM_INVALID';
      error.retryable = false;
      throw error;
    }
    const observedHeaders = [];
    try {
      const head = await api(path, { method: 'HEAD' });
      if (head.status === 404) throw syncResponseError(head, `La copia cloud de ${remote?.fileName || key} ya no está disponible; no se modificó ninguna copia.`);
      if (head.ok) observedHeaders.push(head.headers.get('X-Content-Checksum'), head.headers.get('ETag'));
    } catch (error) {
      if (Number(error?.status) === 404) throw error;
      // HEAD y sus metadatos son informativos; el GET y su SHA-256 deciden si el archivo se acepta.
    }
    return downloadVerifiedCloudBlob(path, expected, remote?.fileName || key, observedHeaders);
  }
  if (window.__ESTUDIOHUB_CLOUD_TEST_MODE__ === true) {
    window.__ESTUDIOHUB_CLOUD_TEST_HOOKS__ = {
      normalizeCloudChecksum,
      downloadCloudFile,
      preserveSnapshotFileCopies,
      authorizeTestUser() { user = { id: 'test-user' }; serverAuth = true; }
    };
    return;
  }
  async function preserveSnapshotFileCopies(target, other, sourceLabel, targetKeepsLocal = false, onlyKeys = null) {
    const targetRefs = new Set(window.collectFileRefs?.(target) || []);
    const otherRefs = [...(window.collectFileRefs?.(other) || [])].filter(key => !onlyKeys || onlyKeys.has(key));
    if (!otherRefs.length) return new Map();
    const archivedLocalKeys = new Map();
    const remoteFiles = await listCloudFiles();
    for (const key of otherRefs) {
      const remote = remoteFiles.get(key), localBlob = await localBlobForKey(key);
      const fileMeta = findFileMeta(other, key) || findFileMeta(target, key);
      const fileName = fileMeta?.name || fileMeta?.fileName || localBlob?.name || remote?.fileName || key;
      if (remote) {
        const localChecksum = localBlob ? await fileChecksum(localBlob) : null;
        if (localBlob && localChecksum !== remote.checksum) {
          const targetHadKey = targetRefs.has(key), localCopyKey = await allocatePrivateFileKey(remoteFiles);
          let wroteLocalCopy = false, replacedOriginal = false;
          try {
            await FS.put(localCopyKey, localBlob); wroteLocalCopy = true;
            const savedLocalCopy = await localBlobForKey(localCopyKey);
            if (!savedLocalCopy || await fileChecksum(savedLocalCopy) !== localChecksum) throw new Error('La copia local no superó la verificación posterior a su escritura.');
            const cloudBlob = await downloadCloudFile(key, remote);
            await FS.put(key, cloudBlob); replacedOriginal = true;
            const savedCloudCopy = await localBlobForKey(key);
            if (!savedCloudCopy || await fileChecksum(savedCloudCopy) !== remote.checksum) throw new Error('La copia cloud local no superó la verificación posterior a su escritura.');
            if (targetKeepsLocal && targetHadKey) remapFileReferences(target, key, localCopyKey);
            else { await addArchiveFile(target, localCopyKey, fileName, 'Copia local divergente recuperada'); archivedLocalKeys.set(key, localCopyKey); }
            if (!(targetKeepsLocal && targetHadKey)) targetRefs.add(localCopyKey);
            if (targetKeepsLocal || !targetHadKey) await addArchiveFile(target, key, remote.fileName || fileName, 'Copia cloud anterior recuperada');
            targetRefs.add(key);
          } catch (error) {
            if (replacedOriginal) await FS.put(key, localBlob).catch(() => {});
            if (wroteLocalCopy) await FS.del(localCopyKey).catch(() => {});
            throw error;
          }
        } else {
          if (!localBlob) {
            const cloudBlob = await downloadCloudFile(key, remote);
            await FS.put(key, cloudBlob);
            const savedCloudCopy = await localBlobForKey(key);
            if (!savedCloudCopy || await fileChecksum(savedCloudCopy) !== remote.checksum) throw new Error('La copia cloud no quedó disponible para recuperación offline.');
          }
          if (!targetRefs.has(key)) await addArchiveFile(target, key, remote.fileName || fileName, sourceLabel);
          targetRefs.add(key);
        }
      } else {
        if (!localBlob) throw new Error(`Falta el archivo ${fileName} en ambos lugares; no se eligió ni reemplazó ninguna copia.`);
        if (!targetRefs.has(key)) await addArchiveFile(target, key, fileName, sourceLabel);
        targetRefs.add(key);
      }
    }
    return archivedLocalKeys;
  }
  async function archiveRemovedCloudFiles(payload, previous) {
    if (!previous) return false;
    const currentRefs = new Set(window.collectFileRefs?.(payload) || []);
    const removedRefs = new Set([...(window.collectFileRefs?.(previous) || [])].filter(key => !currentRefs.has(key)));
    if (!removedRefs.size) return false;
    await preserveSnapshotFileCopies(payload, previous, 'Adjunto retirado · copia recuperable', false, removedRefs);
    return true;
  }
  async function addRecoverySnapshotFile(target, snapshot, remoteRevision, conflicts, localFileMap) {
    const recoverable = clone(snapshot);
    for (const [fromKey, toKey] of localFileMap || []) remapFileReferences(recoverable, fromKey, toKey);
    const fingerprint = await payloadFingerprint({ snapshot: recoverable, remoteRevision, conflicts });
    const key = `f_recovery_${fingerprint.slice(0, 48)}`;
    const blob = new Blob([JSON.stringify(recoverable)], { type: 'application/json' });
    if (blob.size > 25 * 1024 * 1024) throw Object.assign(new Error('El snapshot de recuperación supera el límite privado de 25 MB; no se reemplazó el estado local.'), { retryable: false });
    const checksum = await fileChecksum(blob), existing = await localBlobForKey(key);
    if (existing && (existing.size !== blob.size || await fileChecksum(existing) !== checksum)) throw new Error('La clave determinista de recuperación ya contiene datos distintos; no se sobrescribió ninguna copia.');
    if (!existing) {
      await FS.put(key, blob);
      const saved = await localBlobForKey(key);
      if (!saved || saved.size !== blob.size || await fileChecksum(saved) !== checksum) { await FS.del(key).catch(() => {}); throw new Error('El snapshot recuperable no superó la verificación posterior a su escritura.'); }
    }
    await addArchiveFile(target, key, `estudiohub-recuperacion-r${remoteRevision}-${fingerprint.slice(0, 10)}.json`, 'Versión local desplazada por cloud-wins · recuperable');
    return true;
  }
  async function syncReferencedFiles(payload) {
    const refs = typeof window.collectFileRefs === 'function' ? [...window.collectFileRefs(payload)] : [];
    if (!refs.length) return;
    const remoteFiles = await listCloudFiles();
    for (const key of refs) {
      const remote = remoteFiles.get(key), blob = localFileGet ? await localFileGet(key) : await FS.get(key);
      if (!blob && remote) continue;
      if (!blob) throw new Error(`El archivo ${key} no está en este dispositivo ni en la nube; el estado no se confirmará hasta recuperarlo.`);
      if (remote) {
        const localChecksum = await fileChecksum(blob);
        if (remote.checksum === localChecksum) continue;
        await preserveSnapshotFileCopies(payload, { files: [{ key }] }, 'Copia local desplazada por nube · recuperable', false, new Set([key]));
        setState(payload); localSave(); refreshUI();
        setStatus('Conflicto de archivo resuelto · nube confirmada', user?.name || user?.email || 'Perfil Google');
        showLocalNotice(`La nube tenía una versión confirmada distinta de ${remote.fileName || key}. Se mantuvo activa la versión cloud y la copia local verificada quedó en Versiones recuperables.`);
        return syncReferencedFiles(getState());
      }
      if (blob.size > 25 * 1024 * 1024) throw new Error(`El archivo ${blob.name || key} supera el límite cloud de 25 MB. Quedó intacto en el dispositivo.`);
      const fileMeta = findFileMeta(payload, key); const name = fileMeta?.name || fileMeta?.fileName || blob.name || key;
      const response = await api(`/api/files/${encodeURIComponent(key)}`, { method: 'PUT', headers: { ...csrf, 'Content-Type': 'application/octet-stream', 'X-File-Name': encodeURIComponent(name), 'X-File-Type': blob.type || 'application/octet-stream' }, body: blob });
      if (response.status === 409) {
        await preserveSnapshotFileCopies(payload, { files: [{ key }] }, 'Copia local desplazada por nube · recuperable', false, new Set([key]));
        setState(payload); localSave(); refreshUI();
        return syncReferencedFiles(getState());
      }
      if (!response.ok) { const err = await response.json().catch(() => ({})); throw syncResponseError(response, err.error || `No se confirmó la subida de ${name}.`); }
      const uploaded = await response.json().catch(() => ({}));
      remoteFiles.set(key, { localKey: key, fileName: name, checksum: uploaded.checksum });
    }
  }

  async function flushSync(allowDuringProfileChange = false) {
    if (!user || !serverAuth || !navigator.onLine || conflictOpen || (profileChanging && !allowDuringProfileChange)) { if (pending && !navigator.onLine) setStatus('Sin conexión · cambios guardados localmente', user?.name || 'Perfil local'); return; }
    if (syncing) { scheduleSyncRetry(500); return; }
    const syncProfileId = String(user.id), syncGeneration = profileGeneration;
    const isCurrentProfile = () => syncProfileIsCurrent(syncProfileId, syncGeneration);
    syncing = true; lastSyncError = null; setStatus('Sincronizando…', user.name || user.email);
    try {
      let payload = getState();
      if (window.normalizeStudyKitState?.(payload)) localSave();
      if (!payload || !Array.isArray(payload.subjects)) throw Object.assign(new Error('El estado local no pasó la validación; se conservó sin enviar.'), { retryable: false });
      const archivedRemovedFiles = await archiveRemovedCloudFiles(payload, baseSnapshot);
      if (!isCurrentProfile()) return;
      if (archivedRemovedFiles) { setState(payload); localSave(); refreshUI(); payload = getState(); }
      await syncReferencedFiles(payload);
      if (!isCurrentProfile()) return;
      const operation = await getPendingOperation(payload, syncProfileId);
      if (!isCurrentProfile()) return;
      const startedAt = performance.now();
      const response = await api('/api/study/state', { method: 'PUT', headers: { 'Content-Type': 'application/json', ...csrf }, body: JSON.stringify({ baseRevision: revision, operationId: operation.id, payload }) });
      if (!isCurrentProfile()) return;
      if (response.status === 409) {
        const data = await response.json(); noteServerTime(data, startedAt, performance.now());
        if (!isCurrentProfile()) return;
        const remote = data.current || { revision: 0, payload: null };
        if (!remote.payload || !baseSnapshot) { await showConflictChoice(payload, remote, ['/perfil completo'], remote.payload ? remote.payload : payload); return; }
        const merged = merge3(baseSnapshot, payload, remote.payload);
        if (merged.conflicts.length) { await showConflictChoice(payload, remote, merged.conflicts, merged.value); return; }
        await preserveSnapshotFileCopies(merged.value, payload, 'Copia local recuperable', false);
        await preserveSnapshotFileCopies(merged.value, remote.payload, 'Copia cloud recuperable', false);
        await saveBase(remote.payload, remote.revision); clearSyncRetry(true); setState(merged.value); localSave();
        if (equal(merged.value, remote.payload)) { await clearPendingOperation(); pending = false; }
        else { pending = true; retrySoon = true; }
        return;
      }
      const result = await response.json().catch(() => ({}));
      if (!isCurrentProfile()) return;
      noteServerTime(result, startedAt, performance.now());
      if (!response.ok || result.confirmed !== true) {
        const error = syncResponseError(response, result.error || 'El servidor no confirmó la sincronización.', result);
        if (response.ok) error.status = 503;
        throw error;
      }
      if (result.idempotent && result.current && result.current.revision > result.revision) {
        const latest = result.current;
        if (!baseSnapshot || !latest.payload) { await showConflictChoice(payload, latest, ['/perfil completo'], latest.payload ? latest.payload : payload); return; }
        const merged = merge3(baseSnapshot, payload, latest.payload);
        if (merged.conflicts.length) { await showConflictChoice(payload, latest, merged.conflicts, merged.value); return; }
        await preserveSnapshotFileCopies(merged.value, payload, 'Copia local recuperable', false);
        await preserveSnapshotFileCopies(merged.value, latest.payload, 'Copia cloud recuperable', false);
        await saveBase(latest.payload, latest.revision, syncProfileId); if (!isCurrentProfile()) return; clearSyncRetry(true); setState(merged.value); localSave(); await clearPendingOperation(syncProfileId); if (!isCurrentProfile()) return;
        pending = !equal(merged.value, latest.payload); if (pending) retrySoon = true;
        else setStatus('Sincronizado · nube confirmada', user.name || user.email);
        return;
      }
      await saveBase(payload, result.revision, syncProfileId); if (!isCurrentProfile()) return; clearSyncRetry(true); await clearPendingOperation(syncProfileId); if (!isCurrentProfile()) return;
      pending = !equal(getState(), payload);
      if (pending) { setStatus('Cambios nuevos pendientes', user.name || user.email); retrySoon = true; }
      else setStatus('Sincronizado · nube confirmada', user.name || user.email);
    } catch (error) {
      if (!isCurrentProfile()) return;
      if (handleExpiredCloudSession(error)) return;
      if (await discardRejectedStudyKit(error)) { lastSyncError = null; return; }
      lastSyncError = error; pending = true; setStatus(navigator.onLine ? 'Pendiente · no confirmado' : 'Sin conexión · guardado local', user?.name || 'Perfil local');
      showLocalNotice(error.message || 'No se pudo sincronizar; los datos siguen en este dispositivo.');
      if (isRetryableSyncError(error)) scheduleSyncRetry(Number(error?.retryAfterMs) || 0);
    } finally {
      const shouldRetry = retrySoon; retrySoon = false;
      syncing = false; announceSyncState(); resolveSyncIdleWaiters();
      if (shouldRetry && !profileChanging) scheduleSyncRetry(250);
    }
  }
  function queueSync() {
    if (!serverAuth || applyingRemote || profileChanging) return;
    pending = true; lastSyncError = null; setStatus(navigator.onLine ? 'Pendiente de sincronizar' : 'Sin conexión · guardado local', user?.name || 'Perfil local');
    clearSyncRetry();
    clearTimeout(flushTimer); flushTimer = setTimeout(() => { void flushSync(); }, 800);
  }
  if (typeof originalSave === 'function') window.saveAppData = function (...args) { const result = originalSave.apply(this, args); queueSync(); return result; };
  window.addEventListener('online', () => { clearSyncRetry(true); if (serverAuth) { pending = true; void flushSync(); startCloudFileSync(); } else if (user) { location.reload(); } else void loadGoogleConfig(); });
  window.addEventListener('offline', () => { clearSyncRetry(); if (user) setStatus('Sin conexión · cambios locales', serverAuth ? user.name || user.email : `Perfil local: ${user.name || user.email}`); });

  async function refreshCloudState() {
    if (!serverAuth || !user || profileChanging || profileLoading) return;
    const profileId = String(user.id), generation = profileGeneration;
    const isCurrent = () => serverAuth && !profileChanging && !profileLoading && syncProfileIsCurrent(profileId, generation);
    try {
      const startedAt = performance.now();
      const response = await api('/api/study/state'); if (!isCurrent()) return;
      if (response.status === 401) {
        const data = await response.json().catch(() => ({})); if (!isCurrent()) return;
        handleExpiredCloudSession(syncResponseError(response, data.error || 'La sesión de Google venció.', data)); return;
      }
      if (!response.ok) return;
      const remote = await response.json(); if (!isCurrent()) return; noteServerTime(remote, startedAt, performance.now()); if (remote.revision <= revision) return;
      const local = getState();
      if (!baseSnapshot) { await showConflictChoice(local, remote, ['/perfil completo'], remote.payload, isCurrent); return; }
      const merged = merge3(baseSnapshot, local, remote.payload);
      if (merged.conflicts.length) { await showConflictChoice(local, remote, merged.conflicts, merged.value, isCurrent); return; }
      await saveBase(remote.payload, remote.revision, profileId); if (!isCurrent()) return; setState(merged.value); localSave();
      if (equal(merged.value, remote.payload)) { pending = false; setStatus('Sincronizado · nube confirmada', user.name || user.email); }
      else { pending = true; await flushSync(); }
    } catch { /* una verificación fallida no sustituye datos */ }
  }
  function openEventStream() {
    if (!serverAuth || !('ReadableStream' in window)) return;
    eventStream?.abort(); const controller = new AbortController(); eventStream = controller;
    const connect = async () => {
      while (serverAuth && !profileChanging && !profileLoading && !controller.signal.aborted) {
        try {
          const response = await api(`/api/study/events?since=${revision}`, { headers: { Accept: 'text/event-stream' }, signal: controller.signal });
          if (controller.signal.aborted || profileChanging || profileLoading) return;
          if (response.status === 401) {
            const data = await response.json().catch(() => ({}));
            if (!controller.signal.aborted && !profileChanging && !profileLoading) handleExpiredCloudSession(syncResponseError(response, data.error || 'La sesión de Google venció.', data));
            return;
          }
          if (!response.ok || !response.body) throw new Error('No se pudo abrir la sincronización en tiempo real.');
          if (remotePoll) { clearInterval(remotePoll); remotePoll = null; }
          const reader = response.body.getReader(), decoder = new TextDecoder(); let buffer = '';
          while (!controller.signal.aborted) {
            const { value, done } = await reader.read(); if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const blocks = buffer.split(/\r?\n\r?\n/); buffer = blocks.pop() || '';
            for (const block of blocks) if (!profileChanging && !profileLoading && block.split(/\r?\n/).some(line => line === 'event: revision')) void refreshCloudState();
          }
        } catch { if (controller.signal.aborted) return; }
        if (!serverAuth || controller.signal.aborted) return;
        if (!remotePoll) remotePoll = setInterval(() => { if (document.visibilityState !== 'hidden') void refreshCloudState(); }, 15000);
        await new Promise(resolve => setTimeout(resolve, 4000));
      }
    };
    void connect();
  }
  function startCloudFileSync() { if (serverAuth && pending) void flushSync(); }

  if (FS?.get && FS?.put) {
    const localGet = FS.get.bind(FS);
    localFileGet = localGet;
    FS.get = async function (key) {
      const profileId = String(user?.id || ''), generation = profileGeneration, wasServerAuth = serverAuth;
      const isSameProfile = () => syncProfileIsCurrent(profileId, generation);
      const local = await localGet(key);
      if (!isSameProfile()) return null;
      if (!wasServerAuth || !serverAuth || !navigator.onLine) return local;
      try {
        const path = `/api/files/${encodeURIComponent(key)}`;
        const head = await api(path, { method: 'HEAD' });
        if (!isSameProfile() || !serverAuth) return null;
        if (head.status === 404) return local;
        if (!head.ok) throw new Error('No se pudo verificar la copia cloud del archivo.');
        const xChecksum = normalizeCloudChecksum(head.headers.get('X-Content-Checksum'));
        const etagChecksum = normalizeCloudChecksum(head.headers.get('ETag'));
        const remoteChecksum = isCloudSha256(xChecksum) ? xChecksum : isCloudSha256(etagChecksum) ? etagChecksum : '';
        if (!remoteChecksum) throw new Error('La nube no devolvió un checksum SHA-256 verificable.');
        if (local && await fileChecksum(local) === remoteChecksum) return isSameProfile() ? local : null;
        const blob = await downloadVerifiedCloudBlob(path, remoteChecksum, key, [xChecksum, etagChecksum]);
        if (!isSameProfile() || !serverAuth) return null;
        if (!local) await FS.put(key, blob);
        else showLocalNotice('Este archivo tiene una copia local distinta. Se mostró la copia verificada de la nube sin reemplazar ni borrar la versión local.');
        return blob;
      } catch (error) {
        if (!isSameProfile()) return null;
        if (local) { showLocalNotice(error.message || 'No se pudo verificar el archivo; se conserva la copia local.'); return local; }
        return null;
      }
    };
  }

  async function loadGoogleConfig() {
    if (!navigator.onLine) return;
    try {
      const response = await api('/api/auth/config', { signal: AbortSignal.timeout(8000) });
      if (!response.ok) throw new Error('No se pudo leer la configuración Google.');
      clientId = (await response.json()).googleClientId || '';
      const host = $('googleButtonHost'); if (!host) return;
      if (!clientId) { host.innerHTML = '<button type="button" onclick="StudyHubCloud.showSetupHelp()">Configurar Google</button>'; setProfileError('El cliente web de Google aún no está configurado.'); return; }
      await loadGoogleScript();
      const nonceResponse = await api('/api/auth/nonce', { signal: AbortSignal.timeout(10000) });
      const nonceData = await nonceResponse.json(); if (!nonceResponse.ok || !nonceData.nonce) throw new Error(nonceData.error || 'Google aún no está listo.');
      authNonce = nonceData.nonce;
      window.google.accounts.id.initialize({ client_id: clientId, nonce: authNonce, callback: result => { if (result.credential) void signInWithGoogle(result.credential); }, context: 'signin', ux_mode: 'popup' });
      setProfileError(''); host.replaceChildren(); window.google.accounts.id.renderButton(host, { type: 'standard', theme: document.documentElement.classList.contains('dark') ? 'filled_blue' : 'outline', size: 'medium', shape: 'pill', text: 'signin_with', locale: 'es' });
    } catch (error) { const host = $('googleButtonHost'); if (host) host.innerHTML = '<button type="button" onclick="StudyHubCloud.showSetupHelp()">Conectar Google</button>'; const message = error.message || 'Google no está disponible.'; setProfileError(message); showLocalNotice(message); }
  }
  function loadGoogleScript() {
    if (window.google?.accounts?.id) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const existing = document.querySelector('script[data-google-identity]');
      if (existing) { existing.addEventListener('load', resolve, { once: true }); existing.addEventListener('error', () => reject(new Error('No se pudo cargar Google Identity Services.')), { once: true }); return; }
      const script = document.createElement('script'); script.src = 'https://accounts.google.com/gsi/client'; script.async = true; script.defer = true; script.dataset.googleIdentity = '1'; script.onload = resolve; script.onerror = () => reject(new Error('No se pudo cargar Google Identity Services.')); document.head.append(script);
    });
  }
  async function signInWithGoogle(credential) {
    if (!credential) { setProfileError('Google no devolvió un comprobante de acceso. Vuelve a pulsar el botón.'); return; }
    if (!authNonce) { setProfileError('El código temporal venció. Vuelve a iniciar sesión desde Perfil.'); if (navigator.onLine) void loadGoogleConfig(); return; }
    if (profileChanging || profileLoading) { setProfileError('El perfil aún está cambiando. Espera un momento e inténtalo de nuevo.'); return; }
    if (syncing && !(await waitForSyncIdle())) { setProfileError('La sincronización sigue activa; no se cambió de perfil y tus datos permanecen guardados.'); return; }
    if (serverAuth && user) { setProfileError('Cierra primero la sesión del perfil actual para evitar mezclar cuentas. La sesión se conservará y sincronizará antes del cierre.'); return; }
    clearTimeout(flushTimer); flushTimer = null; clearSyncRetry();
    beginProfileTransition(); profileGeneration += 1;
    let transitionStarted = true;
    try {
      const response = await api('/api/auth/google', { method: 'POST', headers: { 'Content-Type': 'application/json', ...csrf }, body: JSON.stringify({ credential, nonce: authNonce }), signal: AbortSignal.timeout(20000) });
      const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Google rechazó el inicio de sesión.');
      authNonce = ''; setProfileError('');
      const before = getState();
      await loadAccountProfile(data.user, before, true);
      transitionStarted = false;
    } catch (error) { profileLoading = false; if (transitionStarted) { profileChanging = false; announceSyncState(); if (pending) scheduleSyncRetry(250); } authNonce = ''; setStatus('No se inició sesión', 'Perfil local'); const message = error.message || 'No se pudo iniciar sesión.'; setProfileError(message); showLocalNotice(message); if (navigator.onLine) setTimeout(() => { void loadGoogleConfig(); }, 250); }
  }

  function reveal() { document.documentElement.classList.remove('hub-booting'); }
  async function listRecoveryRecords(profileId) {
    const db = await metaOpen();
    const keys = await new Promise((resolve, reject) => {
      const request = db.transaction(META_STORE, 'readonly').objectStore(META_STORE).getAllKeys();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error || new Error('No se pudieron leer las copias recuperables.'));
    });
    const prefix = `${metaPrefix(profileId)}recovery:`;
    const records = await Promise.all(keys.filter(key => typeof key === 'string' && key.startsWith(prefix)).map(key => metaGet(key)));
    return records.filter(record => record?.snapshot && Array.isArray(record.snapshot.subjects))
      .sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || '')));
  }
  async function downloadLatestRecovery() {
    if (!user) return;
    try {
      const records = await listRecoveryRecords(user.id), record = records[records.length - 1];
      if (!record) { showLocalNotice('No hay copias recuperables guardadas para este perfil.'); return; }
      const date = new Date(record.createdAt || Date.now()), stamp = date.toISOString().replace(/[:.]/g, '-');
      const blob = new Blob([JSON.stringify(record.snapshot)], { type: 'application/json' });
      const url = URL.createObjectURL(blob), link = document.createElement('a');
      link.href = url; link.download = `estudiohub-recuperacion-${stamp}.json`; document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showLocalNotice('Se descargó la instantánea de recuperación en JSON. Las copias de archivos adjuntos se descargan por separado desde «Versiones recuperables».');
    } catch (error) { showLocalNotice(error.message || 'No se pudo descargar la recuperación local.'); }
  }
  async function refreshRecoveryButton() {
    const button = $('studyhubRecoveryExport');
    if (!button) return;
    if (!user) { button.hidden = true; button.textContent = 'Descargar recuperación'; return; }
    try {
      const count = (await listRecoveryRecords(user.id)).length;
      button.textContent = `Descargar recuperación (${count})`;
      button.title = 'Descarga el estado recuperable más reciente como JSON; los adjuntos se descargan desde Versiones recuperables.';
      button.hidden = count === 0;
    } catch { button.hidden = true; }
  }
  function safeArchiveDownloadName(value) {
    return String(value || 'archivo-recuperable').replace(/[\\/\u0000-\u001f\u007f]/g, '_').trim().slice(0, 180) || 'archivo-recuperable';
  }
  async function downloadArchivedFile(item) {
    if (item?.checksumAlgorithm !== 'sha256' || !/^[a-f0-9]{64}$/i.test(String(item?.checksum || '')) || !Number.isSafeInteger(item?.size) || item.size < 0) {
      throw new Error(`La copia recuperable ${item?.fileName || item?.key} no tiene un checksum verificable. No se descargó para evitar presentar una copia posiblemente alterada.`);
    }
    let blob = await localBlobForKey(item.key);
    const matchesArchive = async value => !!value && value.size === item.size && await fileChecksum(value) === item.checksum;
    if (!(await matchesArchive(blob)) && serverAuth && navigator.onLine) {
      const remoteFiles = await listCloudFiles(), remote = remoteFiles.get(item.key);
      if (remote?.checksum === item.checksum) {
        const cloudBlob = await downloadCloudFile(item.key, remote);
        if (await matchesArchive(cloudBlob)) {
          if (!blob) {
            await FS.put(item.key, cloudBlob);
            const saved = await localBlobForKey(item.key);
            if (!(await matchesArchive(saved))) throw new Error('La copia recuperable descargada no superó la verificación local posterior.');
          }
          blob = cloudBlob;
        }
      }
    }
    if (!(await matchesArchive(blob))) throw new Error(`La copia recuperable ${item.fileName || item.key} falta o no coincide con su SHA-256/tamaño registrados; las copias existentes se dejaron intactas.`);
    blob = blob.slice(0, blob.size, item.mimeType || blob.type || 'application/octet-stream');
    const url = URL.createObjectURL(blob), link = document.createElement('a');
    link.href = url; link.download = safeArchiveDownloadName(item.fileName || item.key); document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }
  function reviewFileArchives() {
    const archives = Array.isArray(getState()?.studyhubFileArchives) ? getState().studyhubFileArchives.filter(item => item && typeof item.key === 'string') : [];
    if (!archives.length) { showLocalNotice('No hay versiones de archivos recuperables en este perfil.'); return; }
    const rows = archives.map((item, index) => { const verified = item.checksumAlgorithm === 'sha256' && /^[a-f0-9]{64}$/i.test(String(item.checksum || '')) && Number.isSafeInteger(item.size) && item.size >= 0; return `<li><div><b>${escapeHtml(item.title || item.fileName || item.key)}</b><br><small>${escapeHtml(item.createdAt || '')}${verified ? ' · SHA-256 verificado' : ' · sin checksum verificable'}</small></div><button type="button" data-archive-download="${index}" ${verified ? '' : 'disabled title="Esta versión antigua no registra un checksum verificable."'}>Descargar copia</button></li>`; }).join('');
    const overlay = appOverlay('Versiones recuperables', `<p>Las copias retiradas o divergentes se conservan asociadas a este perfil; no se eliminan automáticamente. Descarga la versión que necesitas y guárdala en un lugar seguro.</p><ul class="hub-conflict-list hub-archive-list">${rows}</ul>`, [{ label: 'Cerrar', primary: true, run: () => {} }]);
    overlay.querySelectorAll('[data-archive-download]').forEach(button => { button.onclick = async () => { button.disabled = true; try { await downloadArchivedFile(archives[Number(button.dataset.archiveDownload)]); } catch (error) { showLocalNotice(error.message || 'No se pudo descargar la versión recuperable.'); } finally { button.disabled = false; } }; });
  }
  function refreshProfileToolState() {
    const syncButton = $('studyhubSyncNow');
    if (syncButton) {
      syncButton.hidden = !user;
      syncButton.disabled = !serverAuth || !navigator.onLine || syncing;
      syncButton.textContent = pending ? 'Reintentar sincronización' : 'Sincronizar ahora';
    }
    const archives = getState()?.studyhubFileArchives;
    const archiveButton = $('studyhubFileArchiveButton');
    if (archiveButton) {
      const count = Array.isArray(archives) ? archives.length : 0;
      archiveButton.hidden = count === 0;
      archiveButton.disabled = count === 0;
      archiveButton.textContent = `Versiones recuperables (${count})`;
    }
    const toolsHint = $('studyhubSyncToolsHint'); if (toolsHint) toolsHint.hidden = !!user;
    const tools = $('studyhubSyncTools'); if (tools && pending) tools.open = true;
  }
  function refreshUI() {
    const profile = $('studyhubProfileStatus'); if (profile) profile.textContent = user ? `${serverAuth ? '' : 'Local · '}${user.name || user.email || 'Estudiante'}` : 'Perfil local';
    refreshProfileToolState();
    if (serverAuth && user) { setStatus(pending ? 'Pendiente de sincronizar' : 'Sincronizado · nube confirmada', user.name || user.email); }
    void refreshRecoveryButton();
    try { window.renderSubjects?.(); window.renderSubjectPanel?.(); window.renderInicio?.(); } catch { /* la pestaña actual se renderizará al cambiar */ }
    try {
      const backgroundRefresh = window.applyBg?.();
      if (backgroundRefresh && typeof backgroundRefresh.then === 'function') {
        void backgroundRefresh.then(() => window.renderBgGallery?.()).catch(error => console.warn('No se pudo recargar el fondo del perfil.', error));
      } else {
        window.renderBgGallery?.();
      }
    } catch (error) { console.warn('No se pudo recargar el fondo del perfil.', error); }
    refreshProfileTrigger(); renderProfilePanel();
    window.dispatchEvent(new CustomEvent('studyhub-auth-state', { detail: { signedIn: serverAuth, user } }));
  }

  const GEMINI_FAB_POSITION_KEY = 'estudiohub_gemini_fab_position_v1';
  function positionGeminiPanel() {
    const panel = $('studyhubGeminiPanel'), fab = $('studyhubGeminiFab');
    if (!panel || !fab || !panel.classList.contains('open')) return;
    const previousVisibility = panel.style.visibility;
    panel.style.visibility = 'hidden';
    const box = panel.getBoundingClientRect(), anchor = fab.getBoundingClientRect();
    const width = box.width || Math.min(410, window.innerWidth - 28);
    const height = box.height || Math.min(420, window.innerHeight * .72);
    const maxLeft = Math.max(8, window.innerWidth - width - 8);
    const maxTop = Math.max(8, window.innerHeight - height - 8);
    const left = Math.min(maxLeft, Math.max(8, anchor.right - width));
    let top = anchor.top - height - 12;
    if (top < 8) top = anchor.bottom + 12;
    top = Math.min(maxTop, Math.max(8, top));
    panel.style.left = `${Math.round(left)}px`;
    panel.style.top = `${Math.round(top)}px`;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    panel.style.visibility = previousVisibility;
  }
  function setGeminiFabPosition(fab, left, top, persist = false) {
    const box = fab.getBoundingClientRect();
    const maxLeft = Math.max(8, window.innerWidth - box.width - 8);
    const maxTop = Math.max(8, window.innerHeight - box.height - 8);
    const x = Math.round(Math.min(maxLeft, Math.max(8, left)));
    const y = Math.round(Math.min(maxTop, Math.max(8, top)));
    fab.style.left = `${x}px`; fab.style.top = `${y}px`; fab.style.right = 'auto'; fab.style.bottom = 'auto';
    fab.dataset.positioned = 'true';
    if (persist) { try { localStorage.setItem(GEMINI_FAB_POSITION_KEY, JSON.stringify({ left: x, top: y })); } catch { /* la posición aún funciona en esta sesión */ } }
    if ($('studyhubGeminiPanel')?.classList.contains('open')) requestAnimationFrame(positionGeminiPanel);
  }
  function resetGeminiFabPosition(fab) {
    try { localStorage.removeItem(GEMINI_FAB_POSITION_KEY); } catch { /* preferencia local opcional */ }
    fab.style.removeProperty('left'); fab.style.removeProperty('top'); fab.style.removeProperty('right'); fab.style.removeProperty('bottom');
    delete fab.dataset.positioned;
    if ($('studyhubGeminiPanel')?.classList.contains('open')) requestAnimationFrame(positionGeminiPanel);
  }
  function restoreGeminiFabPosition(fab) {
    try {
      const saved = JSON.parse(localStorage.getItem(GEMINI_FAB_POSITION_KEY) || 'null');
      if (Number.isFinite(saved?.left) && Number.isFinite(saved?.top)) requestAnimationFrame(() => setGeminiFabPosition(fab, saved.left, saved.top));
    } catch { /* posición predeterminada */ }
  }
  function installGeminiFabControls(fab) {
    fab.title = 'Abrir asistente · arrastra para mover · flechas para ajustar · Inicio para restablecer';
    fab.setAttribute('aria-label', 'Asistente Gemini: activar para abrir o cerrar; arrastrar para mover; usa las flechas para ajustar y Inicio para restablecer');
    fab.setAttribute('aria-keyshortcuts', 'ArrowUp ArrowDown ArrowLeft ArrowRight Home');
    fab.setAttribute('aria-expanded', 'false');
    restoreGeminiFabPosition(fab);
    let drag = null, suppressClick = false;
    fab.addEventListener('pointerdown', event => {
      if (event.button !== 0 || drag) return;
      const box = fab.getBoundingClientRect();
      drag = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, left: box.left, top: box.top, moved: false };
      try { fab.setPointerCapture(event.pointerId); } catch { /* algunos navegadores de prueba no capturan eventos sintéticos */ }
    });
    fab.addEventListener('pointermove', event => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const dx = event.clientX - drag.startX, dy = event.clientY - drag.startY;
      if (!drag.moved && Math.hypot(dx, dy) < 6) return;
      drag.moved = true; event.preventDefault(); fab.classList.add('is-dragging');
      setGeminiFabPosition(fab, drag.left + dx, drag.top + dy);
    });
    const finishDrag = event => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const finished = drag; drag = null; fab.classList.remove('is-dragging');
      try { if (fab.hasPointerCapture(event.pointerId)) fab.releasePointerCapture(event.pointerId); } catch { /* ya liberado por el navegador */ }
      if (finished.moved) {
        setGeminiFabPosition(fab, finished.left + event.clientX - finished.startX, finished.top + event.clientY - finished.startY, true);
        suppressClick = true; setTimeout(() => { suppressClick = false; }, 500);
      }
    };
    fab.addEventListener('pointerup', finishDrag);
    fab.addEventListener('pointercancel', finishDrag);
    fab.addEventListener('click', event => {
      if (suppressClick) { suppressClick = false; event.preventDefault(); event.stopImmediatePropagation(); return; }
      window.StudyHubCloud?.openGemini?.();
    });
    fab.addEventListener('keydown', event => {
      if (event.key === 'Home') { event.preventDefault(); resetGeminiFabPosition(fab); return; }
      const delta = { ArrowUp: [0, -18], ArrowDown: [0, 18], ArrowLeft: [-18, 0], ArrowRight: [18, 0] }[event.key];
      if (!delta) return;
      event.preventDefault(); const box = fab.getBoundingClientRect();
      const step = event.shiftKey ? 40 : 18;
      setGeminiFabPosition(fab, box.left + Math.sign(delta[0]) * step, box.top + Math.sign(delta[1]) * step, true);
    });
    window.addEventListener('resize', () => {
      if (fab.dataset.positioned === 'true') { const box = fab.getBoundingClientRect(); setGeminiFabPosition(fab, box.left, box.top, true); }
      else positionGeminiPanel();
    });
  }

  function createChatUI() {
    if ($('studyhubGeminiFab')) return;
    const fab = document.createElement('button'); fab.id = 'studyhubGeminiFab'; fab.type = 'button'; fab.innerHTML = '<i class="fa-solid fa-sparkles"></i>';
    const panel = document.createElement('section'); panel.id = 'studyhubGeminiPanel'; panel.setAttribute('aria-label', 'Asistente académico Gemini');
    panel.innerHTML = `<div class="hub-chat-head"><span><i class="fa-solid fa-sparkles text-sky-600 mr-1"></i>Asistente EstudioHUB</span><button type="button" aria-label="Cerrar" style="background:none;border:0;font-size:20px" id="studyhubGeminiClose">×</button></div><div id="studyhubGeminiContext">Elige un PDF/archivo, selecciona texto o pregunta sobre la pestaña actual.</div><label class="hub-chat-page-toggle"><input id="studyhubGeminiIncludePage" type="checkbox" checked><span>Incluir texto visible de esta pestaña (sin datos del perfil)</span></label><p class="hub-chat-privacy">Al enviar, la pregunta y el contexto seleccionado se procesan con Google Gemini.</p><div id="studyhubGeminiMessages"></div><form id="studyhubGeminiForm"><textarea id="studyhubGeminiQuestion" placeholder="Pregunta sobre el material o la asignatura…" required></textarea><button type="submit">Enviar</button></form>`;
    document.body.append(fab, panel); installGeminiFabControls(fab); $('studyhubGeminiClose').onclick = () => { panel.classList.remove('open'); fab.setAttribute('aria-expanded', 'false'); }; $('studyhubGeminiForm').onsubmit = sendGemini;
  }
  function activeMaterialText() {
    const selected = window.getSelection?.()?.toString().trim(); if (selected && selected.length >= 40) return selected.slice(0, 80000);
    if (currentMaterial?.key && FS?.get) return null;
    const extracted = $('trainingExtracted')?.value?.trim(); if (extracted) return extracted.slice(0, 80000);
    try { const c = window.curClass?.(window.curSubject?.()); if (c) return [`Apuntes: ${c.notes || ''}`, `Ideas clave: ${c.key || ''}`, c.trainingText || ''].filter(Boolean).join('\n\n').slice(0, 80000); } catch { }
    return '';
  }
  async function getAssistantContext() {
    if (currentMaterial?.key && FS?.get) {
      try {
        const blob = await FS.get(currentMaterial.key), ext = (currentMaterial.name.split('.').pop() || '').toLowerCase();
        if (!blob) return { text: '', label: `${currentMaterial.name} (archivo no disponible sin conexión)` };
        if (ext === 'pdf' && window.StudyHubExtract?.pdf) return { text: await window.StudyHubExtract.pdf(blob), label: currentMaterial.name };
        if (ext === 'docx' && window.StudyHubExtract?.docx) return { text: await window.StudyHubExtract.docx(blob), label: currentMaterial.name };
        if (['xlsx', 'xlsm'].includes(ext) && window.StudyHubExtract?.xlsx) return { text: await window.StudyHubExtract.xlsx(blob), label: currentMaterial.name };
        if (['txt', 'md', 'csv', 'tsv', 'json', 'xml'].includes(ext)) return { text: await blob.text(), label: currentMaterial.name };
      } catch (error) { return { text: '', label: `${currentMaterial.name}: ${error.message}` }; }
    }
    return { text: activeMaterialText() || '', label: currentMaterial?.name || (activeMaterialText() ? 'Material de clase' : 'Sin material seleccionado') };
  }
  function getVisiblePageText() {
    const main = document.querySelector('main');
    if (!main) return '';
    return String(main.innerText || '').replace(/\n{3,}/g, '\n\n').trim().slice(0, 22000);
  }
  function addChatMessage(value, role) { const area = $('studyhubGeminiMessages'); if (!area) return; const node = document.createElement('div'); node.className = `hub-msg ${role}`; node.textContent = value; area.append(node); area.scrollTop = area.scrollHeight; }
  async function sendGemini(event) {
    event.preventDefault(); const requestGeneration = profileGeneration, input = $('studyhubGeminiQuestion'), question = input?.value?.trim(); if (!question) return;
    if (profileChanging || profileLoading) { addChatMessage('El perfil está cambiando; vuelve a enviar la pregunta cuando la nube confirme.', 'assistant'); return; }
    if (!serverAuth || !navigator.onLine) { addChatMessage('Para enviar preguntas a Gemini necesitas conexión a Internet e iniciar sesión con Google.', 'assistant'); return; }
    const submit = $('studyhubGeminiForm')?.querySelector('button[type="submit"],button'); if (submit) submit.disabled = true;
    try {
      const material = await getAssistantContext();
      if (!isActiveProfileGeneration(requestGeneration)) return;
      const pageText = $('studyhubGeminiIncludePage')?.checked ? getVisiblePageText() : '';
      const sources = [];
      if (material.text && material.text.trim().length >= 40) sources.push(`MATERIAL SELECCIONADO · ${material.label || 'Documento'}\n${material.text}`);
      if (pageText.length >= 40) sources.push(`CONTENIDO VISIBLE DE LA PESTAÑA ACTIVA\n${pageText}`);
      const contextText = sources.join('\n\n--- CONTEXTO ---\n\n').slice(0, 80000);
      const contextHash = await payloadFingerprint(contextText || 'consulta-general');
      if (!isActiveProfileGeneration(requestGeneration)) return;
      if (activeChatContextHash !== contextHash) { activeChatContextHash = contextHash; chat.length = 0; $('studyhubGeminiMessages')?.replaceChildren(); }
      const label = $('studyhubGeminiContext'); if (label) label.textContent = contextText ? `Contexto enviado: ${sources.map((_, index) => index === 0 && material.text?.trim().length >= 40 ? material.label || 'Documento' : 'pestaña activa').join(' + ')}` : 'Sin material adjunto · Gemini responderá como consulta general.';
      const history = chat.slice(-8); input.value = '';
      const data = await requestStudyAI('/api/gemini/chat', { question, context: contextText, history }, 95000);
      if (!isActiveProfileGeneration(requestGeneration)) return;
      chat.push({ role: 'user', text: question }, { role: 'model', text: data.text }); addChatMessage(question, 'user'); addChatMessage(data.text, 'assistant');
    } catch (error) { if (error?.profileChanged || !isActiveProfileGeneration(requestGeneration)) return; input.value = question; addChatMessage(`No se envió la respuesta: ${error.message || 'fallo de conexión'}. La pregunta quedó en el campo para reintentar.`, 'assistant'); }
    finally { if (submit) submit.disabled = false; input?.focus(); }
  }
  const oldOpenViewer = window.openViewer;
  if (typeof oldOpenViewer === 'function') window.openViewer = function (key, name, type) { currentMaterial = { key, name: String(name || 'material'), type: String(type || '') }; const context = $('studyhubGeminiContext'); if (context) context.textContent = `Contexto: ${currentMaterial.name} · extracción local al preguntar`; return oldOpenViewer.apply(this, arguments); };

  async function logout() {
    if (profileChanging || profileLoading) { showLocalNotice('No se cambió el perfil: espera a que termine la transición actual.'); return false; }
    if (user && !navigator.onLine) { showLocalNotice('Para revocar la sesión Google y cerrar el perfil cloud necesitas volver a conectarte.'); return false; }
    beginProfileTransition();
    if (serverAuth) pending = true;
    if (syncing) {
      showLocalNotice('Terminando la sincronización actual antes de cambiar de perfil.');
      if (!(await waitForSyncIdle())) { profileChanging = false; announceSyncState(); if (pending) scheduleSyncRetry(250); restoreProfileStreams(); showLocalNotice('No se cerró la sesión porque la sincronización sigue activa. Tus datos permanecen guardados; puedes reintentar el cambio de perfil.'); return false; }
    }
    if (pending && serverAuth && navigator.onLine && !conflictOpen) {
      await flushSync(true);
      if (pending) { profileChanging = false; announceSyncState(); if (pending) scheduleSyncRetry(250); restoreProfileStreams(); showLocalNotice(lastSyncError?.message || 'No se cerró la sesión porque el último guardado no quedó confirmado. La sesión pausada sigue guardada localmente; reintenta la sincronización antes de cambiar de perfil.'); return false; }
    }
    if (serverAuth && (pending || conflictOpen)) { profileChanging = false; announceSyncState(); if (pending) scheduleSyncRetry(250); restoreProfileStreams(); showLocalNotice('No se cerró la sesión porque hay cambios pendientes o un conflicto. Resuélvelos y vuelve a intentarlo; no se descartó ningún dato.'); return false; }
    try { if (navigator.onLine && (serverAuth || user)) { const response = await api('/api/auth/logout', { method: 'POST', headers: csrf, body: '{}' }); if (!response.ok && response.status !== 401) throw new Error('El servidor no confirmó el cierre de sesión.'); } }
    catch (error) { profileChanging = false; announceSyncState(); if (pending) scheduleSyncRetry(250); restoreProfileStreams(); showLocalNotice(error.message || 'No se pudo cerrar la sesión cloud.'); return false; }
    eventStream?.abort(); if (remotePoll) clearInterval(remotePoll); eventStream = null; remotePoll = null; clearTimeout(flushTimer); clearSyncRetry(true);
    authNonce = ''; window.google?.accounts?.id?.disableAutoSelect?.();
    profileGeneration += 1;
    localStorage.removeItem('estudiohub_last_profile'); user = null; serverAuth = false; pending = false; lastSyncError = null;
    window.setEstudioStorageNamespace(null); if (guestSnapshot) setState(guestSnapshot); else window.loadAppData(); localSave(); profileChanging = false; refreshUI(); setStatus('Solo en este dispositivo', 'Perfil local'); return true;
  }
  function isOnlineStudyReady() { return Boolean(serverAuth && user && navigator.onLine && !pending && !syncing && !conflictOpen && !profileChanging && !profileLoading); }
  async function requestStudyAI(path, payload, timeout = 120000) {
    if (profileChanging || profileLoading) throw new Error('El perfil está cambiando. Espera antes de enviar material a Gemini.');
    if (!serverAuth || !user) throw new Error('Inicia sesión con Google para usar Study Kit y Gemini.');
    if (!navigator.onLine) throw new Error('Esta función requiere conexión a Internet. Los materiales locales se conservaron.');
    const requestGeneration = profileGeneration;
    const staleProfileError = () => Object.assign(new Error('El perfil cambió durante la solicitud; se descartó la respuesta tardía.'), { profileChanged: true });
    const waitUntil = Date.now() + 45000;
    while (syncing && navigator.onLine && Date.now() < waitUntil) { await new Promise(resolve => setTimeout(resolve, 120)); if (!isActiveProfileGeneration(requestGeneration)) throw staleProfileError(); }
    if (syncing) throw new Error('La nube aún está confirmando otros cambios. Espera y vuelve a intentar.');
    if (pending && !(await syncNow())) { if (!isActiveProfileGeneration(requestGeneration)) throw staleProfileError(); throw new Error('No se pudo confirmar primero la sincronización cloud. Tus datos locales siguen guardados; vuelve a intentar cuando el estado indique «nube confirmada».'); }
    if (!isActiveProfileGeneration(requestGeneration)) throw staleProfileError();
    if (!isOnlineStudyReady()) throw new Error('Study Kit requiere el perfil Google y la nube confirmada antes de enviar material a Gemini.');
    if (typeof path !== 'string' || !path.startsWith('/api/')) throw new Error('Ruta de servicio no permitida.');
    const body = JSON.stringify(payload), requestTimeout = Math.max(10000, Math.min(180000, Number(timeout) || 120000));
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await api(path, { method: 'POST', headers: { 'Content-Type': 'application/json', ...csrf }, body, signal: AbortSignal.timeout(requestTimeout) });
        if (!isActiveProfileGeneration(requestGeneration)) throw staleProfileError();
        const data = await response.json().catch(() => ({}));
        if (!isActiveProfileGeneration(requestGeneration)) throw staleProfileError();
        if (response.ok && !data.error) return data;
        const error = syncResponseError(response, data.error || `El servicio respondió con estado ${response.status}.`, data);
        if (response.status === 401) handleExpiredCloudSession(error);
        const retryAfter = response.headers.get('Retry-After');
        const retrySeconds = Number(retryAfter);
        const retryDate = retryAfter && !Number.isFinite(retrySeconds) ? Date.parse(retryAfter) : NaN;
        error.retryAfterMs = Number.isFinite(retrySeconds) && retrySeconds > 0 ? Math.min(60_000, retrySeconds * 1000) : Number.isFinite(retryDate) ? Math.max(0, Math.min(60_000, retryDate - Date.now())) : 0;
        throw error;
      } catch (error) {
        if (error?.profileChanged) throw error;
        const status = Number(error?.status);
        const retryable = error?.name === 'TimeoutError' || error instanceof TypeError || !Number.isFinite(status) || [408, 425, 429].includes(status) || status >= 500;
        if (!retryable || attempt > 0) throw error;
        const backoff = Math.round(1000 * (0.85 + Math.random() * 0.3));
        const delay = Math.max(backoff, Number(error?.retryAfterMs) || 0);
        await new Promise(resolve => setTimeout(resolve, delay));
        if (!isOnlineStudyReady()) throw new Error('La conexión o la confirmación cloud cambió durante el reintento. Se conservó el material; vuelve a intentarlo cuando nube esté confirmada.');
      }
    }
    throw new Error('Gemini no devolvió una respuesta utilizable. Inténtalo de nuevo.');
  }
  async function syncNow() { if (!serverAuth || profileChanging || profileLoading) return false; pending = true; await flushSync(); return !pending; }
  function showSetupHelp() {
    const origin = location.origin;
    const message = !navigator.onLine ? 'La configuración requiere Internet. Puedes seguir usando el perfil local mientras tanto.' : 'Crea un cliente OAuth 2.0 de tipo Aplicación web en Google Cloud y agrega este origen autorizado de JavaScript. Google Identity Services usa ventana emergente; no necesita URI de redirección.';
    const steps = `<p>${escapeHtml(message)}</p><p><b>Origen de esta vista previa:</b> <code>${escapeHtml(origin)}</code></p><ol><li>Google Cloud → APIs y servicios → Credenciales → Crear credenciales → ID de cliente OAuth → Aplicación web.</li><li>Agrega el origen de arriba en <i>Orígenes autorizados de JavaScript</i>; completa la pantalla de consentimiento y añade tu cuenta como usuario de prueba si Google lo pide.</li><li>Guarda el <b>Client ID</b> que termina en <code>.apps.googleusercontent.com</code> como secreto de entorno <code>GOOGLE_CLIENT_ID</code>. No se requiere Client Secret para este flujo.</li><li>Obtén una clave Gemini desde <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a> y guárdala en <code>GEMINI_API_KEY</code> mediante la tarjeta protegida del proyecto.</li></ol><p>La clave Gemini permanece en el servidor; no la pegues en el HTML ni en el chat. Al publicar, añade también el origen final de producción en Google Cloud.</p><p><a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener">Abrir credenciales de Google Cloud</a></p>`;
    appOverlay('Conectar Google y Gemini', steps, [{ label: 'Entendido', primary: true, run: () => {} }]);
  }
  function openGemini() {
    createChatUI(); const panel = $('studyhubGeminiPanel'); if (!panel) return;
    const opening = !panel.classList.contains('open'); panel.classList.toggle('open', opening); $('studyhubGeminiFab')?.setAttribute('aria-expanded', String(opening));
    if (opening) requestAnimationFrame(() => { positionGeminiPanel(); $('studyhubGeminiQuestion')?.focus(); });
  }
  window.StudyHubCloud = { isSignedIn: () => serverAuth, isOnlineStudyReady, getStudySyncState, getProfileGeneration: () => profileGeneration, isProfileGenerationCurrent: isActiveProfileGeneration, saveLocalOnly: localSave, requestStudyAI, isOfflineProfile: () => !!user && !serverAuth, login: openProfile, logout, switchAccount, syncNow, openProfile, openGemini, showSetupHelp, reviewFileArchives, getUser: () => user, serverNow };
  window.addEventListener('click', event => { const target = event.target; if (target?.closest?.('#studyhubGeminiFab')) { /* handled by its own listener */ } });

  async function registerOfflineShell() {
    if (!('serviceWorker' in navigator) || !window.isSecureContext) return;
    try { const registration = await navigator.serviceWorker.register('/studyhub-service-worker.js', { scope: '/' }); void registration.update(); } catch (error) { showLocalNotice('No se pudo preparar la caché offline: ' + (error.message || 'error del navegador')); }
  }
  async function init() {
    createChatUI(); void registerOfflineShell();
    try {
      if (navigator.onLine) {
        const response = await api('/api/auth/me', { signal: AbortSignal.timeout(5000) });
        if (response.ok) {
          const data = await response.json(); const guest = getState();
          await loadAccountProfile(data.user, guest);
        } else {
          const last = JSON.parse(localStorage.getItem('estudiohub_last_profile') || 'null');
          if (last?.id) {
            reveal();
            const choice = await new Promise(resolve => appOverlay('Sin conexión con el servidor', `<p>No se pudo validar la sesión Google. Hay una copia local de <b>${escapeHtml(last.name || last.email || 'este perfil')}</b>. Solo se abrirá en este dispositivo y no se sincronizará hasta reconectar.</p>`, [
              { label: 'Abrir copia local', primary: true, run: () => resolve('offline') },
              { label: 'Continuar como perfil local', run: () => resolve('guest') },
            ]));
            if (choice === 'offline') { beginProfileTransition(); profileGeneration += 1; user = last; serverAuth = false; window.setEstudioStorageNamespace(String(last.id)); window.loadAppData(); profileChanging = false; announceSyncState(); setStatus('Sin conexión · copia local', `Perfil local: ${last.name || last.email}`); }
          }
          if (!user) setStatus(navigator.onLine ? 'Inicia sesión con Google para sincronizar' : 'Sin conexión · guardado local', 'Perfil local');
        }
      } else {
        const last = JSON.parse(localStorage.getItem('estudiohub_last_profile') || 'null');
        if (last?.id) {
            reveal();
          const choice = await new Promise(resolve => appOverlay('EstudioHUB está sin conexión', `<p>Tu último perfil Google fue <b>${escapeHtml(last.name || last.email || 'Estudiante')}</b>. La copia local sigue disponible en este dispositivo. No se verificará ni sincronizará hasta recuperar Internet.</p>`, [
            { label: 'Abrir copia local', primary: true, run: () => resolve('offline') },
            { label: 'Continuar como perfil local', run: () => resolve('guest') },
          ]));
          if (choice === 'offline') { beginProfileTransition(); profileGeneration += 1; user = last; window.setEstudioStorageNamespace(String(last.id)); window.loadAppData(); profileChanging = false; announceSyncState(); setStatus('Sin conexión · copia local', `Perfil local: ${last.name || last.email}`); }
        } else setStatus('Sin conexión · guardado local', 'Perfil local');
      }
    } catch { profileLoading = false; profileChanging = false; announceSyncState(); setStatus('Sin conexión · guardado local', 'Perfil local'); }
    reveal(); refreshUI();
  }
  init();
})();
