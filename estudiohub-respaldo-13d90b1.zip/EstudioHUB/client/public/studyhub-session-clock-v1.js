/* Reloj Study Kit: tiempo canónico del servidor + avance monotónico local. */
(function (root) {
  'use strict';
  let anchor = null;
  const MAX_ELAPSED_MS = 12 * 60 * 60 * 1000;

  function monotonicNow() {
    const value = root.performance?.now?.();
    return Number.isFinite(value) ? Number(value) : null;
  }

  function syncServerNow(serverNow, requestStartedAt, responseReceivedAt) {
    if (!Number.isSafeInteger(serverNow) || serverNow < 0) return false;
    const received = Number.isFinite(responseReceivedAt) ? Number(responseReceivedAt) : monotonicNow();
    const started = Number.isFinite(requestStartedAt) ? Number(requestStartedAt) : received;
    if (!Number.isFinite(received) || !Number.isFinite(started) || received < started) return false;
    anchor = { serverNow, monotonicNow: (started + received) / 2 };
    return true;
  }

  function now() {
    const current = monotonicNow();
    if (!anchor || !Number.isFinite(current)) return null;
    const value = Math.floor(anchor.serverNow + Math.max(0, current - anchor.monotonicNow));
    return Number.isSafeInteger(value) ? value : null;
  }

  function deadlineAfter(durationMs) {
    const current = now();
    if (!Number.isSafeInteger(current) || !Number.isFinite(durationMs) || durationMs < 0 || durationMs > MAX_ELAPSED_MS) return null;
    const deadline = current + Math.floor(durationMs);
    return Number.isSafeInteger(deadline) ? deadline : null;
  }

  function remainingUntil(deadline) {
    const current = now();
    if (!Number.isSafeInteger(current) || !Number.isSafeInteger(deadline) || deadline < 0) return null;
    return Math.max(0, Math.min(MAX_ELAPSED_MS, Number(deadline) - current));
  }

  function remainingMs(session) {
    const saved = Math.max(0, Math.min(MAX_ELAPSED_MS, Math.floor(Number(session?.remainingMs) || 0)));
    if (session?.status !== 'active') return saved;
    if (session?.timestampBasis !== 'server' || !Number.isSafeInteger(session?.updatedAt)) return null;
    const currentServerNow = now();
    if (!Number.isSafeInteger(currentServerNow)) return null;
    const elapsed = Math.max(0, Math.min(MAX_ELAPSED_MS, currentServerNow - Number(session.updatedAt)));
    return Math.max(0, saved - elapsed);
  }

  root.StudyKitSessionClock = Object.freeze({ syncServerNow, now, deadlineAfter, remainingUntil, remainingMs, isReady: () => Number.isSafeInteger(now()) });
})(typeof window !== 'undefined' ? window : globalThis);
