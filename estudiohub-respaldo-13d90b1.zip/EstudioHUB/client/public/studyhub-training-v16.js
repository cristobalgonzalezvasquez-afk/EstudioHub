/* Puente de compatibilidad para la pestaña heredada. TEA local se retiró; el Study Kit se ejecuta con Gemini. */
(function () {
  'use strict';

  window.trainingTabHTML = function (_studyClass, activeTab) {
    const active = activeTab === 'training';
    return `<button type="button" role="tab" aria-selected="${active}" class="flash-tab ${active ? 'active' : ''}" onclick="setClassViewTab('training')"><i class="fa-solid fa-brain mr-1"></i>Estudio IA</button>`;
  };

  window.trainingPaneHTML = function (studyClass) {
    return typeof window.studyKitPanelHTML === 'function'
      ? window.studyKitPanelHTML(studyClass)
      : '<p class="text-sm text-slate-500">Study Kit se está cargando. Vuelve a abrir Estudio IA en unos segundos.</p>';
  };

  window.trainingPaneEnter = function () {
    window.studyKitRefreshChoices?.();
    window.studyKitRenderCurrentSession?.();
  };
})();
