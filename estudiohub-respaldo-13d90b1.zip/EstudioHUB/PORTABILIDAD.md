# EstudioHUB — copia portable del código

**Corte:** 15-10-2026
**Checkpoint oficial:** `1acef1d9c4aafa595b933aa95ac7bed0e67c844d`
**Sitio publicado:** https://estudiohub-9j7t78pd.manus.space

## Qué contiene

Este archivo reúne los 155 archivos versionados del código fuente del checkpoint indicado: interfaz, scripts, estilos, backend, esquema y migraciones de base de datos, configuración de compilación y documentación del proyecto.

## Qué no contiene

Por seguridad, no incluye `.git` ni la URL interna del repositorio; tampoco contiene claves Google/Gemini, variables de entorno, datos de cuentas, base de datos, archivos subidos por estudiantes ni datos de IndexedDB/localStorage de un navegador. Es una copia del código, no un respaldo de datos personales.

Para respaldar los datos de una cuenta, inicia sesión en EstudioHUB y usa **Perfil → Sincronización y recuperación** o la exportación JSON disponible en la aplicación. Mantén ese respaldo separado del código.

## Restauración en un nuevo proyecto Webdev

1. Crea un proyecto web separado con servidor y base de datos administrada propios. No conectes staging a la base de datos oficial ni copies datos de estudiantes.
2. Extrae este ZIP y copia sus archivos al nuevo proyecto.
3. Configura las credenciales Google y Gemini mediante el formulario seguro del proyecto; no las escribas en el código, en Git ni en un archivo de respaldo.
4. Autoriza el origen de Preview de staging en el cliente OAuth Web de Google.
5. Instala las dependencias con `pnpm install --frozen-lockfile`; aplica las migraciones pendientes con `pnpm db:migrate`.
6. Ejecuta `pnpm check`, `pnpm test` y `pnpm build`; revisa el Preview antes de promover cualquier cambio al proyecto oficial.
7. Mantén desactivada la publicación automática del entorno de pruebas.

La copia no trae historial Git; se puede importar en un nuevo repositorio o proyecto. El proyecto oficial publicado sigue siendo la referencia de producción en el checkpoint indicado arriba.
