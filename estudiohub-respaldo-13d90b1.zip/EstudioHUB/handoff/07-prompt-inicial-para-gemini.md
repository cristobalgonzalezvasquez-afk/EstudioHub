# 07 — Prompt inicial para Gemini

Copia y pega este prompt en la conversación de la IA de programación que continuará EstudioHUB:

```text
Vas a continuar EstudioHUB. Antes de proponer o editar código, lee en este orden todos los archivos:

1. handoff/00-LEEME-PRIMERO.md
2. handoff/01-arquitectura.md
3. handoff/02-sincronizacion-y-perfiles.md
4. handoff/03-study-kit-gemini.md
5. handoff/04-historial-de-cambios.md
6. handoff/05-problemas-abiertos.md
7. handoff/06-despliegue-y-entorno.md
8. handoff/07-prompt-inicial-para-gemini.md

Después, resume con tus propias palabras: arquitectura, rutas activas, garantías de perfiles/sync, flujo de Study Kit/procedencia, correcciones anteriores y qué partes están verificadas o NO VERIFICADAS. No empieces a editar todavía.

Primero diagnostica los problemas abiertos del archivo 05. Para el error de evaluación de Smart Study, pide/lee status HTTP, code, error, Retry-After y duración, sin solicitar cookies, claves ni materiales académicos privados. Para la pausa al iniciar, compara lo reportado con las versiones servidas del HTML/Service Worker y con la prueba sintética ya documentada. Distingue claramente un bug actual de uno histórico ya corregido en el código pero posiblemente no desplegado.

No cambies código, configuración, datos, base de datos, secretos ni despliegue hasta presentar una explicación causal con evidencia y recibir confirmación explícita del usuario. No publiques a producción sin confirmación explícita.

Reglas obligatorias:
- No borrar ni sobrescribir datos de usuario.
- No debilitar citas, `citationProofId`, hashes/receipts de procedencia ni SHA-256 de archivos.
- ETag y X-Content-Checksum son informativos; SHA-256 de bytes descargados decide.
- No mezclar perfiles Google ni aceptar respuestas Gemini tardías de otra identidad.
- Mantener modo offline, copias recuperables y mensajes reales de error.
- No poner claves en código o navegador.
- No afirmar que una prueba sintética es una prueba de producción/E2E.
- Si un dato no está demostrado, escribe NO VERIFICADO.
```
