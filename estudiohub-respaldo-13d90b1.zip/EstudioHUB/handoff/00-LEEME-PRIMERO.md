# EstudioHUB — leer primero

## Qué es

EstudioHUB es una aplicación web para que estudiantes organicen ramos, clases y materiales, estudien sin conexión y sincronicen perfiles entre dispositivos. En las funciones de Study Kit usa Gemini en el servidor para crear y evaluar actividades citadas desde los materiales seleccionados.

El código documentado corresponde al proyecto de pruebas en `HEAD c9b6406` antes del commit de este paquete. El dominio `https://estudiohub-2mnlhtoe.manus.space` aparece en el historial como URL oficial. Qué SHA sirve ahora ese dominio: **NO VERIFICADO**. Este paquete no publica ni cambia la URL oficial.

## Secciones principales

Los nombres están comprobados en `client/index.html:486–499`; el detalle funcional que no se desprende del nombre se indica como no verificado.

- **Inicio:** entrada y resumen de la aplicación; composición exacta del panel: **NO VERIFICADO**.
- **Ramos y Apuntes:** organiza asignaturas, clases, apuntes y archivos; contiene las funciones de estudio IA/Study Kit.
- **Hoja de Cálculo:** acceso a hojas de cálculo del estudiante.
- **Contabilidad:** espacio de trabajo contable.
- **Documentos:** acceso a documentos.
- **Presentaciones:** acceso a presentaciones.
- **Calendario:** acceso al calendario.
- **Graficador Económico:** herramienta de gráficos económicos.
- **Fórmulas:** acceso a fórmulas.
- **Biblioteca:** acceso a la biblioteca.

Las descripciones detalladas de los módulos que no son Ramos/Study Kit deben confirmarse leyendo `client/index.html` y los manejadores asociados antes de cambiarlos.

## Reglas obligatorias para quien continúe

1. **No borrar ni sobrescribir datos de estudiantes.** No probar contra la base compartida. Usar datos sintéticos y un entorno/DB aislado para cualquier integración real.
2. **No debilitar integridad.** Las citas deben tener procedencia verificable. `citationProofId`, `studyKitProofHash`, los recibos por campo y la revisión de snapshot siguen siendo obligatorios. Los archivos cloud se aceptan por SHA-256 calculado sobre los bytes recibidos; `ETag` y `X-Content-Checksum` no reemplazan esa comprobación.
3. **No publicar a producción sin autorización expresa.** Un commit/checkpoint no equivale a publicación. Confirmar el SHA y destino exactos antes de publicar.
4. **Nunca poner claves en el código del navegador.** `GEMINI_API_KEY`, tokens de sesión y secretos de infraestructura solo en el entorno protegido del servidor. No imprimir ni adjuntar secretos.
5. **Mantener el modo offline y la recuperación local.** Los cambios pendientes no deben desechar copias locales ni copias cloud automáticamente.
6. **Mantener aislamiento estricto por perfil Google.** No fusionar datos de cuentas. Invalidar respuestas de solicitudes iniciadas en una generación de perfil anterior.
7. Si un dato no está demostrado por el código, una prueba existente o evidencia observada, escribir **NO VERIFICADO**. No presentar pruebas sintéticas como verificación visual o E2E en producción.

## Orden recomendado de lectura

1. `00-LEEME-PRIMERO.md` — alcance y límites.
2. `01-arquitectura.md` — carpetas, scripts activos, DB y flujo.
3. `02-sincronizacion-y-perfiles.md` — login, sincronización, offline, recuperación e integridad de archivos.
4. `03-study-kit-gemini.md` — generación, citas, proofs, sesiones y corrección.
5. `04-historial-de-cambios.md` — síntomas, causas, reparaciones y SHAs comprobados.
6. `05-problemas-abiertos.md` — diagnóstico prioritario de lo que el usuario reporta ahora y estado real del código fuente leído.
7. `06-despliegue-y-entorno.md` — variables, dependencias, comandos, pruebas existentes e infraestructura por reemplazar.
8. `07-prompt-inicial-para-gemini.md` — prompt de inicio para otra IA.

## Alcance del paquete

El ZIP se construirá desde Git, por lo que incluye fuentes y documentación versionadas, pero no `node_modules`, archivos `.env`, claves ni datos de usuarios. No es un dump de MySQL ni un respaldo de IndexedDB. Las copias de archivos y snapshots de estudiantes no forman parte de este paquete.
