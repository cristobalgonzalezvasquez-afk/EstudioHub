# 01 — Arquitectura de EstudioHUB

## Stack comprobado

- Node.js 22 (`Dockerfile:1`), TypeScript y pnpm 10.18.0 (`package.json:108`).
- Vite 7 para frontend/build; Express 4 para servidor HTTP.
- Drizzle ORM + `mysql2`; dialecto MySQL (`drizzle.config.ts:8–14`).
- Gemini API REST desde el backend. La clave no se envía al navegador.
- IndexedDB/localStorage y Service Worker para uso local/offline.
- Vitest para pruebas; `tsc --noEmit` para typecheck.

## Estructura

| Ruta | Responsabilidad comprobada |
| --- | --- |
| `client/index.html` | Página principal; pestañas y referencias a CSS/JS públicos. |
| `client/public/` | Scripts y estilos cargados por el HTML, Service Worker y recursos públicos. |
| `client/src/` | Código React del starter. Si los módulos actuales consumen todas esas vistas: **NO VERIFICADO**; no asumir que reemplaza `client/index.html`. |
| `server/_core/index.ts` | Entrada Express/Vite y montaje de rutas. |
| `server/_core/env.ts` | Lee variables de Manus y `DATABASE_URL` por getters. |
| `server/_core/sdk.ts` | OAuth/JWT del starter Manus; es distinto del flujo Google personalizado de EstudioHUB. |
| `server/studyhub.ts` | API de perfil, archivos, sincronización, Gemini, proofs y validación de kits. |
| `server/study-material.ts` | Valida y prepara archivos; convierte Word/Excel a PDF, extrae texto PDF para cotejar citas y crea partes multimodales. |
| `server/db.ts` | Acceso Drizzle/MySQL. |
| `drizzle/schema.ts` | Definición de tablas. |
| `drizzle/*.sql`, `drizzle/meta/_journal.json` | Migraciones y orden de aplicación. |
| `server/*.test.ts`, `server/fixtures/` | Pruebas sintéticas/unitarias y fixtures de prueba. |
| `shared/` | Constantes/tipos compartidos del starter. |
| `attached_assets/` | Recursos adjuntos; inventario/uso por cada pantalla: **NO VERIFICADO**. |
| `Dockerfile` | Build Node de producción y dependencias nativas para documentos/PDF. |

## Scripts activos y versiones heredadas

Referencias comprobadas en `client/index.html:432, 4807–4812` y `client/public/studyhub-service-worker.js:2`:

```text
CSS:  /studyhub-enhancements-v16.css
      /studyhub-study-kit-v16.css
JS:   /studyhub-sync-merge-v16.js
      /studyhub-session-clock-v2.js
      /studyhub-study-kit-compat-v1.js
      /studyhub-study-kit-v18.js
      /studyhub-training-v16.js
      /studyhub-cloud-v20.js
SW:   /studyhub-service-worker.js (shell declarado v27)
```

`studyhub-cloud-v11.js`…`v19.js`, `studyhub-cloud.js`, `studyhub-study-kit-v13.js`…`v17.js`, `studyhub-study-kit.js`, `studyhub-sync-merge-v13.js`…`v15.js` y `studyhub-training-v13.js`…`v15.js` están versionados, pero no aparecen en el entrypoint/shell actual revisado. Clasificarlos como **heredados/no referenciados por la página actual**, no como seguros para borrar: no se demostró que clientes antiguos, URLs externas o cachés previas no los usen.

`studyhub-training-v16.js` sí se carga; el HTML define `trainingPaneHTML()` y `trainingTabHTML()` como funciones vacías en `client/index.html:432`. No asumir que esto habilita un modo de IA local.

El `ReferenceError: studyhub is not defined` fue reportado históricamente para scripts v17/v15. No se reprodujo en esta tarea. Su causa original exacta: **NO VERIFICADO**.

## Modelo de datos MySQL

Nombres comprobados en `drizzle/schema.ts` y usados en `server/studyhub.ts`:

- `users`: identidad del usuario.
- `studySessions`: hash del token de sesión y expiración; no almacenar token claro.
- `studyAuthNonces`: hash del nonce Google y expiración.
- `studyCloudState`: snapshot JSON y revisión por usuario.
- `studyFiles`: archivo privado por usuario/clave local, con bytes, MIME, tamaño y checksum.
- `studyOperations`: operaciones idempotentes y receipts/proofs de Study Kit por propietario.

Las columnas completas están en `drizzle/schema.ts`. No aplicar migraciones sobre una DB con estudiantes sin respaldo y revisión.

Migraciones registradas en `drizzle/meta/_journal.json`:

```text
drizzle/0000_initial_users.sql
drizzle/0001_lazy_nebula.sql
drizzle/0002_tense_lizard.sql
drizzle/0003_study_auth_nonce.sql
```

No se ejecutó migración durante este traspaso.

## Flujo cliente ⇄ servidor ⇄ MySQL ⇄ Gemini

```text
┌─────────────────────────────────────────────────────────────────┐
│ Navegador                                                       │
│ client/index.html + JS versionados                              │
│ IndexedDB/localStorage por namespace; Service Worker offline    │
└───────────────┬─────────────────────────────────────────────────┘
                │ HTTPS + cookie HttpOnly + X-EstudioHub-Request
                │ GET/PUT /api/study/state; /api/files/*
                ▼
┌─────────────────────────────────────────────────────────────────┐
│ Express · server/studyhub.ts                                    │
│ requireStudyUser → usuario autenticado → selección congelada     │
│ valida schema, citas, proofs, hashes y refs de archivos           │
└──────────┬───────────────────────────────────┬──────────────────┘
           │ snapshot/revisión/transacción      │ bytes privados verificados
           ▼                                   ▼
┌─────────────────────────┐           ┌─────────────────────────┐
│ MySQL / Drizzle         │           │ prepareStudyMaterials   │
│ state, users, sessions, │           │ PDF/imagen/Office/texto │
│ files y operations      │           └────────────┬────────────┘
└──────────┬──────────────┘                        │ request + parts
           │                                       ▼
           │                              ┌──────────────────────┐
           └── proof rows/revisión ───────│ Google Gemini API    │
                                          │ JSON de salida       │
                                          └──────────┬───────────┘
                                                     │ parse + validar
                                                     ▼
                              cliente guarda local → PUT de snapshot
```

Límites comprobados en `server/study-material.ts`: 8 archivos máximo, 25 MiB por archivo, 45 MiB de bytes inline combinados y 100.000 caracteres de texto. Word/Excel requieren LibreOffice; PDFs usan `pdftotext` solo para evidencia/citas. El PDF o imagen original se envía como bytes a Gemini; Office se convierte a PDF primero.
