# 03 — Study Kit y Gemini

## Flujo de generación

Código: `client/public/studyhub-study-kit-v18.js`, `client/public/studyhub-cloud-v20.js`, `server/studyhub.ts`, `server/study-material.ts`.

1. En Ramos y Apuntes el estudiante selecciona entre 1 y 10 clases, y hasta 8 archivos privados. Los apuntes del ramo/clase y transcripciones YouTube seleccionadas se resuelven desde el snapshot cloud confirmado del propietario. El cliente no envía libremente texto/archivos para saltarse ese ownership check.
2. `prepareStudyMaterialRequest()` (`server/studyhub.ts:1246–1268`) lee el snapshot confirmado, resuelve las clases/keys y recupera archivos por `userId`. Recalcula SHA-256, tamaño y tipo antes del procesamiento.
3. `prepareStudyMaterials()` (`server/study-material.ts:157–299`) prepara materiales:
   - PDF: envía los bytes PDF originales a Gemini. `pdftotext` se usa solo para cotejar citas y páginas en el servidor; un PDF escaneado puede no tener texto.
   - DOC/DOCX/XLS/XLSX: conversión aislada a PDF con LibreOffice; Gemini recibe el PDF convertido conservando diagramación/tabla. El texto extraído se mantiene solo para cotejar.
   - PNG/JPEG/WebP/BMP: envía bytes originales; no depende de OCR local del navegador.
   - TXT/MD/CSV/TSV/JSON/XML: decodifica UTF-8 y pasa contenido como texto con ID de fuente.
4. `computeStudyKitCounts()` distribuye exactamente el total elegido entre modalidades. La cantidad debe ser 5, 10, 15 o 20; no se aceptan más modalidades que actividades. Las tarjetas complementarias son 5 o 0 y el podcast es optativo.
5. `/api/gemini/study-kit` arma un prompt JSON, llama `callGemini()` (`server/studyhub.ts:1084–1105`) y parsea con `parseGeminiJson()`.
6. `normalizeStudyKitResponse()` (`server/studyhub.ts:693`, ver implementación a continuación) ajusta aliases/IDs/citas; `snapQuoteToEvidence()` (`:113`) busca una ventana literal de hasta 30 palabras con umbral de coincidencia 70% para reemplazar una paráfrasis cercana por palabras reales del material.
7. `studyKitGenerationFailure()` valida estructura, conteos, citas, límites y procedencia. Si algo no se valida, responde `422`; no guarda el kit como resultado correcto.
8. El servidor asigna `id` y `citationProofId`, adjunta selección/material congelados y registra proof en `studyOperations` en una transacción que confirma que la revisión cloud sigue siendo la misma. Devuelve `{ kit: storedKit }`.
9. El cliente v18 conserva el kit como lo devolvió el servidor, añade campos locales de sesión/progreso y lo sincroniza. La validación del snapshot exige proofs de owner y payload; un kit inválido no puede sobrescribir nube.

## Material exacto de Gemini

Modelo default comprobado: `gemini-flash-lite-latest`. Si existe `GEMINI_MODEL`, el backend usa ese nombre, salvo que contenga caracteres fuera del patrón permitido. Endpoint REST:

```text
POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
Content-Type: application/json
x-goog-api-key: <GEMINI_API_KEY>
AbortSignal.timeout: 90 000 ms
```

`GEMINI_API_KEY` solo se lee en el servidor. La ausencia de la clave produce HTTP 503. Respuestas de proveedor no-429/5xx se normalizan como HTTP 400; el 429 se conserva y 5xx pasa como 502. No imprimir prompt, contenido del archivo, respuesta bruta del proveedor o clave.

## Esquema JSON solicitado al generador

Copiado de `server/studyhub.ts:1946–1948`. `sourcePage` es metadato opcional separado del objeto esquemático; no debe inventarse. `sourceFileId` es el ID exacto `S1`…`S8` o cadena vacía para texto sin archivo.

```json
{
  "title": "string",
  "difficulty": "string",
  "studyGuide": {
    "summary": "resumen de 1–3 frases, al menos 40 caracteres",
    "keyPoints": ["punto 1", "punto 2", "punto 3"],
    "glossary": [
      {"term":"...", "definition":"...", "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
    ],
    "questions": ["pregunta 1", "pregunta 2", "pregunta 3"],
    "sourceQuote":"cita breve",
    "sourceFileId":"S1 o cadena vacía",
    "podcastScript":"texto o cadena vacía"
  },
  "multipleChoice": [
    {"id":"...", "question":"...", "topic":"...", "options":["A","B","C","D"], "correctIndex":0, "explanations":["...","...","...","..."], "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
  ],
  "trueFalse": [
    {"id":"...", "question":"...", "topic":"...", "answer":true, "explanation":"...", "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
  ],
  "shortAnswer": [
    {"id":"...", "question":"...", "topic":"...", "expectedAnswer":"...", "rubric":["..."], "explanation":"...", "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
  ],
  "matchingPairs": [
    {"id":"...", "left":"...", "right":"...", "explanation":"...", "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
  ],
  "ordering": [
    {"id":"...", "question":"...", "topic":"...", "items":["...","...","..."], "correctOrder":[0,1,2], "explanation":"...", "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
  ],
  "diagramLabels": [
    {"id":"...", "question":"...", "topic":"...", "diagramDescription":"descripción textual del diagrama", "labels":[{"prompt":"...", "options":["...","..."], "correctIndex":0}], "explanation":"...", "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
  ],
  "flashcards": [
    {"id":"...", "front":"...", "back":"...", "sourceQuote":"cita breve", "sourceFileId":"S1 o cadena vacía"}
  ]
}
```

Requisitos del prompt: guía de exactamente 3 puntos, 3 términos y 3 preguntas de repaso; cantidades exactas para modalidades/tarjetas; arrays vacíos para modalidades no seleccionadas; citas textuales de 12–30 palabras cuando sean citas textuales; PDF/diapositivas: copiar literalmente, sin traducir ni parafrasear; nunca inventar IDs/páginas/conclusiones. Si la fuente no basta, solo `{"error":"evidencia_insuficiente"}`. `followUps` no lo genera el objeto inicial; el servidor lo inicializa como array vacío en el kit persistido. `citationProofId` y `sourceFiles` se agregan después de la respuesta de Gemini.

## Validaciones que no se deben debilitar

- Estructura por modalidad: cuatro opciones en selección múltiple; booleano para verdadero/falso; rúbrica acotada para respuesta corta; pareado `left/right`; permutación base cero válida para ordenamiento; etiquetas con opciones e índices válidos; límites de texto/arrays/IDs.
- Conteo exacto por modalidad y total solicitado; no completar silenciosamente una modalidad faltante.
- Cada cita debe tener entre 12 y 400 caracteres y corresponder a apuntes o al archivo indicado. `citationIssue()` (`server/studyhub.ts:564–604`) permite evidencia visual PDF sin `sourcePage` si la cita no se encuentra literalmente y existe evidencia visual enviada a Gemini. La condición estricta ante página ausente es `evidencePages === undefined && textEvidenceAvailable`; si hay `sourcePage`, valida rango y página indicada. No convertir esta excepción de PDF visual en una tolerancia para texto de apuntes o archivos textuales.
- `snapQuoteToEvidence()` no convierte una afirmación no relacionada en una cita: requiere similitud alta con una ventana real y devuelve un fragmento literal, no una paráfrasis.
- No asignar archivo/página por ambigüedad; no aceptar IDs fuera de la selección.
- El material de prueba corresponde al snapshot confirmado y a los checksums privados de esa revisión.

## Proof de procedencia

`STUDY_KIT_PROOF_FIELDS` en `server/studyhub.ts:259–309` cubre título/dificultad, texto y etiquetas de fuente, IDs de clase, longitud, `sourceFiles`, guía, actividades y `followUps`, además de hashes por campos de cita/archivo/página. `studyKitProofHash()` usa JSON canónico ordenado, SHA-256 y excluye `id`; `sessions` y progreso quedan fuera intencionalmente para permitir estudiar sin invalidar el contenido firmado.

El servidor registra proof y receipts por campo en `studyOperations`, ligados a `userId`, revisión y contenido. En `PUT /api/study/state:1735–1786`, los cambios de kits pasan por el diagnóstico de integridad (ramas a–d). No aceptar kit modificado sin proof válido. El log seguro solo incluye rama, motivo, kit ID y nombres de campos; no incluye el texto o las citas.

## Sesiones, modos y seguimientos

- Smart Study guarda respuestas/estado en `kit.sessions`, hasta 10 sesiones, IDs únicos. Pending/syncing muestra «Sincronizando…»; error, offline, signed-out y conflicto pausan conservando la copia local.
- Simulacro formal guarda respuestas y después manda `/api/gemini/grade` para calificación final; pareados y tarjetas tienen rutas/lógicas propias en v18. No afirmar que todas las actividades se evalúan igual: el tipo de pregunta decide la ruta.
- En práctica, `studyKitSubmitCurrent()` deja `answer.pending=true`, conserva la respuesta y llama `/api/gemini/study-answer`. Si falla, el estado sigue reintentable; no se pierde la respuesta.
- El corrector valida respuesta, feedback, cita y follow-up. Un `followUpQuestion` no firmado se ignora; `createStudyKitFollowUpProof()` crea un nuevo `citationProofId` para el kit actualizado, tras validar la selección congelada y registrar los receipts. El cliente agrega la nueva pregunta solo junto con ese proof.
