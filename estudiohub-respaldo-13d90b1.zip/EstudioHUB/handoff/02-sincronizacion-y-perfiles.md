# 02 — Sincronización, archivos y perfiles

## Inicio de sesión Google

Código principal: `server/studyhub.ts` (rutas de autenticación aproximadamente `1574–1648`, middleware `requireStudyUser` en `1014–1044`) y `client/public/studyhub-cloud-v20.js`.

1. El cliente obtiene `GOOGLE_CLIENT_ID` desde `/api/auth/config` y pide `/api/auth/nonce`.
2. El servidor genera un nonce aleatorio de 32 bytes, guarda solo su digest con expiración de 10 minutos y devuelve el nonce una vez.
3. Google Identity Services entrega una credencial al popup del navegador. `/api/auth/google` valida firma/audience/issuer/nonce y que el correo esté verificado; el código crea o resuelve al usuario de EstudioHUB.
4. El servidor genera una sesión aleatoria. En MySQL guarda el hash del token y el vencimiento en `studySessions`.
5. El navegador recibe cookie `HttpOnly; Secure; SameSite=None; Partitioned`, necesaria para el Preview HTTPS incrustado. El token no se guarda en localStorage.
6. `requireStudyUser` vuelve a buscar el hash de cookie y obtiene el ID de usuario para cada ruta privada.

El cliente ID de Google es público por naturaleza, pero la configuración se entrega desde el servidor. El Client Secret OAuth no se usa en este flujo popup; **NO VERIFICADO** si la infraestructura externa exige otro flujo.

## Aislamiento entre perfiles

`client/public/studyhub-cloud-v20.js` mantiene un namespace local por usuario (`setEstudioStorageNamespace`/`profileKey`) y `profileGeneration`. Al cambiar perfil:

- Espera a que el sync activo termine; si no puede confirmarlo, cancela el cambio y conserva el perfil.
- Guarda/pausa la sesión Smart Study del perfil anterior antes de cerrar.
- Cambia el namespace local y carga una copia local asociada a la nueva cuenta.
- Compara snapshot/revisión cloud con copia local; muestra elección/merge cuando hay dos copias.
- No mezcla perfil invitado y Google automáticamente. Copias desplazadas se archivan en IndexedDB como registros recuperables.
- Incrementa la generación del perfil y descarta resultados Gemini/SSE/polling de la generación anterior.

El campo de último perfil en localStorage se usa para seleccionar el namespace, no como autorización de servidor. La autorización real depende de la cookie de servidor.

## Revisión, estados y cola

- `studyCloudState` guarda un payload y una `revision` por usuario.
- `GET /api/study/state` devuelve snapshot y revisión; `PUT /api/study/state` exige `baseRevision`, `operationId` y payload validado.
- Cada escritura calcula un hash del payload, verifica referencias privadas y ejecuta una transacción. Solo acepta la revisión esperada; responde `409` si existe una carrera/conflicto.
- El `operationId` hace idempotente el retry: la misma operación con el mismo hash devuelve la confirmación previa; el mismo ID con distinto hash es conflicto.
- Estados cliente incluyen `pending`, `syncing`, `confirmed`, `offline`, `signed-out`, `conflict` y `error` (`getStudySyncState`/`announceSyncState` en v20). Los estados exactos son propiedad de las funciones del cliente; no sustituirlos por una sola bandera.
- Cambios offline permanecen en almacenamiento local. Al reconectar se intenta subir el snapshot y archivos. Un error o conflicto no debe borrar copias.
- El cliente usa merge de tres vías (`merge3`) para cambios independientes. Conflictos presentan una elección explícita y guardan copias recuperables antes de sustituir cualquier versión.

`GET/PUT /api/study/state` y bloqueo de escritura: `server/studyhub.ts:1666–1804`. El validador de payload y las reglas por clase/kit están cerca de `470–519`.

## Sesiones de Smart Study durante sincronización

En `client/public/studyhub-study-kit-v18.js`:

- `syncStateBlocksSession()` pausa solo por desconexión, sesión cerrada o conflicto.
- `pending/syncing` muestra «Sincronizando…»; no es una pausa real por sí sola. Un timer conserva su deadline/remainingMs.
- `error` pausa la sesión y muestra status/code para reintentar.
- El evento cloud `confirmed` reanuda el mismo objeto/ID de sesión.
- Una sesión del kit tiene máximo 10 entradas y IDs únicos en `validStoredStudyKit` (`server/studyhub.ts:253–255`). Las sesiones no están dentro del hash de procedencia del contenido.

El inicio de generación/IA aún requiere perfil Google y cloud confirmado. `isOnlineStudyReady()` puede ser falso mientras haya cambios pendientes; eso no debe confundirse con pausar una sesión legítima ya iniciada.

## Archivos privados y recuperación

- El cliente guarda bytes en almacenamiento local/indexado y referencias en el snapshot.
- `PUT /api/files/:localKey` guarda el contenido por `userId` en `studyFiles`; antes verifica tamaño/tipo y SHA-256.
- `GET/HEAD /api/files/:localKey` solo acceden a filas del propietario autenticado. Se verifican bytes contra checksum antes de entregar contenido.
- Archivos recuperables se describen en `studyhubFileArchives` con `checksumAlgorithm: "sha256"`, checksum, tamaño, MIME y fuente. El botón descarga snapshots JSON `estudiohub-recuperacion-<fecha>.json`; los binarios se recuperan aparte desde Versiones recuperables.
- En discrepancia de archivos, el cliente debe conservar original local y copias cloud/recuperables; no reparar ni descartar automáticamente.

## Integridad de descarga: SHA-256 final, ETag informativo

`client/public/studyhub-cloud-v20.js:513–619`:

1. Normaliza `ETag` (quita `W/`, comillas y minúsculas) para comparaciones informativas.
2. Un `HEAD`, `ETag` o `X-Content-Checksum` discrepante no detiene una descarga ni autoriza aceptación.
3. Calcula SHA-256 sobre el `Blob` completo recibido por `GET /api/files/:localKey` y lo compara con `remote.checksum` registrado en el snapshot.
4. Si coincide, acepta. Si no, informa `CLOUD_FILE_CHECKSUM_MISMATCH`, conserva las copias y no repara ni descarta datos.
5. Reintenta una vez errores transitorios de lectura (`408`, `425`, `429`, `5xx`, abort/timeout/red); un mismatch de checksum no se reintenta automáticamente.

En `server/studyhub.ts:1884–1911`, GET/HEAD emiten `Cache-Control: private, no-store, no-transform`, `X-Content-Checksum`, `ETag` fuerte y metadatos de contenido. Estos headers ayudan a diagnosticar; solo el SHA de bytes descargados decide.

## Garantías que no se deben romper

- Nada se elimina por una respuesta de error/timeout ni por discrepancia de ETag.
- El dueño del perfil se comprueba tanto para snapshot como para archivos, sesiones, proofs y operaciones.
- No se sube una referencia de archivo si el binario no está guardado por ese mismo usuario.
- `pending/syncing` no implica pérdida ni pausa de sesión; `conflict` sí requiere resolución explícita.
- Respuesta tardía de otro perfil no modifica el perfil actual.
- Local → nube requiere confirmación por revisión. Mostrar «confirmado» solo después de un recibo válido del servidor.
