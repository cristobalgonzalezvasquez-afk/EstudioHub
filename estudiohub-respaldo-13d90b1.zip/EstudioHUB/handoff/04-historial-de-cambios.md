# 04 — Historial de cambios relevantes

Los SHAs siguientes corresponden a commits Git del proyecto. Los síntomas originales provienen de reportes del usuario; las causas se marcan como comprobadas cuando una prueba sintética reprodujo el flujo o el código identifica el fallo.

## 1. Citas PDF: falta de página y cita parafraseada

**Síntoma:** el generador fallaba con «no indica una página para verificar la evidencia visual del PDF» y descartaba todo el kit con HTTP 422.

**Causa:** `citationIssue()` no encontraba literalmente en `pdftotext` una cita que Gemini obtuvo visualmente de diapositivas/gráficos. Para PDF se consideraba que siempre existía evidencia de páginas y se exigía `sourcePage`, aunque Gemini no la hubiera indicado. En PDFs escaneados no hay texto extraíble que cotejar. Otra variante era una cita parafraseada que no coincidía con el texto literal.

**Solución:** `citationIssue()` acepta evidencia visual de PDF sin página si no hay texto/página cotejable, pero conserva estricto el cotejo literal cuando el PDF sí aporta texto verificable. `snapQuoteToEvidence()` busca ventanas de hasta 30 palabras y, si coincide al menos 70%, reemplaza la paráfrasis por un fragmento literal válido. El prompt exige copia literal en el mismo idioma, incluso para diapositivas. `sourcePage` sigue siendo validado si se proporciona.

**Archivos y SHAs:**

- `c50cea3` — `server/study-material.ts`, `server/studyhub.ts`, `server/study-kit.validation.test.ts`, `server/study-material.test.ts`, `server/studyhub.validation.test.ts`, documentación.
- `a068e60` — ajuste de PDF visual sin página y pruebas en `server/studyhub.ts`, `server/study-kit.validation.test.ts`, documentación.
- `9af8905` — límite de extracción, evidencia completa, normalización/snap de cita y pruebas; `server/study-material.ts`, `server/studyhub.ts`, pruebas y documentación.

## 2. Error de descarga cloud por ETag/checksum

**Síntoma:** descarga/sync se quedaba pendiente o fallaba aunque los bytes fueran íntegros; ETag débil/comillas/formato de transporte no coincidían con el metadato.

**Causa comprobada en el código:** ETag es un valor de transporte y no debe decidir la aceptación. Un CDN/proxy puede representarlo como `W/"…"`, normalizarlo o transformarlo.

**Solución:** `downloadCloudFile()` trata `HEAD`, ETag y `X-Content-Checksum` como señales informativas; lee el archivo y decide solo por SHA-256 de los bytes frente al `remote.checksum` del snapshot. Un mismatch conserva todas las copias y da error claro; no repara ni borra. Errores transitorios permiten reintentar una vez. GET/HEAD añaden `Cache-Control: private, no-store, no-transform` y `X-Content-Checksum`.

**Archivos y SHA:** `212b82f` — `client/public/studyhub-cloud-v20.js`, `client/public/studyhub-service-worker.js`, `server/studyhub.ts`, `server/studyhub-cloud-file-integrity.test.ts`, documentación.

## 3. 422 de integridad de snapshot por `followUps` sin re-firma

**Síntoma:** después de crear/editar un kit o guardar un seguimiento adaptativo, `PUT /api/study/state` respondía 422 `invalid_study_kit_integrity` y la nube no se modificaba.

**Causa reproducida:** rama **c**, `proof.payloadHash !== studyKitProofHash(kit)`. La transformación del cliente cambiaba el campo protegido `followUps` respecto del kit devuelto y registrado por el servidor. El proof anterior ya no correspondía al contenido nuevo. `sessions` no era la causa: está excluido del hash de contenido.

**Solución:** el servidor conserva y firma el `followUps` actualizado con un `citationProofId` nuevo y receipts por campo, ligado al propietario y a la revisión/material congelados. El cliente agrega la pregunta y el ID de proof juntos. Si no existe proof válido, no añade el follow-up. No se debilitó la validación.

**Archivos y SHA:** `0425161` — `server/studyhub.ts`, `client/public/studyhub-cloud-v20.js`, `client/public/studyhub-study-kit-v18.js`, `server/study-kit.validation.test.ts`, documentación y versión del Service Worker.

**Límite histórico:** no es posible reconstruir la rama exacta del 422 ocurrido antes de activar diagnóstico. La prueba sintética reproduce la rama c y los futuros rechazos registran rama/motivo/kit/campos sin texto privado.

## 4. Smart Study se pausaba al crear una sesión

**Síntoma:** al iniciar Smart Study, la sesión se guardaba y a continuación se mostraba pausa mientras la barra quedaba pendiente.

**Causa reproducida:** el manejador anterior trataba cualquier `!onlineReady()` como fallo real. Crear/guardar la sesión produce legítimamente `pending/syncing`; el ciclo pausaba y volvía a guardar la misma sesión durante su propio sync. No era rechazo de `validStoredStudyKitSession`, del límite 10 ni del hash de proof.

**Respuesta sintética:** flujo cliente v18 real → `PUT /api/study/state` real con DB sintética: HTTP `200`, `{revision: 2, confirmed: true}`, sin `code`. La prueba confirma que agregar `sessions` deja invariable `studyKitProofHash`.

**Solución:** `syncStateBlocksSession()` solo pausa offline/signed-out/conflict; pending/syncing mantiene sesión/deadline y muestra «Sincronizando…». Error muestra HTTP/code y permite retry; solo `confirmed` reanuda. Timeout de espera ofrece reintento. Se conserva el ID y se evita duplicar sesiones.

**Archivos y SHA:** `c9b6406` — `client/public/studyhub-study-kit-v18.js`, `client/public/studyhub-cloud-v20.js`, Service Worker, `server/study-kit.smart-study.test.ts`, documentación.

## 5. Cambio de perfil, 401 y resultados Gemini tardíos

**Síntoma:** un 401 podía dejar al cliente creyendo que la sesión cloud seguía activa; una solicitud Gemini iniciada en un perfil podía resolverse después de cambiar a otra cuenta.

**Causa:** eventos 401 recibidos por sync/SSE/solicitudes IA no siempre se convertían de inmediato en `signed-out`; una Promise tardía necesitaba comprobar que seguía perteneciendo a la misma generación de perfil.

**Solución:** expirar el estado cloud, detener stream/reintentos, emitir `signed-out` con HTTP/code y conservar localmente la sesión. `profileGeneration` invalida respuestas tardías; el namespace local y la sesión antigua no se mezclan con el nuevo perfil. Se agregaron pruebas sintéticas de 401, generación y transcripción YouTube tardías, y cambio de perfil.

**Archivos y SHA:** `c9b6406` — `client/public/studyhub-cloud-v20.js`, `client/public/studyhub-study-kit-v18.js`, `server/study-kit.smart-study.test.ts`, documentación.

**Cobertura precisa:** el test sintético descrito verifica generación y transcripción tardías; la guardia de chat Gemini existe en v20, pero una prueba específica de chat tardío: **NO VERIFICADO**.

## 6. Otros cambios documentados

- `b61f54b`: ajuste de readiness tras sync; alcance exacto adicional fuera del mensaje del commit: **NO VERIFICADO**.
- `0251617`: tolerancia a variaciones benignas de salida Gemini; los tests de validación actuales cubren aliases/campos opcionales, pero no se reconstruye aquí cada diff antiguo.
- `1a24afc`: restauración de la base del código desde respaldo.
- El Service Worker se elevó a v27 para distribuir los JS corregidos en instalaciones que actualicen el shell. Una caché en un navegador/URL de producción concreta no se inspeccionó en esta tarea.

## Base de evidencia de este documento

Se leyó el código actual, las suites nombradas y los metadatos de commits. No se ejecutaron pruebas ni llamadas Gemini durante la creación de este paquete. Para el resultado de la validación previa, ver `TODO.md:188`; esa evidencia corresponde a la sesión anterior, no a una repetición en esta tarea.
