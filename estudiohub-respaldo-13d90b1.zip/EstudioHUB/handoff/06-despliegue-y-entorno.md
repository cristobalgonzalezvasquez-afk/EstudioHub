# 06 — Despliegue y entorno

## Variables de entorno

Solo se enumeran nombres y usos; no incluir valores en Git, navegador, logs o documentación.

| Variable | Uso comprobado |
| --- | --- |
| `DATABASE_URL` | URL de conexión MySQL para Drizzle (`server/_core/env.ts`, `drizzle.config.ts`). Obligatoria al ejecutar migraciones. |
| `GOOGLE_CLIENT_ID` | Client ID OAuth Web de Google. `/api/auth/config` lo entrega al cliente para inicializar GIS; no es Client Secret. |
| `GEMINI_API_KEY` | Clave privada leída por `callGemini()`; se envía en header `x-goog-api-key` solo servidor-servidor. |
| `GEMINI_MODEL` | Modelo de generación. Default: `gemini-flash-lite-latest`. |
| `PORT` | Puerto HTTP. Dockerfile default 3000; `server/_core/index.ts` debe honrarlo. |
| `NODE_ENV` | Distingue runtime/build de desarrollo/producción. |
| `MANUS_PROJECT_ID` | ID de proyecto para la autenticación SDK del starter Manus. |
| `MANUS_JWT_SECRET` | Secreto de firma/validación de sesión del SDK Manus del starter. |
| `MANUS_OAUTH_API_URL` | Endpoint OAuth del servicio Manus usado por `server/_core/sdk.ts`. |
| `MANUS_API_URL`, `MANUS_API_KEY` | Endpoint/credencial del API Manus usado por helpers del starter. |
| `OWNER_OPEN_ID` | Pista de rol propietario del starter Manus; no es la identidad Google de StudyHub. |

Un archivo `.env.example` **no está versionado** en el repo revisado. No se consultaron secretos ni existe un inventario de los valores actualmente configurados en la plataforma. El valor real de cada variable está **NO VERIFICADO**.

## Google OAuth y dominio

EstudioHUB usa Google Identity Services en popup. En Google Cloud Console → APIs y servicios → Credenciales, crear/verificar un ID de cliente OAuth tipo **Aplicación web** y agregar el origen de cada entorno en «Orígenes autorizados de JavaScript» (Preview y dominio de producción por separado). El flujo actual no usa URI de redirección ni Client Secret; el código de ayuda lo indica en `client/public/studyhub-cloud-v20.js:1275–1279`.

Guardar el Client ID como `GOOGLE_CLIENT_ID` en el entorno protegido de servidor. No escribirlo manualmente en bundle; el servidor lo sirve por `/api/auth/config`. Crear la credencial de Gemini en Google AI Studio, guardar como `GEMINI_API_KEY` en el servidor y configurar `GEMINI_MODEL` solo si se requiere cambiar el default. Nunca copiar esas credenciales al navegador ni a este paquete.

`server/_core/sdk.ts` también integra el OAuth/JWT del starter Manus. Para migrar completamente fuera de Manus, decidir si se conserva o elimina ese login secundario y reemplazar `MANUS_*` por un proveedor propio. El login Google específico de EstudioHUB está en `server/studyhub.ts`; no asumir que eliminar el SDK del starter es inocuo sin rastrear sus rutas/tRPC.

## Base de datos y migraciones

- DB: MySQL; `drizzle.config.ts` requiere `DATABASE_URL` y apunta a `drizzle/schema.ts`.
- Migraciones existentes: `drizzle/0000_initial_users.sql` hasta `drizzle/0003_study_auth_nonce.sql` (ver `drizzle/meta/_journal.json`).
- Aplicar en una DB separada/prueba primero. Revisar esquema, permisos y backup antes de apuntar a una DB que tenga estudiantes.
- `pnpm db:migrate` aplica migraciones existentes; `pnpm db:push` genera y aplica cambios de esquema y no se debe usar sin revisar un cambio de schema.
- No se incluyó ni generó dump de MySQL. No copiar bases o carpetas de perfil de usuarios.

Los binarios privados se guardan en la tabla `studyFiles` como contenido binario MySQL en el código actual. Las dependencias AWS S3 aparecen en `package.json`; su uso activo para los archivos de StudyHub: **NO VERIFICADO**. No migrar `studyFiles` a S3 sin diseñar ownership, URLs firmadas, comprobación SHA y recuperación.

## Despliegue Docker fuera de Manus

`Dockerfile` usa `node:22-bookworm-slim`, instala `libreoffice-writer`, `libreoffice-calc` y `poppler-utils`, activa pnpm 10.18.0, instala con lockfile, ejecuta `pnpm build` y arranca `node dist/index.js` con `PORT=3000` por defecto.

Secuencia equivalente para un entorno limpio (no ejecutada aquí):

```bash
corepack enable
corepack prepare pnpm@10.18.0 --activate
pnpm install --frozen-lockfile
# Definir DATABASE_URL en el entorno; aplicar solo a DB de prueba/revisada.
pnpm db:migrate
pnpm build
PORT=3000 pnpm start
```

Comandos Docker, tras configurar el registry y secretos fuera del repo:

```bash
docker build -t estudiohub:local .
docker run --rm -p 3000:3000 \
  -e PORT=3000 \
  -e DATABASE_URL \
  -e GOOGLE_CLIENT_ID \
  -e GEMINI_API_KEY \
  -e GEMINI_MODEL \
  estudiohub:local
```

No poner literales secretos en línea de comando guardada, Dockerfile o `docker-compose.yml` versionado. Usar un secret manager del proveedor. La DB debe ser persistente; el contenedor no debe ser la única copia de datos. Configurar HTTPS, dominio, cookies `SameSite=None; Secure`, CORS/orígenes y monitoreo antes de exposición pública.

Para Office/PDF, conservar las dependencias nativas de Dockerfile: sin LibreOffice no funcionará conversión DOC/DOCX/XLS/XLSX; sin `pdftotext`, las citas textuales/páginas PDF no se podrán verificar como ahora. El PDF aún puede ser visual, pero no se debe convertir esa limitación en aceptación textual permisiva.

## Pruebas y comandos existentes (solo descripción)

Scripts de `package.json`; **no ejecutados en esta tarea**:

```bash
pnpm check   # tsc --noEmit
pnpm test    # vitest run
pnpm build   # vite build + esbuild del entrypoint Express a dist/
```

Cobertura documentada en los archivos de tests existentes:

- `server/study-material.test.ts`: concurrencia; bytes originales de PDF/imagen; extracción/páginas PDF; DOCX/XLSX a PDF; texto y límites/formato.
- `server/study-kit.validation.test.ts`: modalidad/conteo, estructura/citas, visual PDF sin página, snap de cita, campos/archivos/proof, follow-up y snapshot.
- `server/study-kit.smart-study.test.ts`: sesión → pending → PUT 200 sintético; error/retry, 401, conflicto/offline, límite 10/ID único, cambio de perfil y respuestas tardías.
- `server/studyhub-cloud-file-integrity.test.ts`: ETag débil con SHA correcto; mismatch preserva copias; reintento de descarga.
- `server/studyhub.validation.test.ts` y otros `server/*.test.ts`: validación de estados, rutas/helpers y compatibilidad; inventario exhaustivo por cada test: **NO VERIFICADO** aquí.

`TODO.md:188` conserva el último resultado anterior: `pnpm check`, `pnpm test` (83/83 en 10 archivos), `pnpm build` y sintaxis de JS aprobados. No se debe presentar como una repetición de esta tarea.

## Dependencias de Manus que hay que revisar/reemplazar

- **Repositorio/checkpoints/publicación:** Git canónico y configuración de Webdev de Manus; fuera de Manus configurar Git remoto, CI y deploy propio. El paquete no ejecuta publicación.
- **Autenticación del starter:** `MANUS_*` en `server/_core/sdk.ts`; decidir reemplazo. El login Google propio exige cookies seguras, validación de ID token, nonce de un solo uso y DB.
- **DB:** Manus provisiona el acceso inicial; migrar a MySQL administrado externo con backups y volumen persistente.
- **Almacenamiento privado:** actualmente MySQL BLOB + IndexedDB del navegador. Un object store externo requeriría controles de propietario, checksum, URLs privadas y conservar copias.
- **Gemini/Google:** depende directamente de credenciales y cuota Google; la clave debe permanecer servidor.
- **Service Worker / offline:** el shell usa same-origin; mantener rutas estáticas, HTTPS y cache versioning. No purgar IndexedDB como forma de invalidar SW.
- **Notificaciones externas:** dependencia de notificaciones propia de esta aplicación: **NO VERIFICADO**. `OWNER_OPEN_ID` es una variable del starter; no demuestra que exista una ruta de notificación activa.
- **Health/deploy:** `/api/health` es la ruta de salud indicada en configuración Webdev previa. Configurar health check y `PORT` al migrar; el estado del deploy oficial actual no se verificó en esta tarea.
