# 05 — Problemas abiertos y diagnóstico pendiente

## Estado epistemológico

Los síntomas exactos de los apartados A y B se copiaron del archivo de requisitos del usuario. No se reprodujeron visualmente en navegador ni contra una cuenta real en esta tarea. No se ejecutaron tests/build/check ni se llamó a Gemini. Se leyó el código actual de `HEAD c9b6406` y las pruebas sintéticas ya existentes. Por tanto, separar:

- **Reportado por el usuario:** síntoma que aparece aquí.
- **Comprobado en código:** ruta y comportamiento que la rama c9b6406 implementa.
- **NO VERIFICADO:** estado de Preview/producción, proveedor Gemini, OAuth, cuota, DB o red del usuario.

No aplicar cambios antes de observar la respuesta de red que acompaña al error.

## A. Evaluación de respuesta queda `pending`

**Síntoma exacto reportado:** «La respuesta se conservó, pero Gemini no alcanzó a corregirla. Comprueba la conexión y la nube; luego puedes reintentar la evaluación.» Aparece el botón «Reintentar evaluación».

**Comprobado en código:**

- `client/public/studyhub-study-kit-v18.js:758` muestra el texto si `answer.pending === true` y `session.evaluating === false`.
- `studyKitSubmitCurrent()` (`:771–825`) guarda la respuesta primero como `{ userAnswer, correct: null, pending: true }`, salva la sesión y llama `requestAI('/api/gemini/study-answer', …)` (`:805–810`).
- El catch deja `pending=true`, guarda de nuevo y muestra el error (`:825`). Por eso el mensaje genérico no revela por sí solo el status HTTP ni prueba que Gemini haya procesado la petición.
- `client/public/studyhub-cloud-v20.js:1233–1273` exige Google, Internet y nube confirmada. Si hay `pending`, intenta `syncNow()` antes de la llamada. Reintenta una sola vez timeouts/red/408/425/429/5xx, con `Retry-After` si existe; 400/401/409/422 no se reintentan automáticamente.
- `/api/gemini/study-answer` (`server/studyhub.ts:1998–2042`) exige usuario y snapshot cloud confirmado; aplica límite, resuelve materiales, valida formato/cita, llama Gemini y valida `validAdaptiveResult()`. Una respuesta mal formada o con cita inválida devuelve HTTP 422.
- `callGemini()` usa 90 s; devuelve 429 para cuota/proveedor, 502 para respuesta vacía/5xx y 400 para otros errores HTTP del proveedor. Sin `GEMINI_API_KEY`, responde 503.

**Hipótesis ordenadas para investigar; no son diagnóstico confirmado:**

1. **Cloud pending/sync no confirmado o error al subir la respuesta guardada.** Plausible porque el cliente sincroniza antes de Gemini y el mensaje invita a revisar la nube. Falta: Network de `/api/study/state` o evento `studyhub:sync-state`, `status`, `code`, revisión y error visible.
2. **HTTP 422 por formato/cita de entrada o salida adaptativa.** `validAdaptiveResult()` rechaza estructura, respuesta o procedencia. Falta: body JSON seguro de respuesta y fixture sintético que reproduzca exactamente pregunta/material; no compartir el texto académico real.
3. **HTTP 429 por límite temporal del servidor o cuota de Google.** El servidor limita 20 solicitudes por usuario/minuto en memoria y devuelve `Retry-After: 60`; Google también puede responder 429. Falta: status, header `Retry-After` y si hubo request a Google.
4. **Timeout/red/5xx/JSON inválido.** La llamada servidor tiene timeout 90 s; el cliente intenta una sola repetición para timeout/red/5xx. Falta: duración, status, tipo de error y resultado de repetición.
5. **Configuración/API de modelo (400/503).** `GEMINI_MODEL` puede nombrar un modelo no disponible; clave ausente da 503 y errores HTTP del proveedor distintos de 429/5xx se exponen como 400 genérico. Valor/configuración actual: **NO VERIFICADO**.

El orden anterior es una prioridad de diagnóstico según los caminos del código y el mensaje, no una estimación estadística. Sin status/código no se puede elegir una causa real.

**Próximo diagnóstico propuesto (sin hacerlo en esta tarea):**

1. En una sesión autorizada del estudiante, abrir DevTools → Network y capturar solo URL, status, `code`, `error`, `Retry-After` y duración de `/api/study/state` y `/api/gemini/study-answer`. No exportar request bodies, cookies, credenciales, PDFs ni apuntes.
2. Anotar si el POST de evaluación llegó a servidor o falló antes en el preflight/sync. Inspeccionar el último evento `studyhub:sync-state` y si el indicador termina en confirmado/error.
3. Si es 422, reproducir el caso con datos sintéticos y `callGemini` simulado; distinguir validación de entrada de `validAdaptiveResult` de salida. No relajar citas.
4. Si es 429, revisar `Retry-After` y cuota de Google en la consola del propietario, sin mostrar clave.
5. No existe en la ruta revisada un log diagnóstico por cada fallo Gemini que incluya la clase del error sin contenido. Instrumentación futura, si se autoriza, debe registrar solo endpoint, status interno, categoría, duración y request ID; nunca prompt, respuesta, email o bytes del archivo.

## B. Sesión se pausa al comenzar Smart Study

**Síntoma exacto reportado:** «Study Kit pausado: vuelve a conectar, iniciar sesión con Google y esperar la confirmación de la nube para continuar.» La barra queda «Pendiente de sincronizar».

**Causa histórica comprobada por prueba sintética:** en el estado de código previo al fix (`0425161`), el manejador trataba `!onlineReady()` como pausa real. Guardar una nueva sesión produce `pending/syncing` legítimo; el handler volvía a pausar/guardar/reencolar la sesión. No fue rechazo del hash de proof, validación de sesiones ni límite de 10.

**Estado del código actual leído (c9b6406):**

- `syncStateBlocksSession()` en `client/public/studyhub-study-kit-v18.js:86` devuelve bloqueo solo para `offline`, `signed-out` o `conflict`.
- `handleSyncState()` (`:1011–1054`) trata `pending/syncing` como aviso «Sincronizando…», mantiene la sesión y reserva una sugerencia de retry a los 15 s; solo reanuda en `confirmed`.
- `isOnlineStudyReady()` en `client/public/studyhub-cloud-v20.js:1232` todavía exige `!pending && !syncing`, pero esa función deshabilita operaciones nuevas que requieren cloud confirmado; no es el predicado actual para pausar una sesión ya iniciada.
- `server/study-kit.smart-study.test.ts:179–224` simula el cliente v18 y la ruta real `PUT /api/study/state`: espera HTTP 200, `{ revision: 2, confirmed: true }`, mantiene status active durante pending y preserva `studyKitProofHash`.
- El test no usa Google, Gemini, una DB real ni navegador visual.

**Conclusión:** la causa conocida se corrigió en el código de c9b6406. Que la Preview o producción del estudiante ya esté sirviendo ese código: **NO VERIFICADO**. El dominio oficial no se publicó en esta tarea. Si el usuario continúa viendo el texto antiguo, comparar la URL/versión de scripts servida (`studyhub-cloud-v20.js`, `studyhub-study-kit-v18.js`, SW shell v27) antes de cambiar código.

**Faltan para confirmar el incidente actual:** versión/URL abierta por el usuario; evento exacto recibido (pending, error, signed-out, conflict); status/code del `PUT`; si el navegador activó el SW v27; captura visual sin datos personales. La suite previa registrada en `TODO.md` es evidencia sintética, no una reproducción en el navegador del usuario.

## C. Otros errores/fallos conocidos

### Integridad del kit al sincronizar

`invalid_study_kit_integrity` responde 422 y no modifica nube. El servidor escribe un log seguro `Study Kit integrity rejected` con rama, razón, `kitId` y nombres de campos (`server/studyhub.ts:1782–1787`). La causa de una reproducción sintética fue rama c (`followUps` cambió sin renovar proof). La rama del 422 histórico real: **NO VERIFICADO**. El servidor conserva protección; el cliente permite recuperación/descartar solo el kit tras confirmación explícita, según el flujo actual.

### Mismatch del archivo privado

`CLOUD_FILE_CHECKSUM_MISMATCH` significa que SHA-256 de los bytes descargados no coincide con el checksum del snapshot. Es rechazo deliberadamente seguro, no autorización para reparar. Se preservan copias. Revisar status de GET, checksum esperado/calculado y headers informativos; nunca descartar el original.

### `ReferenceError: studyhub is not defined`

Fue reportado en una sesión anterior para scripts antiguos. El HTML actual carga cloud v20 después de merge/session/Study Kit/training. Reproducción actual y causa original: **NO VERIFICADO**. No borrar compatibilidad basándose solo en un reporte antiguo.

### Sesiones y datos de perfil

La suite sintética cubre el caso HTTP 401, error/retry, conflicto, offline, límite de 10, ID estable, cambio de perfil y descarte de generación/transcripción tardía. La integración real con dos cuentas y dos navegadores: **NO VERIFICADO**. No usar cuentas de estudiantes como prueba.

## Evidencia disponible y límites

`TODO.md:176–188` registra la validación anterior: HTTP 200 sintético y 83/83 pruebas en 10 archivos, más check/build. Esos comandos no se repitieron en esta tarea por instrucción explícita. No hubo llamada a Gemini, prueba manual, lectura de datos de usuarios ni publicación en esta tarea.
