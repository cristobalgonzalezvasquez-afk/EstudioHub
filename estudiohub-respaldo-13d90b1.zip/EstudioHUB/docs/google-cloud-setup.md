# Configuración Google de EstudioHUB

## Proyecto OAuth

- Proyecto Google Cloud: `EstudioHUB`.
- ID del proyecto: `united-storm-511612-b7`.
- La plataforma de consentimiento OAuth quedó en modo **Prueba / Externo**.
- Cliente creado: **EstudioHUB Preview**, tipo **Aplicación web**.
- Único origen JavaScript autorizado configurado: `https://8328-icnenjd1g2v2bcxmnyud5-a19bc498.us4.manus.computer`.
- No se añadieron URI de redirección porque la aplicación usa Google Identity Services con token ID y validación de nonce en el servidor.
- El público permanece en modo Externo/Prueba; para validar el acceso, la cuenta propietaria debe figurar en la lista de usuarios de prueba. El inicio de sesión real todavía no se ha comprobado.
- El flujo de token ID no utiliza el Client Secret; no se descargó ni se guardó ese secreto.
- El valor público del Client ID debe incorporarse a `GOOGLE_CLIENT_ID` mediante la entrada protegida del proyecto. No copiarlo al código fuente.
- `GEMINI_API_KEY` aún está pendiente; deberá guardarse en la entrada protegida del proyecto después de obtenerla desde Google AI Studio.

## Referencias operativas

- Google Auth Platform / Clientes: https://console.cloud.google.com/auth/clients?project=united-storm-511612-b7
- Google Auth Platform / Público: https://console.cloud.google.com/auth/audience?project=united-storm-511612-b7
- Credenciales de Google Cloud: https://console.cloud.google.com/apis/credentials?project=united-storm-511612-b7
- Página para gestionar claves de Google AI Studio: https://aistudio.google.com/apikey

No almacenar claves API, secretos OAuth ni tokens en este documento, el repositorio, la consola del navegador o el chat.

## Estado operativo comprobado (14 de octubre de 2026)

Las migraciones `0001_lazy_nebula` y `0002_tense_lizard` se aplicaron correctamente. Son aditivas: crean las tablas privadas de estado, archivos, operaciones y sesiones; la segunda añade el hash de carga a las operaciones. No eliminan datos existentes. El esquema MySQL confirmó las cuatro tablas nuevas.

El Preview responde con HTTP 200 en `/`, `/api/health`, `/manus-routes.json`, `/studyhub-service-worker.js`, CSS, módulos TEA/nube, manifiesto e icono; el endpoint de estado devuelve `401` sin sesión. El manifiesto de rutas responde como JSON con la ruta raíz. El Service Worker `estudiohub-shell-v9` exige precargar con éxito el HTML raíz y todo el shell antes de activarse. Pasaron `pnpm check`, 18 pruebas, `pnpm build`, la sintaxis de los módulos JS y de los cuatro scripts inline ejecutables (el bloque `text/plain` no es código ejecutable), además de `git diff --check`. No se simuló una desconexión de red en un navegador para esta revisión, por lo que la activación y navegación offline real siguen pendientes de esa comprobación interactiva.

El servidor verifica firmas/MIME de PDF, DOCX, XLSX/XLSM, PPTX, imágenes y textos conocidos. Archivos con extensiones no reconocidas se guardan/entregan solo como `application/octet-stream` adjunto, no como contenido activo. Las referencias `f_*` tienen un patrón y límite común de 150 caracteres en cliente y servidor; las claves malformadas se rechazan antes de cambiar la nube o restaurar respaldos.

Los adjuntos retirados o divergentes se conservan en el estado privado como versiones recuperables con SHA-256, tamaño y MIME; la descarga comprueba la huella y el tamaño, y el toolbar bloquea entradas antiguas que carecen de SHA-256 verificable. No se purgan automáticamente. Los nuevos respaldos JSON/carpeta fallan de forma segura si no hay WebCrypto para emitir SHA-256. Al restaurar, los archivos sin SHA-256 verificable o con checksum heredado débil como FNV-32 requieren confirmación separada y un punto recuperable previo. El servidor acepta snapshots de datos v3/v4 con colecciones principales y anidadas acotadas; la versión futura o una estructura incompatible se rechaza antes de escribir. En modalidad TEA combinada, la cantidad 5/10/15/20 cuenta alternativas y pareados; se agregan cinco flashcards aparte. La extracción, importación y generación TEA usan el mismo máximo de 100.000 caracteres de fuente; las citas se validan contra el texto visible al usuario. Los logs de base de datos registran solo códigos de error técnicos acotados.

Aún no se configuraron `GOOGLE_CLIENT_ID` ni `GEMINI_API_KEY`; por eso no se pudo probar el login real, la sincronización de una cuenta Google ni las respuestas Gemini. Antes del primer test, confirmar en Google Auth Platform que la cuenta propietaria figure como usuaria de prueba. La publicación automática permanece desactivada y no se hizo publicación pública.
