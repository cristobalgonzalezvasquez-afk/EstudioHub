# Entrada multimodal de Gemini — notas de implementación

Consulta realizada el 15 de octubre de 2026 para la corrección de Study Kit.

## Fuentes oficiales

- [Métodos de entrada de archivos — Gemini API](https://ai.google.dev/gemini-api/docs/file-input-methods)
- [Comprensión de documentos PDF — Gemini `generateContent`](https://ai.google.dev/gemini-api/docs/generate-content/document-processing)

## Hallazgos aplicables

- La guía de Gemini enumera `application/pdf` y formatos de texto como `text/plain` y `text/csv`, además de imágenes BMP, JPEG, PNG y WebP. DOCX/XLSX no aparecen en esa lista de tipos admitidos para entrada multimodal.
- Gemini procesa PDF con capacidades visuales, incluyendo gráficos, tablas, diagramas e imágenes. La documentación indica hasta 50 MB por PDF inline y hasta 100 MB por solicitud inline; el servicio de archivos acepta cargas mayores, pero las conserva hasta 48 horas.
- La documentación de procesamiento de documentos indica que los formatos no PDF recibidos como documento se ven como texto normal y pierden contexto de gráficos y formato.

## Decisión de implementación

Para cumplir la solicitud del usuario de evitar extracción local y análisis deformado: Study Kit enviará PDF e imágenes compatibles como bytes originales mediante entrada inline a Gemini; Word/Excel se convertirán a PDF **en el servidor** antes del análisis visual; texto escrito, TXT y CSV se enviarán como texto. No se usará la API temporal de archivos de Gemini para no dejar copias de los materiales allí durante 48 horas. El tamaño total de adjuntos por solicitud se limitará para mantenerse dentro de los límites inline y proteger memoria/latencia.
