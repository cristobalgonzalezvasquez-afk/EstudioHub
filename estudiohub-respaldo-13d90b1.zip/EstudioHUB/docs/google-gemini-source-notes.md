# Fuentes oficiales — Google Sign-In y Gemini

Consultadas el 13 de octubre de 2026. Estas notas registran las páginas de origen y sus requisitos pertinentes para EstudioHUB.

## Google Identity Services

- Guía oficial de alta del OAuth client ID: https://developers.google.com/identity/gsi/web/guides/get-google-api-clientid
- El sitio necesita un OAuth 2.0 Client ID de tipo **Web application**. Se deben agregar el origen web exacto a **Authorized JavaScript origins** (esquema y host, sin ruta). Para iniciar sesión por callback JavaScript no se requiere URI de redirección; solo se agregaría una si la aplicación eligiera flujo de redirección.
- La guía indica configurar la pantalla de consentimiento/branding y usar scopes básicos `openid`, `email` y `profile` para autenticación, sin pedir scopes de Google APIs que no se necesiten.
- La implementación debe verificar el ID token en el servidor (firma, emisor, audiencia, vencimiento y nonce); no confiar en la identidad que el navegador informe.

## Gemini API key

- Guía oficial: https://ai.google.dev/gemini-api/docs/api-key
- La clave se debe mantener confidencial y **nunca incluirla en código de navegador, repositorio o archivos de configuración públicos**. Para una aplicación web de producción, la llamada debe pasar por un backend/proxy.
- La guía recomienda leer la clave de variables de entorno o un almacén de secretos y controlar límites/costos. Una clave no debe enviarse en query strings ni mostrarse en logs.
- Se usará la API desde el servidor EstudioHUB y la clave se ingresará mediante el flujo protegido del proyecto. No se habilitará facturación ni se cambiarán opciones con costo sin autorización expresa.

## Contrato REST consultado para la integración

La referencia actual `models.generateContent` acepta `contents`, `systemInstruction` y `generationConfig`; el endpoint usa `POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`. El modo JSON se define dentro de `generationConfig` con `responseMimeType: "application/json"`. La guía muestra `gemini-3.8-flash` como modelo Flash de ejemplo en esta consulta; EstudioHUB permite cambiar el nombre mediante `GEMINI_MODEL` si el catálogo/proyecto del usuario requiere otro modelo. La clave se envía en el encabezado `x-goog-api-key`, nunca al navegador.

Referencias adicionales consultadas:

- https://ai.google.dev/api/generate-content
- https://ai.google.dev/gemini-api/docs/api-key
